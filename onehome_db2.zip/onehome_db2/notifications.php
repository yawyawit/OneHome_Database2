<?php
require_once __DIR__ . '/includes/auth.php';
require_roles(['admin', 'employee', 'customer']);
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (($_POST['action'] ?? '') === 'read_all') {
        mark_all_notifications_read($u['user_id']);
        flash('All notifications marked as read.', 'info');
    } elseif (!empty($_POST['notification_id'])) {
        mark_notification_read((int) $_POST['notification_id'], $u['user_id']);
    }
    redirect('notifications.php');
}

$title = 'Notifications';
$rows = user_notifications($u['user_id'], 50);
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="mb-0">Notifications</h2>
    <?php if ($rows): ?>
        <form method="post">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="read_all">
            <button class="btn btn-sm btn-outline-secondary">Mark All Read</button>
        </form>
    <?php endif; ?>
</div>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No notifications yet.</div>
<?php else: ?>
    <div class="list-group">
        <?php foreach ($rows as $n): ?>
            <div class="list-group-item d-flex justify-content-between align-items-start gap-3 <?= $n['is_read'] ? '' : 'list-group-item-light border-primary' ?>">
                <div>
                    <div class="fw-semibold">
                        <?php if (!$n['is_read']): ?><span class="badge bg-primary me-1">New</span><?php endif; ?>
                        <?= e($n['title']) ?>
                    </div>
                    <div class="small text-muted"><?= e($n['message']) ?></div>
                    <div class="small text-muted mt-1"><?= fdatetime($n['created_at']) ?></div>
                </div>
                <div class="d-flex gap-2 flex-shrink-0">
                    <?php if (!empty($n['link'])): ?>
                        <a class="btn btn-sm btn-outline-primary" href="<?= url($n['link']) ?>">Open</a>
                    <?php endif; ?>
                    <?php if (!$n['is_read']): ?>
                        <form method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="notification_id" value="<?= (int) $n['notification_id'] ?>">
                            <button class="btn btn-sm btn-outline-secondary">Mark Read</button>
                        </form>
                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
