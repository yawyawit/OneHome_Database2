# One Home

A home-services two-sided marketplace web app for Baguio City built with HTML, CSS, Bootstrap 5, JavaScript, procedural PHP 8, and MariaDB/MySQL (XAMPP).

## System Lifecycle
`Request -> Match -> Quote -> Agreement (Booking) -> Service Execution -> Settlement (Payment & Payout) -> Review / Dispute`

- **Customers** maintain saved service addresses, post service requests, compare competing provider quotes, accept quotes into confirmed bookings, reschedule/cancel within state rules, pay (cash or simulated card ledger), open disputes, and submit reviews.
- **Service Providers** manage business profiles, availability, and service offerings (`fixed` or `quotation`), submit/withdraw quotes for matching open requests, execute and complete jobs, reschedule appointments, record cash captures, and track eligible payouts.
- **Dual-Role Support**: A single `User` identity may hold both `Customer` and `Provider` profiles and switch workspaces from the navbar.
- **Admins** verify providers, manage service categories, monitor bookings under permitted state-machine transitions, manage the payment & refund ledger, initiate/reconcile provider payouts, investigate/resolve disputes, and inspect audit logs and reports.

## Setup
1. Start **Apache** and **MySQL** in XAMPP.
2. Import `database/one_home.sql` in phpMyAdmin (or via `mysql.exe -u root < database/one_home.sql`).
3. Configure database credentials in `includes/dbconn.php` if needed.
4. Open `http://localhost/onehome_db2/` in your browser.

## Demo Accounts (password for all: `password`)
- **Admin:** `admin@onehome.test`
- **Verified Providers:** `juan@onehome.test`, `maria@onehome.test`, `pedro@onehome.test`, `ana@onehome.test` (dual-role Customer + Provider)
- **Pending Verification Provider:** `carlo@onehome.test`
- **Customers:** `liza@onehome.test`, `mark@onehome.test`
