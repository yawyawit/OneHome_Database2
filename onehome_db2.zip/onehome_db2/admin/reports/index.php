<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Reports & Audit Log';
$svc = db_all(
    "SELECT sc.category_name AS name, COUNT(b.booking_id) AS c
     FROM service_categories sc
     LEFT JOIN service_requests sr ON sr.category_id = sc.category_id
     LEFT JOIN bookings b ON b.request_id = sr.request_id
     GROUP BY sc.category_id ORDER BY c DESC LIMIT 5"
);
$emp = db_all(
    "SELECT p.business_name AS name, COUNT(b.booking_id) AS c
     FROM providers p
     LEFT JOIN quotes q ON q.provider_id = p.provider_id
     LEFT JOIN bookings b ON b.quote_id = q.quote_id AND b.booking_status IN ('completed','settled')
     WHERE p.verification_status = 'verified' AND p.provider_status = 'active'
     GROUP BY p.provider_id ORDER BY c DESC LIMIT 5"
);
$avg = db_val("SELECT ROUND(AVG(rating), 2) FROM reviews");
$total = (int) db_val("SELECT COUNT(*) FROM reviews");
$logs = db_all("SELECT al.*, u.full_name AS actor_name FROM audit_logs al LEFT JOIN users u ON u.user_id = al.actor_user_id ORDER BY al.created_at DESC LIMIT 15");

function bars($rows)
{
    $max = max(1, max(array_column($rows, 'c') ?: [0]));
    foreach ($rows as $r) {
        echo '<div class="mb-2"><div class="d-flex justify-content-between"><span>' . e($r['name']) . '</span><b>' . (int) $r['c'] . '</b></div><div class="progress"><div class="progress-bar" style="width:' . ((int) $r['c'] / $max * 100) . '%"></div></div></div>';
    }
}
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between">
    <h2>Reports &amp; Audit Trail</h2>
    <div class="no-print">
        <a class="btn btn-primary" href="monthly_report.php">Monthly Bookings &amp; Revenue</a>
        <button class="btn btn-outline-secondary" onclick="window.print()">Print</button>
    </div>
</div>
<div class="row mt-3">
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header">Most Booked Service Categories</div>
            <div class="card-body"><?php bars($svc); ?></div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header">Top Providers by Completed Jobs</div>
            <div class="card-body"><?php bars($emp); ?></div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header">Customer Satisfaction</div>
            <div class="card-body">
                <p class="fs-3 mb-2"><?= $total ? stars($avg) . ' ' . $avg . ' / 5' : 'No ratings yet' ?> <small class="text-muted fs-6">(<?= $total ?> reviews)</small></p>
                <?php for ($i = 5; $i >= 1; $i--):
                    $n = (int) db_val("SELECT COUNT(*) FROM reviews WHERE rating = ?", [$i]); ?>
                    <div class="d-flex align-items-center mb-1">
                        <span style="width:50px"><?= $i ?> ★</span>
                        <div class="progress flex-grow-1"><div class="progress-bar bg-warning" style="width:<?= $total ? $n / $total * 100 : 0 ?>%"></div></div>
                        <span class="ms-2"><?= $n ?></span>
                    </div>
                <?php endfor; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6 mb-3">
        <div class="card h-100">
            <div class="card-header">Recent Audit Logs</div>
            <div class="card-body p-0">
                <ul class="list-group list-group-flush small">
                    <?php foreach ($logs as $l): ?>
                        <li class="list-group-item">
                            <b><?= e($l['action']) ?></b> (<?= e($l['entity_type']) ?> #<?= (int) $l['entity_id'] ?>)
                            by <?= e($l['actor_name'] ?: 'System') ?> &mdash; <?= e($l['details']) ?>
                            <div class="text-muted"><?= fdatetime($l['created_at']) ?></div>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
