<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Monthly Report';
$rows = db_all(
    "SELECT DATE_FORMAT(b.scheduled_start, '%Y-%m') AS m,
            COUNT(DISTINCT b.booking_id) AS total,
            SUM(b.booking_status IN ('completed','settled')) AS done,
            SUM(b.booking_status IN ('cancelled','refunded')) AS cancelled,
            COALESCE((
                SELECT SUM(CASE WHEN p.payment_type='capture' AND p.payment_status='successful' THEN p.amount
                                WHEN p.payment_type='refund' AND p.payment_status='successful' THEN -p.amount ELSE 0 END)
                FROM payments p
                JOIN bookings b2 ON b2.booking_id = p.booking_id
                WHERE DATE_FORMAT(b2.scheduled_start, '%Y-%m') = DATE_FORMAT(b.scheduled_start, '%Y-%m')
            ), 0) AS net_revenue
     FROM bookings b
     GROUP BY m
     ORDER BY m DESC
     LIMIT 12"
);
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between">
    <h2>Monthly Bookings &amp; Net Revenue</h2>
    <button class="btn btn-outline-secondary no-print" onclick="window.print()">Print</button>
</div>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No data yet.</div>
<?php else: ?>
    <table class="table table-striped bg-white">
        <thead class="table-light">
            <tr><th>Month</th><th>Total Bookings</th><th>Completed / Settled</th><th>Cancelled / Refunded</th><th>Net Captured Revenue</th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <tr>
                    <td><?= date('F Y', strtotime($r['m'] . '-01')) ?></td>
                    <td><?= (int) $r['total'] ?></td>
                    <td><?= (int) $r['done'] ?></td>
                    <td><?= (int) $r['cancelled'] ?></td>
                    <td><?= money($r['net_revenue']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<a class="btn btn-secondary no-print" href="index.php">Back to reports</a>
<?php require INC . '/footer.php'; ?>
