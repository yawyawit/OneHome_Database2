<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Reviews & Ratings';
$perf = db_all(
    "SELECT p.business_name, u.full_name, COUNT(r.review_id) AS cnt, ROUND(AVG(r.rating), 1) AS avg_r
     FROM providers p
     JOIN users u ON u.user_id = p.user_id
     LEFT JOIN quotes q ON q.provider_id = p.provider_id
     LEFT JOIN bookings b ON b.quote_id = q.quote_id
     LEFT JOIN reviews r ON r.booking_id = b.booking_id
     WHERE p.verification_status = 'verified' AND p.provider_status = 'active'
     GROUP BY p.provider_id
     ORDER BY avg_r DESC"
);
$rows = db_all(
    "SELECT r.*, cu.full_name AS cname, pr.business_name AS ename, sc.category_name AS sname
     FROM reviews r
     JOIN bookings b ON b.booking_id = r.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN customers c ON c.customer_id = r.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     JOIN providers pr ON pr.provider_id = q.provider_id
     ORDER BY r.created_at DESC"
);
require INC . '/header.php'; ?>
<h2>Reviews &amp; Ratings</h2>
<h5 class="mt-3">Provider Performance</h5>
<table class="table table-sm bg-white" style="max-width:650px">
    <thead class="table-light"><tr><th>Provider</th><th>Reviews</th><th>Average rating</th></tr></thead>
    <tbody>
        <?php foreach ($perf as $p): ?>
            <tr>
                <td><?= e($p['business_name']) ?> <small class="text-muted">(<?= e($p['full_name']) ?>)</small></td>
                <td><?= (int) $p['cnt'] ?></td>
                <td><?= rating_text($p['avg_r'], $p['cnt']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<h5 class="mt-4">All Reviews</h5>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No reviews yet.</div>
<?php else: ?>
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light"><tr><th>Date</th><th>Customer</th><th>Provider</th><th>Category</th><th>Rating</th><th>Comment</th><th></th></tr></thead>
        <tbody>
            <?php foreach ($rows as $r): ?>
                <tr class="<?= $r['rating'] <= 2 ? 'table-danger' : '' ?>">
                    <td><?= fdate($r['created_at']) ?></td>
                    <td><?= e($r['cname']) ?></td>
                    <td><?= e($r['ename']) ?></td>
                    <td><?= e($r['sname']) ?></td>
                    <td><?= stars($r['rating']) ?></td>
                    <td><?= e($r['comment']) ?></td>
                    <td><a class="btn btn-sm btn-outline-primary" href="view.php?id=<?= (int) $r['review_id'] ?>">View</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
