<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$u = current_user();
$rid = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$r = db_one(
    "SELECT r.*, cu.full_name AS cname, pr.business_name AS ename
     FROM reviews r
     JOIN bookings b ON b.booking_id = r.booking_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN customers c ON c.customer_id = r.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     JOIN providers pr ON pr.provider_id = q.provider_id
     WHERE r.review_id = ?",
    [$rid]
);
if (!$r) {
    flash('Review not found.', 'danger');
    redirect('admin/reviews/index.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    db_exec("DELETE FROM reviews WHERE review_id = ?", [$rid]);
    audit_log($u['user_id'], 'review', $rid, 'review_deleted', 'Removed inappropriate review');
    flash('Review deleted.');
    redirect('admin/reviews/index.php');
}
$b = get_booking((int) $r['booking_id']);
$title = 'Review #' . $rid;
require INC . '/header.php'; ?>
<h2>Review #<?= $rid ?></h2>
<div class="card mb-3">
    <div class="card-body">
        <p><b><?= e($r['cname']) ?></b> reviewed <b><?= e($r['ename']) ?></b></p>
        <p class="fs-4"><?= stars($r['rating']) ?></p>
        <p><?= e($r['comment'] ?: '(no comment)') ?></p>
        <small class="text-muted"><?= fdate($r['created_at']) ?></small>
    </div>
</div>
<h5>Related booking</h5>
<?php booking_info($b); ?>
<form method="post" class="d-inline" data-confirm="Delete this review permanently?">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $rid ?>">
    <button class="btn btn-danger">Delete Review</button>
</form>
<a class="btn btn-secondary" href="index.php">Back</a>
<?php require INC . '/footer.php'; ?>
