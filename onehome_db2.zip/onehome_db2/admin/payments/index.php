<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Payment Ledger';
$type = in_array($_GET['type'] ?? '', ['authorization', 'capture', 'refund', 'adjustment'], true) ? $_GET['type'] : '';
$st = in_array($_GET['status'] ?? '', ['pending', 'successful', 'failed', 'reversed'], true) ? $_GET['status'] : '';

$rows = db_all(
    "SELECT p.*, b.agreed_price, b.booking_status, sc.category_name, cu.full_name AS cname, pr.business_name
     FROM payments p
     JOIN bookings b ON b.booking_id = p.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN customers c ON c.customer_id = sr.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     JOIN providers pr ON pr.provider_id = q.provider_id
     WHERE (? = '' OR p.payment_type = ?) AND (? = '' OR p.payment_status = ?)
     ORDER BY p.created_at DESC",
    [$type, $type, $st, $st]
);

$captured = (float) db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_type = 'capture' AND payment_status = 'successful'");
$refunded = (float) db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_type = 'refund' AND payment_status = 'successful'");
require INC . '/header.php'; ?>
<h2>Payment Ledger</h2>
<div class="row mt-3">
    <?= stat_card('Total captured', money($captured), 'bi-cash-coin', 'success') ?>
    <?= stat_card('Total refunded', money($refunded), 'bi-arrow-counterclockwise', 'dark') ?>
    <?= stat_card('Net collected', money(max(0, $captured - $refunded)), 'bi-wallet2', 'primary') ?>
</div>
<form class="row g-2 mb-3" method="get">
    <div class="col-auto">
        <select name="type" class="form-select">
            <option value="">All types</option>
            <?php foreach (['authorization', 'capture', 'refund', 'adjustment'] as $t): ?>
                <option value="<?= $t ?>" <?= $type === $t ? 'selected' : '' ?>><?= ucfirst($t) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-auto">
        <select name="status" class="form-select">
            <option value="">All status</option>
            <?php foreach (['pending', 'successful', 'failed', 'reversed'] as $s): ?>
                <option value="<?= $s ?>" <?= $st === $s ? 'selected' : '' ?>><?= ucfirst($s) ?></option>
            <?php endforeach; ?>
        </select>
    </div>
    <div class="col-auto"><button class="btn btn-outline-primary">Filter</button></div>
</form>
<div class="table-responsive">
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light">
            <tr><th>#</th><th>Booking</th><th>Customer</th><th>Provider</th><th>Type</th><th>Method</th><th>Amount</th><th>Status</th><th>Reference</th><th>Date</th><th></th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $p): ?>
                <tr>
                    <td>#<?= (int) $p['payment_id'] ?></td>
                    <td>#<?= (int) $p['booking_id'] ?> <?= e($p['category_name']) ?></td>
                    <td><?= e($p['cname']) ?></td>
                    <td><?= e($p['business_name']) ?></td>
                    <td><?= badge($p['payment_type']) ?></td>
                    <td><?= pay_label($p['method']) ?></td>
                    <td class="fw-semibold"><?= money($p['amount']) ?></td>
                    <td><?= badge($p['payment_status']) ?></td>
                    <td><code><?= e($p['gateway_reference'] ?: '-') ?></code></td>
                    <td><?= fdatetime($p['created_at']) ?></td>
                    <td><a class="btn btn-sm btn-outline-primary" href="view.php?booking_id=<?= (int) $p['booking_id'] ?>">Ledger</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require INC . '/footer.php'; ?>
