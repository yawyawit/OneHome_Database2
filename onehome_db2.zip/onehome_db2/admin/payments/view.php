<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$u = current_user();
$bookingId = (int) ($_GET['booking_id'] ?? $_POST['booking_id'] ?? 0);
if ($bookingId === 0 && !empty($_GET['id'])) {
    $bookingId = (int) db_val("SELECT booking_id FROM payments WHERE payment_id = ?", [(int) $_GET['id']]);
}
$b = get_booking($bookingId);
if (!$b) {
    flash('Booking payment ledger not found.', 'danger');
    redirect('admin/payments/index.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    $conn->beginTransaction();
    db_one("SELECT booking_id FROM bookings WHERE booking_id = ? FOR UPDATE", [$bookingId]);
    $fin = booking_financials($bookingId, $b['agreed_price']);

    if ($action === 'capture') {
        $amt = (float) ($_POST['amount'] ?? 0);
        if (!in_array($b['booking_status'], ['completed', 'settled'], true)) {
            $conn->rollBack();
            flash('Payments can only be captured for completed bookings.', 'danger');
        } elseif ($amt <= 0 || $amt > $fin['balance_due']) {
            $conn->rollBack();
            flash('Capture amount must be between ₱0.01 and remaining balance (' . money($fin['balance_due']) . ').', 'danger');
        } else {
            $ref = 'CAP-ADM-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
            $pid = (int) db_exec(
                "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, gateway_reference, notes)
                 VALUES (?, ?, 'PHP', 'capture', 'successful', ?, ?, ?)",
                [$bookingId, $amt, $fin['method'], $ref, 'Admin recorded capture']
            );
            audit_log($u['user_id'], 'payment', $pid, 'admin_capture', 'Booking #' . $bookingId . ' amount=' . $amt);
            $conn->commit();
            flash('Payment capture recorded.');
        }
    } elseif ($action === 'refund') {
        $amt = (float) ($_POST['amount'] ?? 0);
        $maxRefundable = max(0.0, round($fin['captured'] - $fin['refunded'], 2));
        if ($amt <= 0 || $amt > $maxRefundable) {
            $conn->rollBack();
            flash('Refund amount must be between ₱0.01 and net captured (' . money($maxRefundable) . ').', 'danger');
        } else {
            $ref = 'REF-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
            $pid = (int) db_exec(
                "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, gateway_reference, notes)
                 VALUES (?, ?, 'PHP', 'refund', 'successful', ?, ?, ?)",
                [$bookingId, $amt, $fin['method'], $ref, trim($_POST['notes'] ?? 'Admin refund operation')]
            );
            if ($amt >= $maxRefundable && can_transition_booking($b['booking_status'], 'refunded')) {
                db_exec("UPDATE bookings SET booking_status = 'refunded' WHERE booking_id = ?", [$bookingId]);
            }
            audit_log($u['user_id'], 'payment', $pid, 'refund_recorded', 'Booking #' . $bookingId . ' refund=' . $amt . ' ref=' . $ref);
            notify_user($b['customer_user_id'], 'Refund Processed (Booking #' . $bookingId . ')', 'A refund of ' . money($amt) . ' was recorded.', 'customer/booking_details.php?id=' . $bookingId);
            $conn->commit();
            flash('Auditable refund record created.');
        }
    } else {
        $conn->rollBack();
        flash('Invalid payment operation.', 'danger');
    }
    redirect('admin/payments/view.php?booking_id=' . $bookingId);
}

$fin = booking_financials($bookingId, $b['agreed_price']);
$maxRefundable = max(0.0, round($fin['captured'] - $fin['refunded'], 2));
$title = 'Booking #' . $bookingId . ' Payment Ledger';
require INC . '/header.php'; ?>
<h2>Payment Ledger &mdash; Booking #<?= $bookingId ?> <?= badge($fin['pstatus']) ?></h2>
<?php booking_info($b); ?>

<div class="row mb-4">
    <?php if (in_array($b['booking_status'], ['completed', 'settled'], true) && $fin['balance_due'] > 0): ?>
        <div class="col-md-6">
            <form method="post" class="card card-body">
                <?= csrf_field() ?>
                <input type="hidden" name="booking_id" value="<?= $bookingId ?>">
                <input type="hidden" name="action" value="capture">
                <h5>Record Payment Capture</h5>
                <label class="form-label small">Amount (max <?= money($fin['balance_due']) ?>)</label>
                <input type="number" step="0.01" min="0.01" max="<?= e($fin['balance_due']) ?>" name="amount" value="<?= e($fin['balance_due']) ?>" class="form-control mb-2" required>
                <button class="btn btn-success">Record Capture</button>
            </form>
        </div>
    <?php endif; ?>

    <?php if ($maxRefundable > 0): ?>
        <div class="col-md-6">
            <form method="post" class="card card-body" data-confirm="Record an auditable refund transaction?">
                <?= csrf_field() ?>
                <input type="hidden" name="booking_id" value="<?= $bookingId ?>">
                <input type="hidden" name="action" value="refund">
                <h5>Issue Auditable Refund</h5>
                <label class="form-label small">Refund Amount (max <?= money($maxRefundable) ?>)</label>
                <input type="number" step="0.01" min="0.01" max="<?= e($maxRefundable) ?>" name="amount" value="<?= e($maxRefundable) ?>" class="form-control mb-2" required>
                <label class="form-label small">Reason / Reference Note</label>
                <input name="notes" class="form-control mb-2" placeholder="Dispute or cancellation refund" required>
                <button class="btn btn-danger">Record Refund</button>
            </form>
        </div>
    <?php endif; ?>
</div>

<h5>Transaction History</h5>
<table class="table table-bordered bg-white align-middle">
    <thead class="table-light">
        <tr><th>Type</th><th>Method</th><th>Amount</th><th>Status</th><th>Gateway Reference</th><th>Date</th></tr>
    </thead>
    <tbody>
        <?php foreach ($fin['records'] as $pr): ?>
            <tr>
                <td><?= badge($pr['payment_type']) ?></td>
                <td><?= pay_label($pr['method']) ?><?= $pr['card_last4'] ? ' (*' . e($pr['card_last4']) . ')' : '' ?></td>
                <td><?= money($pr['amount']) ?></td>
                <td><?= badge($pr['payment_status']) ?></td>
                <td><code><?= e($pr['gateway_reference'] ?: '-') ?></code></td>
                <td><?= fdatetime($pr['created_at']) ?></td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<a class="btn btn-secondary" href="index.php">Back to Payments</a>
<?php require INC . '/footer.php'; ?>
