<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'initiate') {
        $bookingId = (int) ($_POST['booking_id'] ?? 0);
        $b = get_booking($bookingId);
        if (!$b) {
            flash('Booking not found.', 'danger');
            redirect('admin/payouts/index.php');
        }
        $conn->beginTransaction();
        db_one("SELECT booking_id FROM bookings WHERE booking_id = ? FOR UPDATE", [$bookingId]);
        $fin = booking_financials($bookingId, $b['agreed_price']);
        $amt = (float) ($_POST['amount'] ?? $fin['remaining_payout']);
        if ($amt <= 0 || $amt > $fin['remaining_payout']) {
            $conn->rollBack();
            flash('Payout exceeds remaining eligible provider earnings (' . money($fin['remaining_payout']) . ') — BR-42.', 'danger');
        } else {
            $fee = round($amt * (PLATFORM_FEE_RATE / (1.0 - PLATFORM_FEE_RATE)), 2);
            $ref = 'PO-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
            $poId = (int) db_exec(
                "INSERT INTO payouts (booking_id, provider_id, amount, platform_fee, payout_status, gateway_reference, notes)
                 VALUES (?, ?, ?, ?, 'processing', ?, 'Initiated by admin')",
                [$bookingId, (int) $b['provider_id'], $amt, $fee, $ref]
            );
            audit_log($u['user_id'], 'payout', $poId, 'payout_initiated', 'Booking #' . $bookingId . ' amount=' . $amt . ' ref=' . $ref);
            $conn->commit();
            flash('Payout #' . $poId . ' initiated (' . money($amt) . ').');
        }
    } elseif ($action === 'status') {
        $poId = (int) ($_POST['payout_id'] ?? 0);
        $newStatus = in_array($_POST['payout_status'] ?? '', ['paid', 'failed', 'reversed'], true) ? $_POST['payout_status'] : '';
        $po = db_one("SELECT * FROM payouts WHERE payout_id = ?", [$poId]);
        if (!$po || !$newStatus) {
            flash('Invalid payout status request.', 'danger');
        } else {
            $conn->beginTransaction();
            db_exec(
                "UPDATE payouts SET payout_status = ?, paid_at = CASE WHEN ? = 'paid' THEN NOW() ELSE paid_at END WHERE payout_id = ?",
                [$newStatus, $newStatus, $poId]
            );
            $b = get_booking((int) $po['booking_id']);
            if ($newStatus === 'paid' && $b) {
                $fin = booking_financials($b['booking_id'], $b['agreed_price']);
                if ($fin['balance_due'] <= 0 && $fin['remaining_payout'] <= 0 && can_transition_booking($b['booking_status'], 'settled')) {
                    db_exec("UPDATE bookings SET booking_status = 'settled' WHERE booking_id = ?", [$b['booking_id']]);
                }
                notify_user($b['provider_user_id'], 'Payout #' . $poId . ' Paid', 'Your payout of ' . money($po['amount']) . ' for Booking #' . $b['booking_id'] . ' has been marked paid.', 'employee/payment_history.php');
            }
            audit_log($u['user_id'], 'payout', $poId, 'payout_' . $newStatus, 'Updated payout #' . $poId . ' to ' . $newStatus);
            $conn->commit();
            flash('Payout #' . $poId . ' marked ' . $newStatus . '.');
        }
    }
    redirect('admin/payouts/index.php');
}

$title = 'Provider Payouts';
$eligibleBookings = array_filter(list_bookings("b.booking_status IN ('completed','settled')"), function ($b) {
    $fin = booking_financials($b['booking_id'], $b['agreed_price']);
    return $fin['remaining_payout'] > 0;
});

$payoutRows = db_all(
    "SELECT po.*, p.business_name, sc.category_name
     FROM payouts po
     JOIN providers p ON p.provider_id = po.provider_id
     JOIN bookings b ON b.booking_id = po.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     ORDER BY po.created_at DESC"
);
require INC . '/header.php'; ?>
<h2>Provider Payouts</h2>

<?php if ($eligibleBookings): ?>
    <div class="card mb-4">
        <div class="card-header">Bookings Ready for Payout Initiation (90% of Net Captured)</div>
        <div class="card-body table-responsive p-0">
            <table class="table table-striped mb-0 align-middle">
                <thead class="table-light"><tr><th>Booking</th><th>Provider</th><th>Captured</th><th>Remaining Eligible</th><th>Action</th></tr></thead>
                <tbody>
                    <?php foreach ($eligibleBookings as $eb):
                        $fin = booking_financials($eb['booking_id'], $eb['agreed_price']); ?>
                        <tr>
                            <td>#<?= (int) $eb['booking_id'] ?> &mdash; <?= e($eb['offering_title']) ?></td>
                            <td><?= e($eb['provider_business_name']) ?></td>
                            <td><?= money($fin['captured'] - $fin['refunded']) ?></td>
                            <td class="fw-bold text-success"><?= money($fin['remaining_payout']) ?></td>
                            <td>
                                <form method="post" class="d-flex gap-1">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="initiate">
                                    <input type="hidden" name="booking_id" value="<?= (int) $eb['booking_id'] ?>">
                                    <input type="number" step="0.01" min="0.01" max="<?= e($fin['remaining_payout']) ?>" name="amount" value="<?= e($fin['remaining_payout']) ?>" class="form-control form-control-sm" style="width:120px" required>
                                    <button class="btn btn-sm btn-primary">Initiate Payout</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
<?php endif; ?>

<h4>Payout Ledger</h4>
<?php if (!$payoutRows): ?>
    <div class="alert alert-secondary">No payouts recorded yet.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped bg-white align-middle">
            <thead class="table-light"><tr><th>#</th><th>Booking</th><th>Provider</th><th>Amount</th><th>Fee</th><th>Status</th><th>Reference</th><th>Created</th><th>Actions</th></tr></thead>
            <tbody>
                <?php foreach ($payoutRows as $po): ?>
                    <tr>
                        <td>#<?= (int) $po['payout_id'] ?></td>
                        <td>#<?= (int) $po['booking_id'] ?> <?= e($po['category_name']) ?></td>
                        <td><?= e($po['business_name']) ?></td>
                        <td class="fw-semibold"><?= money($po['amount']) ?></td>
                        <td><?= money($po['platform_fee']) ?></td>
                        <td><?= badge($po['payout_status']) ?></td>
                        <td><code><?= e($po['gateway_reference'] ?: '-') ?></code></td>
                        <td><?= fdatetime($po['created_at']) ?></td>
                        <td>
                            <?php if (in_array($po['payout_status'], ['pending', 'processing'], true)): ?>
                                <form method="post" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="status">
                                    <input type="hidden" name="payout_id" value="<?= (int) $po['payout_id'] ?>">
                                    <input type="hidden" name="payout_status" value="paid">
                                    <button class="btn btn-sm btn-success">Mark Paid</button>
                                </form>
                                <form method="post" class="d-inline">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="status">
                                    <input type="hidden" name="payout_id" value="<?= (int) $po['payout_id'] ?>">
                                    <input type="hidden" name="payout_status" value="failed">
                                    <button class="btn btn-sm btn-outline-danger">Failed</button>
                                </form>
                            <?php elseif ($po['payout_status'] === 'paid'): ?>
                                <form method="post" class="d-inline" data-confirm="Reverse this paid payout?">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="status">
                                    <input type="hidden" name="payout_id" value="<?= (int) $po['payout_id'] ?>">
                                    <input type="hidden" name="payout_status" value="reversed">
                                    <button class="btn btn-sm btn-outline-dark">Reverse</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
