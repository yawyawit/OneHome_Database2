<?php require_once __DIR__ . '/../includes/auth.php';
require_once INC . '/notifications.php';
require_role('admin');
$title = 'Admin Dashboard';
$cust = (int) db_val("SELECT COUNT(*) FROM customers");
$prov = (int) db_val("SELECT COUNT(*) FROM providers WHERE verification_status = 'verified' AND provider_status = 'active'");
$pendProv = pending_employees_count();
$openDisputes = open_disputes_count();
$total = (int) db_val("SELECT COUNT(*) FROM bookings");
$done = (int) db_val("SELECT COUNT(*) FROM bookings WHERE booking_status IN ('completed','settled')");
$captured = (float) db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_type = 'capture' AND payment_status = 'successful'");
$refunded = (float) db_val("SELECT COALESCE(SUM(amount),0) FROM payments WHERE payment_type = 'refund' AND payment_status = 'successful'");
$netRevenue = max(0.0, $captured - $refunded);
$recent = array_slice(list_bookings(), 0, 5);
require INC . '/header.php'; ?>
<h2>Admin Dashboard</h2>
<div class="row mt-3">
    <?= stat_card('Total customers', $cust, 'bi-people', 'primary') ?>
    <?= stat_card('Verified providers', $prov, 'bi-person-workspace', 'primary') ?>
    <?= stat_card('Total bookings', $total, 'bi-calendar-check', 'info') ?>
    <?= stat_card('Completed / Settled', $done, 'bi-check-circle', 'success') ?>
    <?= stat_card('Open disputes', $openDisputes, 'bi-shield-exclamation', 'danger') ?>
    <?= stat_card('Net captured revenue', money($netRevenue), 'bi-cash-coin', 'success') ?>
</div>
<?php if ($pendProv): ?>
    <div class="alert alert-warning"><?= $pendProv ?> provider profile(s) awaiting verification.
        <a href="<?= url('admin/users/index.php?role=provider') ?>">Review Providers</a>
    </div>
<?php endif; ?>
<?php if ($openDisputes): ?>
    <div class="alert alert-danger"><?= $openDisputes ?> open dispute(s) require administrative attention.
        <a href="<?= url('admin/disputes/index.php') ?>">Investigate Disputes</a>
    </div>
<?php endif; ?>
<h4>Recent Bookings</h4>
<?php bookings_table($recent, 'admin'); ?>
<?php require INC . '/footer.php'; ?>
