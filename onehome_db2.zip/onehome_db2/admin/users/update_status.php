<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
post_only();
$adm = current_user();
$uid = (int) ($_POST['id'] ?? 0);
$x = db_one(
    "SELECT u.* FROM users u LEFT JOIN admins a ON a.user_id = u.user_id WHERE u.user_id = ? AND a.admin_id IS NULL",
    [$uid]
);
$status = in_array($_POST['status'] ?? '', ['active', 'suspended', 'inactive'], true) ? $_POST['status'] : 'active';
if (!$x) {
    flash('User not found.', 'danger');
    redirect('admin/users/index.php');
}
db_exec("UPDATE users SET account_status = ? WHERE user_id = ?", [$status, $uid]);
audit_log($adm['user_id'], 'user', $uid, 'account_status_' . $status, 'Updated account status to ' . $status);
flash('Account status updated to ' . $status . '.');
$backRole = ($_POST['back_role'] ?? '') === 'provider' ? 'provider' : 'customer';
redirect('admin/users/index.php?role=' . $backRole);
