<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
post_only();
$u = current_user();
$provId = (int) ($_POST['id'] ?? 0);
$decision = in_array($_POST['decision'] ?? 'verified', ['verified', 'rejected', 'suspended'], true) ? $_POST['decision'] : 'verified';
$p = db_one("SELECT * FROM providers WHERE provider_id = ?", [$provId]);
if (!$p) {
    flash('Provider profile not found.', 'danger');
    redirect('admin/users/index.php?role=provider');
}
db_exec("UPDATE providers SET verification_status = ? WHERE provider_id = ?", [$decision, $provId]);
audit_log($u['user_id'], 'provider', $provId, 'verification_' . $decision, 'Provider ' . $p['business_name']);
notify_user($p['user_id'], 'Provider Verification ' . ucfirst($decision), 'Your provider profile "' . $p['business_name'] . '" is now ' . $decision . '.', 'employee/dashboard.php');
flash('Provider verification updated to ' . $decision . '.');
redirect('admin/users/index.php?role=provider');
