<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Manage Users & Providers';
$role = ($_GET['role'] ?? '') === 'provider' || ($_GET['role'] ?? '') === 'employee' ? 'provider' : 'customer';

if ($role === 'provider') {
    $rows = db_all(
        "SELECT u.*, p.provider_id, p.business_name, p.verification_status, p.provider_status, p.service_area
         FROM providers p
         JOIN users u ON u.user_id = p.user_id
         ORDER BY (p.verification_status = 'pending') DESC, u.full_name"
    );
} else {
    $rows = db_all(
        "SELECT u.*, c.customer_id, c.username
         FROM customers c
         JOIN users u ON u.user_id = c.user_id
         ORDER BY u.full_name"
    );
}
require INC . '/header.php'; ?>
<h2>Manage Users &amp; Profiles</h2>
<div class="mb-3">
    <a class="btn btn-sm <?= $role === 'customer' ? 'btn-dark' : 'btn-outline-dark' ?>" href="index.php?role=customer">Customers</a>
    <a class="btn btn-sm <?= $role === 'provider' ? 'btn-dark' : 'btn-outline-dark' ?>" href="index.php?role=provider">
        Service Providers <?php if (pending_employees_count()): ?><span class="badge bg-danger"><?= pending_employees_count() ?> pending</span><?php endif; ?>
    </a>
</div>
<div class="table-responsive">
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light">
            <tr>
                <th>Name</th>
                <?php if ($role === 'provider'): ?><th>Business</th><?php endif; ?>
                <th>Email</th>
                <th>Phone</th>
                <th>Joined</th>
                <th>Account</th>
                <?php if ($role === 'provider'): ?><th>Verification</th><?php endif; ?>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $x): ?>
                <tr>
                    <td><?= e($x['full_name']) ?></td>
                    <?php if ($role === 'provider'): ?>
                        <td><?= e($x['business_name']) ?><br><small class="text-muted"><?= e($x['service_area']) ?></small></td>
                    <?php endif; ?>
                    <td><?= e($x['email']) ?></td>
                    <td><?= e($x['phone']) ?></td>
                    <td><?= fdate($x['created_at']) ?></td>
                    <td><?= badge($x['account_status']) ?></td>
                    <?php if ($role === 'provider'): ?><td><?= badge($x['verification_status']) ?></td><?php endif; ?>
                    <td>
                        <a class="btn btn-sm btn-outline-primary" href="view.php?id=<?= (int) $x['user_id'] ?>">View</a>
                        <?php if ($role === 'provider' && $x['verification_status'] === 'pending'): ?>
                            <form method="post" action="approve_employee.php" class="d-inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $x['provider_id'] ?>">
                                <input type="hidden" name="decision" value="verified">
                                <button class="btn btn-sm btn-success">Verify</button>
                            </form>
                            <form method="post" action="approve_employee.php" class="d-inline" data-confirm="Reject this provider application?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $x['provider_id'] ?>">
                                <input type="hidden" name="decision" value="rejected">
                                <button class="btn btn-sm btn-outline-danger">Reject</button>
                            </form>
                        <?php endif; ?>
                        <?php if ($x['account_status'] === 'active'): ?>
                            <form method="post" action="update_status.php" class="d-inline" data-confirm="Suspend this account?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $x['user_id'] ?>">
                                <input type="hidden" name="status" value="suspended">
                                <input type="hidden" name="back_role" value="<?= $role ?>">
                                <button class="btn btn-sm btn-danger">Suspend</button>
                            </form>
                        <?php else: ?>
                            <form method="post" action="update_status.php" class="d-inline">
                                <?= csrf_field() ?>
                                <input type="hidden" name="id" value="<?= (int) $x['user_id'] ?>">
                                <input type="hidden" name="status" value="active">
                                <input type="hidden" name="back_role" value="<?= $role ?>">
                                <button class="btn btn-sm btn-success">Activate</button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php require INC . '/footer.php'; ?>
