<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$uid = (int) ($_GET['id'] ?? 0);
$x = db_one(
    "SELECT u.*, c.customer_id, c.username, p.provider_id, p.business_name, p.verification_status, p.provider_status, p.skills, p.service_area, p.available_days
     FROM users u
     LEFT JOIN customers c ON c.user_id = u.user_id
     LEFT JOIN providers p ON p.user_id = u.user_id
     LEFT JOIN admins a ON a.user_id = u.user_id
     WHERE u.user_id = ? AND a.admin_id IS NULL",
    [$uid]
);
if (!$x) {
    flash('User not found.', 'danger');
    redirect('admin/users/index.php');
}
$title = 'User Details';
$addresses = !empty($x['customer_id']) ? db_all("SELECT * FROM addresses WHERE customer_id = ?", [$x['customer_id']]) : [];
$offerings = !empty($x['provider_id']) ? db_all("SELECT so.*, sc.category_name FROM service_offerings so JOIN service_categories sc ON sc.category_id = so.category_id WHERE so.provider_id = ?", [$x['provider_id']]) : [];
$custBookings = !empty($x['customer_id']) ? list_bookings("sr.customer_id = ?", [$x['customer_id']]) : [];
$provBookings = !empty($x['provider_id']) ? list_bookings("q.provider_id = ?", [$x['provider_id']]) : [];
require INC . '/header.php'; ?>
<h2><?= e($x['full_name']) ?> <?= badge($x['account_status']) ?></h2>
<table class="table table-bordered bg-white" style="max-width:750px">
    <tr><th width="30%">User ID</th><td>#<?= (int) $x['user_id'] ?> (Role flag: <?= e($x['user_role']) ?>)</td></tr>
    <tr><th>Email</th><td><?= e($x['email']) ?></td></tr>
    <tr><th>Phone</th><td><?= e($x['phone']) ?></td></tr>
    <tr><th>Joined</th><td><?= fdatetime($x['created_at']) ?></td></tr>
    <?php if (!empty($x['customer_id'])): ?>
        <tr><th>Customer Profile</th><td>#<?= (int) $x['customer_id'] ?> (<?= e($x['username'] ?: '-') ?>)</td></tr>
    <?php endif; ?>
    <?php if (!empty($x['provider_id'])): ?>
        <tr><th>Provider Profile</th><td>#<?= (int) $x['provider_id'] ?> &mdash; <?= e($x['business_name']) ?> <?= badge($x['verification_status']) ?> <?= badge($x['provider_status']) ?></td></tr>
        <tr><th>Service Area &amp; Days</th><td><?= e($x['service_area']) ?> &middot; <?= e($x['available_days']) ?></td></tr>
        <tr><th>Skills</th><td><?= e($x['skills'] ?: '-') ?></td></tr>
    <?php endif; ?>
</table>

<?php if ($addresses): ?>
    <h5>Customer Addresses</h5>
    <ul><?php foreach ($addresses as $a): ?><li><?= e(($a['address_label'] ? $a['address_label'] . ': ' : '') . $a['street_address'] . ', ' . $a['city'] . ', ' . $a['province']) ?></li><?php endforeach; ?></ul>
<?php endif; ?>

<?php if ($offerings): ?>
    <h5>Provider Offerings</h5>
    <ul><?php foreach ($offerings as $o): ?><li><?= e($o['title']) ?> (<?= e($o['category_name']) ?> &middot; <?= badge($o['pricing_type']) ?> <?= badge($o['offering_status']) ?>)</li><?php endforeach; ?></ul>
<?php endif; ?>

<?php if ($custBookings): ?>
    <h4 class="mt-3">Customer Bookings (<?= count($custBookings) ?>)</h4>
    <?php bookings_table($custBookings, 'admin'); ?>
<?php endif; ?>
<?php if ($provBookings): ?>
    <h4 class="mt-3">Provider Bookings (<?= count($provBookings) ?>)</h4>
    <?php bookings_table($provBookings, 'admin'); ?>
<?php endif; ?>

<a class="btn btn-secondary" href="index.php?role=<?= !empty($x['provider_id']) ? 'provider' : 'customer' ?>">Back</a>
<?php require INC . '/footer.php'; ?>
