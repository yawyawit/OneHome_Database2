<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Manage Disputes';
$statuses = ['open', 'under_review', 'resolved', 'rejected'];
$st = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';

$rows = db_all(
    "SELECT d.*, b.booking_status, b.agreed_price, sc.category_name, op.full_name AS opener_name, cu.full_name AS cname, pr.business_name
     FROM disputes d
     JOIN bookings b ON b.booking_id = d.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN customers c ON c.customer_id = sr.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     JOIN providers pr ON pr.provider_id = q.provider_id
     JOIN users op ON op.user_id = d.opened_by_user_id
     WHERE (? = '' OR d.dispute_status = ?)
     ORDER BY (d.dispute_status IN ('open','under_review')) DESC, d.created_at DESC",
    [$st, $st]
);
require INC . '/header.php'; ?>
<h2>Disputes &amp; Resolutions</h2>
<div class="mb-3">
    <a class="btn btn-sm <?= $st ? 'btn-outline-dark' : 'btn-dark' ?>" href="index.php">All</a>
    <?php foreach ($statuses as $s): ?>
        <a class="btn btn-sm <?= $st === $s ? 'btn-dark' : 'btn-outline-dark' ?>" href="index.php?status=<?= $s ?>"><?= ucwords(str_replace('_', ' ', $s)) ?></a>
    <?php endforeach; ?>
</div>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No disputes found.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped bg-white align-middle">
            <thead class="table-light"><tr><th>#</th><th>Booking</th><th>Parties</th><th>Opened By</th><th>Reason</th><th>Status</th><th>Created</th><th></th></tr></thead>
            <tbody>
                <?php foreach ($rows as $d): ?>
                    <tr>
                        <td>#<?= (int) $d['dispute_id'] ?></td>
                        <td>#<?= (int) $d['booking_id'] ?> <?= e($d['category_name']) ?><br><?= badge($d['booking_status']) ?></td>
                        <td><?= e($d['cname']) ?> vs <?= e($d['business_name']) ?></td>
                        <td><?= e($d['opener_name']) ?></td>
                        <td class="small"><?= e(mb_strimwidth($d['reason'], 0, 70, '...')) ?></td>
                        <td><?= badge($d['dispute_status']) ?></td>
                        <td><?= fdatetime($d['created_at']) ?></td>
                        <td><a class="btn btn-sm btn-outline-primary" href="view.php?id=<?= (int) $d['dispute_id'] ?>">Investigate</a></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
