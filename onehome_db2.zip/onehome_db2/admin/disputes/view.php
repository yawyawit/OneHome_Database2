<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$u = current_user();
$did = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$d = db_one(
    "SELECT d.*, op.full_name AS opener_name, op.email AS opener_email
     FROM disputes d JOIN users op ON op.user_id = d.opened_by_user_id
     WHERE d.dispute_id = ?",
    [$did]
);
if (!$d) {
    flash('Dispute not found.', 'danger');
    redirect('admin/disputes/index.php');
}
$b = get_booking((int) $d['booking_id']);
$fin = booking_financials($b['booking_id'], $b['agreed_price']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $newStatus = in_array($_POST['dispute_status'] ?? '', ['under_review', 'resolved', 'rejected'], true) ? $_POST['dispute_status'] : '';
    $resolution = trim($_POST['resolution'] ?? '');
    $bookingOutcome = $_POST['booking_outcome'] ?? '';

    if (!$newStatus) {
        flash('Invalid dispute status.', 'danger');
        redirect('admin/disputes/view.php?id=' . $did);
    }
    if ($newStatus === 'resolved' && $resolution === '') {
        flash('Resolved disputes require written resolution details (BR-50).', 'danger');
        redirect('admin/disputes/view.php?id=' . $did);
    }

    $conn->beginTransaction();
    $resolvedAt = in_array($newStatus, ['resolved', 'rejected'], true) ? date('Y-m-d H:i:s') : null;
    db_exec(
        "UPDATE disputes SET dispute_status = ?, resolution = ?, resolved_at = ? WHERE dispute_id = ?",
        [$newStatus, $resolution ?: null, $resolvedAt, $did]
    );

    if (in_array($bookingOutcome, ['completed', 'settled', 'refunded'], true) && can_transition_booking($b['booking_status'], $bookingOutcome)) {
        db_exec("UPDATE bookings SET booking_status = ? WHERE booking_id = ?", [$bookingOutcome, $b['booking_id']]);
    }

    audit_log($u['user_id'], 'dispute', $did, 'dispute_' . $newStatus, 'Booking #' . $b['booking_id'] . '; resolution=' . $resolution);
    notify_user($b['customer_user_id'], 'Dispute #' . $did . ' ' . ucwords(str_replace('_', ' ', $newStatus)), $resolution ?: 'Status updated by admin.', 'customer/disputes.php');
    notify_user($b['provider_user_id'], 'Dispute #' . $did . ' ' . ucwords(str_replace('_', ' ', $newStatus)), $resolution ?: 'Status updated by admin.', 'employee/disputes.php');
    $conn->commit();

    flash('Dispute #' . $did . ' updated to ' . $newStatus . '.');
    redirect('admin/disputes/view.php?id=' . $did);
}

$title = 'Dispute #' . $did;
require INC . '/header.php'; ?>
<h2>Dispute #<?= $did ?> <?= badge($d['dispute_status']) ?></h2>
<div class="card mb-3">
    <div class="card-body">
        <p class="mb-1"><b>Opened By:</b> <?= e($d['opener_name']) ?> (<?= e($d['opener_email']) ?>) on <?= fdatetime($d['created_at']) ?></p>
        <p class="mb-1"><b>Reason:</b> <?= nl2br(e($d['reason'])) ?></p>
        <?php if ($d['resolution']): ?>
            <p class="mb-0 text-success"><b>Resolution:</b> <?= nl2br(e($d['resolution'])) ?> (<?= fdatetime($d['resolved_at']) ?>)</p>
        <?php endif; ?>
    </div>
</div>

<h5>Related Booking &amp; Financials</h5>
<?php booking_info($b); ?>

<form method="post" class="card card-body mb-3" style="max-width:650px">
    <?= csrf_field() ?>
    <input type="hidden" name="id" value="<?= $did ?>">
    <h5 class="mb-3">Update Investigation / Resolution</h5>
    <div class="row">
        <div class="col-md-6 mb-2">
            <label class="form-label">Dispute Status</label>
            <select name="dispute_status" class="form-select">
                <option value="under_review" <?= $d['dispute_status'] === 'under_review' ? 'selected' : '' ?>>Under Review</option>
                <option value="resolved" <?= $d['dispute_status'] === 'resolved' ? 'selected' : '' ?>>Resolved</option>
                <option value="rejected" <?= $d['dispute_status'] === 'rejected' ? 'selected' : '' ?>>Rejected</option>
            </select>
        </div>
        <div class="col-md-6 mb-2">
            <label class="form-label">Booking Outcome (optional)</label>
            <select name="booking_outcome" class="form-select">
                <option value="">Keep current (<?= e($b['booking_status']) ?>)</option>
                <?php foreach (['completed', 'settled', 'refunded'] as $bo): ?>
                    <?php if (can_transition_booking($b['booking_status'], $bo)): ?>
                        <option value="<?= $bo ?>"><?= ucfirst($bo) ?></option>
                    <?php endif; ?>
                <?php endforeach; ?>
            </select>
        </div>
    </div>
    <label class="form-label">Resolution Details (required when marking Resolved)</label>
    <textarea name="resolution" rows="3" class="form-control mb-3"><?= e($d['resolution'] ?? '') ?></textarea>
    <div class="d-flex gap-2">
        <button class="btn btn-primary">Save Decision</button>
        <a class="btn btn-outline-danger" href="<?= url('admin/payments/view.php?booking_id=' . (int) $b['booking_id']) ?>">Open Payment Ledger (for Refund)</a>
        <a class="btn btn-secondary" href="index.php">Back</a>
    </div>
</form>
<?php require INC . '/footer.php'; ?>
