<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
post_only();
$id = (int) ($_POST['id'] ?? 0);
$used = (int) db_val("SELECT COUNT(*) FROM service_offerings WHERE category_id = ?", [$id])
      + (int) db_val("SELECT COUNT(*) FROM service_requests WHERE category_id = ?", [$id]);
if ($used > 0) {
    db_exec("UPDATE service_categories SET category_status = 'inactive' WHERE category_id = ?", [$id]);
    flash('This category has linked offerings or requests, so it was deactivated instead of deleted.', 'info');
} else {
    db_exec("DELETE FROM service_categories WHERE category_id = ?", [$id]);
    flash('Service category removed.');
}
redirect('admin/services/index.php');
