<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$id = (int) ($_GET['id'] ?? 0);
$s = db_one("SELECT * FROM service_categories WHERE category_id = ?", [$id]);
if (!$s) {
    flash('Service category not found.', 'danger');
    redirect('admin/services/index.php');
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['category_name'] ?? '');
    $price = $_POST['default_price'] ?? '';
    if ($name === '' || !is_numeric($price) || (float) $price < 0) {
        flash('Please fill in the category name and a valid non-negative price.', 'danger');
        redirect('admin/services/edit.php?id=' . $id);
    }
    $status = isset($_POST['is_active']) ? 'active' : 'inactive';
    db_exec(
        "UPDATE service_categories SET category_name = ?, description = ?, default_price = ?, icon = ?, category_status = ? WHERE category_id = ?",
        [$name, trim($_POST['description'] ?? ''), (float) $price, $_POST['icon'] ?? 'bi-tools', $status, $id]
    );
    flash('Service category updated.');
    redirect('admin/services/index.php');
}
$title = 'Edit Service Category';
require INC . '/header.php'; ?>
<h2>Edit Service Category</h2>
<div style="max-width:600px"><?php service_form($s); ?></div>
<?php require INC . '/footer.php'; ?>
