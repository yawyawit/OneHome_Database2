<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $name = trim($_POST['category_name'] ?? '');
    $price = $_POST['default_price'] ?? '';
    if ($name === '' || !is_numeric($price) || (float) $price < 0) {
        flash('Please fill in the category name and a valid non-negative price.', 'danger');
        redirect('admin/services/add.php');
    }
    db_exec(
        "INSERT INTO service_categories (category_name, description, default_price, icon, category_status) VALUES (?, ?, ?, ?, 'active')",
        [$name, trim($_POST['description'] ?? ''), (float) $price, $_POST['icon'] ?? 'bi-tools']
    );
    flash('Service category added.');
    redirect('admin/services/index.php');
}
$title = 'Add Service Category';
require INC . '/header.php'; ?>
<h2>Add Service Category</h2>
<div style="max-width:600px"><?php service_form(); ?></div>
<?php require INC . '/footer.php'; ?>
