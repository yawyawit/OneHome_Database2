<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Manage Service Categories';
$rows = db_all(
    "SELECT sc.*,
            (SELECT COUNT(*) FROM service_offerings so WHERE so.category_id = sc.category_id) AS offerings_cnt,
            (SELECT COUNT(*) FROM service_requests sr WHERE sr.category_id = sc.category_id) AS requests_cnt
     FROM service_categories sc
     ORDER BY sc.category_name"
);
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center">
    <h2>Service Categories</h2>
    <a class="btn btn-primary" href="add.php"><i class="bi bi-plus-lg"></i> Add Category</a>
</div>
<table class="table table-striped bg-white align-middle mt-3">
    <thead class="table-light">
        <tr><th></th><th>Category</th><th>Description</th><th>Default Price</th><th>Offerings / Requests</th><th>Status</th><th>Actions</th></tr>
    </thead>
    <tbody>
        <?php foreach ($rows as $s): ?>
            <tr>
                <td><i class="bi <?= e($s['icon']) ?> fs-4"></i></td>
                <td class="fw-semibold"><?= e($s['category_name']) ?></td>
                <td class="small"><?= e($s['description']) ?></td>
                <td><?= money($s['default_price']) ?></td>
                <td><?= (int) $s['offerings_cnt'] ?> offerings / <?= (int) $s['requests_cnt'] ?> requests</td>
                <td><?= badge($s['category_status']) ?></td>
                <td>
                    <a class="btn btn-sm btn-outline-primary" href="edit.php?id=<?= (int) $s['category_id'] ?>">Edit</a>
                    <form method="post" action="delete.php" class="d-inline" data-confirm="Remove or deactivate this category?">
                        <?= csrf_field() ?>
                        <input type="hidden" name="id" value="<?= (int) $s['category_id'] ?>">
                        <button class="btn btn-sm btn-danger">Remove</button>
                    </form>
                </td>
            </tr>
        <?php endforeach; ?>
    </tbody>
</table>
<p class="small text-muted">Categories linked to offerings or historical requests are deactivated rather than deleted so historical transactions stay intact.</p>
<?php require INC . '/footer.php'; ?>
