<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Manage Bookings';
$statuses = ['pending_confirmation', 'payment_failed', 'confirmed', 'rescheduled', 'in_progress', 'completed', 'settled', 'disputed', 'cancelled', 'refunded'];
$st = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';
$rows = $st ? list_bookings('b.booking_status = ?', [$st]) : list_bookings();
require INC . '/header.php'; ?>
<h2>All Bookings</h2>
<div class="mb-3 d-flex flex-wrap gap-1">
    <a class="btn btn-sm <?= $st ? 'btn-outline-dark' : 'btn-dark' ?>" href="index.php">All (<?= (int) db_val("SELECT COUNT(*) FROM bookings") ?>)</a>
    <?php foreach ($statuses as $s): ?>
        <a class="btn btn-sm <?= $st === $s ? 'btn-dark' : 'btn-outline-dark' ?>" href="index.php?status=<?= $s ?>">
            <?= ucwords(str_replace('_', ' ', $s)) ?> (<?= (int) db_val("SELECT COUNT(*) FROM bookings WHERE booking_status = ?", [$s]) ?>)
        </a>
    <?php endforeach; ?>
</div>
<?php bookings_table($rows, 'admin'); ?>
<?php require INC . '/footer.php'; ?>
