<?php require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$u = current_user();
$bookingId = (int) ($_GET['id'] ?? $_POST['id'] ?? 0);
$b = get_booking($bookingId);
if (!$b) {
    flash('Booking not found.', 'danger');
    redirect('admin/bookings/index.php');
}
$allowedNext = booking_allowed_transitions()[$b['booking_status']] ?? [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $target = $_POST['status'] ?? '';
    if (!can_transition_booking($b['booking_status'], $target)) {
        flash('Invalid state transition from ' . $b['booking_status'] . ' to ' . $target . ' (BR-51).', 'danger');
        redirect('admin/bookings/view.php?id=' . $bookingId);
    }
    $extraSql = $target === 'completed' && empty($b['completed_at']) ? ', completed_at = NOW()' : '';
    db_exec("UPDATE bookings SET booking_status = ? $extraSql WHERE booking_id = ?", [$target, $bookingId]);
    audit_log($u['user_id'], 'booking', $bookingId, 'admin_status_transition', $b['booking_status'] . ' -> ' . $target);
    flash('Booking status transitioned to ' . $target . '.');
    redirect('admin/bookings/view.php?id=' . $bookingId);
}

$review = db_one("SELECT * FROM reviews WHERE booking_id = ?", [$bookingId]);
$fin = booking_financials($bookingId, $b['agreed_price']);
$title = 'Booking #' . $bookingId;
require INC . '/header.php'; ?>
<h2>Booking #<?= $bookingId ?></h2>
<?php booking_info($b); ?>
<?php if ($review): ?>
    <div class="card mb-3">
        <div class="card-body"><b>Customer Review:</b> <?= stars($review['rating']) ?> &mdash; <?= e($review['comment']) ?></div>
    </div>
<?php endif; ?>

<?php if ($allowedNext): ?>
    <form method="post" class="card card-body mb-3" style="max-width:500px" data-confirm="Apply this permitted state transition?">
        <?= csrf_field() ?>
        <input type="hidden" name="id" value="<?= $bookingId ?>">
        <label class="form-label">Permitted State Transitions (from <?= badge($b['booking_status']) ?>)</label>
        <div class="input-group">
            <select name="status" class="form-select">
                <?php foreach ($allowedNext as $s): ?>
                    <option value="<?= e($s) ?>"><?= ucwords(str_replace('_', ' ', $s)) ?></option>
                <?php endforeach; ?>
            </select>
            <button class="btn btn-primary">Transition</button>
        </div>
        <small class="text-muted mt-1">State machine rules prevent bypassing valid lifecycle transitions.</small>
    </form>
<?php else: ?>
    <div class="alert alert-secondary" style="max-width:500px">Booking is in terminal state <?= badge($b['booking_status']) ?>.</div>
<?php endif; ?>

<a class="btn btn-outline-primary" href="<?= url('admin/payments/view.php?booking_id=' . $bookingId) ?>">Payment Ledger</a>
<a class="btn btn-outline-success" href="<?= url('admin/payouts/index.php') ?>">Manage Payouts</a>
<a class="btn btn-secondary" href="index.php">Back</a>
<?php require INC . '/footer.php'; ?>
