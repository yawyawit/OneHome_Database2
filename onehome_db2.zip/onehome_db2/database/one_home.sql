-- One Home database (Aligned with System Anatomical Outline, ERD, and Business Rules)
-- Import this in phpMyAdmin or via mysql CLI.
-- All demo accounts use the password: password

CREATE DATABASE IF NOT EXISTS one_home CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE one_home;

SET FOREIGN_KEY_CHECKS = 0;
DROP TRIGGER IF EXISTS trg_quote_insert;
DROP TRIGGER IF EXISTS trg_booking_insert;
DROP TRIGGER IF EXISTS trg_booking_update;
DROP TRIGGER IF EXISTS trg_review_insert;
DROP TRIGGER IF EXISTS trg_payout_insert;
DROP TRIGGER IF EXISTS trg_dispute_update;
DROP TABLE IF EXISTS
  audit_logs,
  notifications,
  disputes,
  reviews,
  payouts,
  payments,
  bookings,
  quotes,
  service_requests,
  addresses,
  service_offerings,
  service_categories,
  admins,
  providers,
  customers,
  users,
  employee_services,
  services;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USER (Shared Identity)
CREATE TABLE users (
  user_id INT AUTO_INCREMENT PRIMARY KEY,
  full_name VARCHAR(120) NOT NULL,
  first_name VARCHAR(60) NULL,
  last_name VARCHAR(60) NULL,
  email VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  phone VARCHAR(30) NULL,
  account_status ENUM('active','suspended','inactive') NOT NULL DEFAULT 'active',
  user_role ENUM('admin','provider','customer','multi') NOT NULL DEFAULT 'customer',
  avatar VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- 2. CUSTOMER (Customer Profile - 1:0..1 with User)
CREATE TABLE customers (
  customer_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  username VARCHAR(60) NULL UNIQUE,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_customer_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 3. PROVIDER (Service Provider Profile - 1:0..1 with User)
CREATE TABLE providers (
  provider_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  business_name VARCHAR(120) NOT NULL,
  verification_status ENUM('pending','verified','rejected','suspended') NOT NULL DEFAULT 'pending',
  provider_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  skills VARCHAR(255) NULL,
  service_area VARCHAR(120) NOT NULL DEFAULT 'Baguio City',
  available_days VARCHAR(40) NOT NULL DEFAULT 'Mon,Tue,Wed,Thu,Fri',
  is_available TINYINT(1) NOT NULL DEFAULT 1,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_provider_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 4. ADMIN (Admin Profile - 1:0..1 with User)
CREATE TABLE admins (
  admin_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL UNIQUE,
  admin_level ENUM('super','operations','support') NOT NULL DEFAULT 'super',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_admin_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 5. SERVICE_CATEGORY (Catalog Categories)
CREATE TABLE service_categories (
  category_id INT AUTO_INCREMENT PRIMARY KEY,
  category_name VARCHAR(100) NOT NULL UNIQUE,
  description TEXT NULL,
  icon VARCHAR(50) NOT NULL DEFAULT 'bi-tools',
  default_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  category_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  CONSTRAINT chk_category_default_price CHECK (default_price >= 0)
) ENGINE=InnoDB;

-- 6. SERVICE_OFFERING (Provider-specific offerings under categories)
CREATE TABLE service_offerings (
  offering_id INT AUTO_INCREMENT PRIMARY KEY,
  provider_id INT NOT NULL,
  category_id INT NOT NULL,
  title VARCHAR(120) NOT NULL,
  description TEXT NULL,
  pricing_type ENUM('fixed','quotation') NOT NULL DEFAULT 'quotation',
  base_price DECIMAL(10,2) NULL,
  offering_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_offering_provider (offering_id, provider_id),
  UNIQUE KEY uq_offering_provider_cat (offering_id, provider_id, category_id),
  CONSTRAINT chk_offering_base_price CHECK (base_price IS NULL OR base_price >= 0),
  CONSTRAINT chk_offering_fixed_price CHECK (pricing_type <> 'fixed' OR (base_price IS NOT NULL AND base_price >= 0)),
  CONSTRAINT fk_offering_provider FOREIGN KEY (provider_id) REFERENCES providers(provider_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_offering_category FOREIGN KEY (category_id) REFERENCES service_categories(category_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 7. ADDRESS (Customer service locations)
CREATE TABLE addresses (
  address_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  address_label VARCHAR(60) NULL,
  street_address VARCHAR(255) NOT NULL,
  city VARCHAR(100) NOT NULL DEFAULT 'Baguio City',
  province VARCHAR(100) NOT NULL DEFAULT 'Benguet',
  postal_code VARCHAR(20) NULL,
  latitude DECIMAL(10,7) NULL,
  longitude DECIMAL(10,7) NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_address_customer (address_id, customer_id),
  CONSTRAINT fk_address_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 8. SERVICE_REQUEST (Customer demand)
CREATE TABLE service_requests (
  request_id INT AUTO_INCREMENT PRIMARY KEY,
  customer_id INT NOT NULL,
  category_id INT NOT NULL,
  address_id INT NOT NULL,
  preferred_offering_id INT NULL,
  service_snapshot_title VARCHAR(120) NULL,
  service_snapshot_price DECIMAL(10,2) NULL,
  description TEXT NOT NULL,
  photo VARCHAR(255) NULL,
  preferred_start DATETIME NULL,
  request_status ENUM('open','matching','booked','cancelled','closed') NOT NULL DEFAULT 'open',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_request_customer (request_id, customer_id),
  CONSTRAINT fk_request_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_request_category FOREIGN KEY (category_id) REFERENCES service_categories(category_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_request_address_customer FOREIGN KEY (address_id, customer_id) REFERENCES addresses(address_id, customer_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_request_preferred_offering FOREIGN KEY (preferred_offering_id) REFERENCES service_offerings(offering_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 9. QUOTE (Provider proposals for a request)
CREATE TABLE quotes (
  quote_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL,
  provider_id INT NOT NULL,
  offering_id INT NOT NULL,
  proposed_price DECIMAL(10,2) NOT NULL,
  scope TEXT NOT NULL,
  valid_until DATETIME NOT NULL,
  proposed_start DATETIME NULL,
  proposed_end DATETIME NULL,
  quote_status ENUM('pending','accepted','rejected','expired','withdrawn') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY uq_quote_request (quote_id, request_id),
  CONSTRAINT chk_quote_price CHECK (proposed_price >= 0),
  CONSTRAINT chk_quote_times CHECK (proposed_end IS NULL OR proposed_start IS NULL OR proposed_end > proposed_start),
  CONSTRAINT fk_quote_request FOREIGN KEY (request_id) REFERENCES service_requests(request_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_quote_offering_provider FOREIGN KEY (offering_id, provider_id) REFERENCES service_offerings(offering_id, provider_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 10. BOOKING (Agreed service transaction from accepted quote; customer & provider derived via request & quote)
CREATE TABLE bookings (
  booking_id INT AUTO_INCREMENT PRIMARY KEY,
  request_id INT NOT NULL UNIQUE,
  quote_id INT NOT NULL UNIQUE,
  agreed_price DECIMAL(10,2) NOT NULL,
  scheduled_start DATETIME NOT NULL,
  scheduled_end DATETIME NOT NULL,
  booking_status ENUM('pending_confirmation','confirmed','in_progress','rescheduled','completed','cancelled','disputed','settled','refunded','payment_failed') NOT NULL DEFAULT 'confirmed',
  cancellation_reason VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  CONSTRAINT chk_booking_price CHECK (agreed_price >= 0),
  CONSTRAINT chk_booking_duration CHECK (scheduled_end > scheduled_start),
  CONSTRAINT fk_booking_request FOREIGN KEY (request_id) REFERENCES service_requests(request_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_booking_quote_request FOREIGN KEY (quote_id, request_id) REFERENCES quotes(quote_id, request_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 11. PAYMENT (Financial ledger - multiple records per booking)
CREATE TABLE payments (
  payment_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'PHP',
  payment_type ENUM('authorization','capture','refund','adjustment') NOT NULL,
  payment_status ENUM('pending','successful','failed','reversed') NOT NULL DEFAULT 'pending',
  method ENUM('cash','card') NOT NULL DEFAULT 'cash',
  card_last4 CHAR(4) NULL,
  gateway_reference VARCHAR(100) NULL UNIQUE,
  notes VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_payment_amount CHECK (amount >= 0),
  CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 12. PAYOUT (Provider compensation ledger)
CREATE TABLE payouts (
  payout_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  provider_id INT NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  platform_fee DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  payout_status ENUM('pending','processing','paid','failed','reversed') NOT NULL DEFAULT 'pending',
  gateway_reference VARCHAR(100) NULL UNIQUE,
  notes VARCHAR(255) NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  paid_at DATETIME NULL,
  CONSTRAINT chk_payout_amount CHECK (amount >= 0),
  CONSTRAINT chk_payout_fee CHECK (platform_fee >= 0),
  CONSTRAINT fk_payout_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_payout_provider FOREIGN KEY (provider_id) REFERENCES providers(provider_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 13. REVIEW (At most one review per completed booking by its customer)
CREATE TABLE reviews (
  review_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL UNIQUE,
  customer_id INT NOT NULL,
  rating TINYINT NOT NULL,
  comment TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5),
  CONSTRAINT fk_review_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_review_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 14. DISPUTE (Accountability records; multiple allowed per booking)
CREATE TABLE disputes (
  dispute_id INT AUTO_INCREMENT PRIMARY KEY,
  booking_id INT NOT NULL,
  opened_by_user_id INT NOT NULL,
  reason TEXT NOT NULL,
  dispute_status ENUM('open','under_review','resolved','rejected') NOT NULL DEFAULT 'open',
  resolution TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME NULL,
  CONSTRAINT fk_dispute_booking FOREIGN KEY (booking_id) REFERENCES bookings(booking_id) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT fk_dispute_user FOREIGN KEY (opened_by_user_id) REFERENCES users(user_id) ON DELETE RESTRICT ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 15. NOTIFICATIONS (Persistent inbox for FR-11)
CREATE TABLE notifications (
  notification_id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  title VARCHAR(120) NOT NULL,
  message TEXT NOT NULL,
  link VARCHAR(255) NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 16. AUDIT_LOGS (Financial & critical operational audit trail)
CREATE TABLE audit_logs (
  audit_id INT AUTO_INCREMENT PRIMARY KEY,
  actor_user_id INT NULL,
  entity_type VARCHAR(40) NOT NULL,
  entity_id INT NOT NULL,
  action VARCHAR(60) NOT NULL,
  details TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_audit_actor FOREIGN KEY (actor_user_id) REFERENCES users(user_id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB;

-- ---------- Database-level Integrity Triggers ----------
DELIMITER //

CREATE TRIGGER trg_quote_insert BEFORE INSERT ON quotes
FOR EACH ROW
BEGIN
  DECLARE v_req_cat INT;
  DECLARE v_req_status VARCHAR(20);
  DECLARE v_off_cat INT;
  DECLARE v_off_status VARCHAR(20);
  DECLARE v_prov_ver VARCHAR(20);
  DECLARE v_prov_status VARCHAR(20);

  SELECT category_id, request_status INTO v_req_cat, v_req_status
  FROM service_requests WHERE request_id = NEW.request_id;

  SELECT so.category_id, so.offering_status, p.verification_status, p.provider_status
  INTO v_off_cat, v_off_status, v_prov_ver, v_prov_status
  FROM service_offerings so
  JOIN providers p ON p.provider_id = so.provider_id
  WHERE so.offering_id = NEW.offering_id AND so.provider_id = NEW.provider_id;

  IF v_req_status NOT IN ('open', 'matching') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quotes can only be submitted for open or matching requests.';
  END IF;
  IF v_off_cat IS NULL OR v_off_cat <> v_req_cat THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Quote offering must match the requested service category.';
  END IF;
  IF v_off_status <> 'active' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Cannot submit a quote against an inactive service offering.';
  END IF;
  IF v_prov_ver <> 'verified' OR v_prov_status <> 'active' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Only verified active providers may submit quotes.';
  END IF;
END//

CREATE TRIGGER trg_booking_insert BEFORE INSERT ON bookings
FOR EACH ROW
BEGIN
  DECLARE v_quote_status VARCHAR(20);
  DECLARE v_valid_until DATETIME;
  DECLARE v_provider_id INT;
  DECLARE v_overlap INT DEFAULT 0;

  SELECT quote_status, valid_until, provider_id
  INTO v_quote_status, v_valid_until, v_provider_id
  FROM quotes WHERE quote_id = NEW.quote_id AND request_id = NEW.request_id;

  IF v_quote_status <> 'accepted' THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A booking must originate from an accepted quote.';
  END IF;
  IF v_valid_until < NEW.created_at THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'An expired quote cannot be booked.';
  END IF;

  IF NEW.booking_status IN ('confirmed', 'in_progress', 'rescheduled') THEN
    SELECT COUNT(*) INTO v_overlap
    FROM bookings b
    JOIN quotes q ON q.quote_id = b.quote_id
    WHERE q.provider_id = v_provider_id
      AND b.booking_status IN ('confirmed', 'in_progress', 'rescheduled')
      AND b.scheduled_start < NEW.scheduled_end
      AND b.scheduled_end > NEW.scheduled_start;
    IF v_overlap > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Provider has an overlapping confirmed booking for this time slot.';
    END IF;
  END IF;
END//

CREATE TRIGGER trg_booking_update BEFORE UPDATE ON bookings
FOR EACH ROW
BEGIN
  DECLARE v_provider_id INT;
  DECLARE v_overlap INT DEFAULT 0;

  IF NEW.booking_status IN ('confirmed', 'in_progress', 'rescheduled') THEN
    SELECT provider_id INTO v_provider_id FROM quotes WHERE quote_id = NEW.quote_id;
    SELECT COUNT(*) INTO v_overlap
    FROM bookings b
    JOIN quotes q ON q.quote_id = b.quote_id
    WHERE q.provider_id = v_provider_id
      AND b.booking_id <> NEW.booking_id
      AND b.booking_status IN ('confirmed', 'in_progress', 'rescheduled')
      AND b.scheduled_start < NEW.scheduled_end
      AND b.scheduled_end > NEW.scheduled_start;
    IF v_overlap > 0 THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Provider has an overlapping confirmed booking for this time slot.';
    END IF;
  END IF;
END//

CREATE TRIGGER trg_review_insert BEFORE INSERT ON reviews
FOR EACH ROW
BEGIN
  DECLARE v_bstatus VARCHAR(30);
  DECLARE v_cust_id INT;

  SELECT b.booking_status, sr.customer_id
  INTO v_bstatus, v_cust_id
  FROM bookings b
  JOIN service_requests sr ON sr.request_id = b.request_id
  WHERE b.booking_id = NEW.booking_id;

  IF v_bstatus NOT IN ('completed', 'settled') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Reviews can only be submitted for completed or settled bookings.';
  END IF;
  IF v_cust_id <> NEW.customer_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Review author must match the booking customer.';
  END IF;
END//

CREATE TRIGGER trg_payout_insert BEFORE INSERT ON payouts
FOR EACH ROW
BEGIN
  DECLARE v_prov_id INT;
  SELECT q.provider_id INTO v_prov_id
  FROM bookings b
  JOIN quotes q ON q.quote_id = b.quote_id
  WHERE b.booking_id = NEW.booking_id;

  IF v_prov_id IS NULL OR v_prov_id <> NEW.provider_id THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Payout provider must match the booking provider.';
  END IF;
END//

CREATE TRIGGER trg_dispute_update BEFORE UPDATE ON disputes
FOR EACH ROW
BEGIN
  IF NEW.dispute_status = 'resolved' AND (NEW.resolution IS NULL OR TRIM(NEW.resolution) = '') THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'A resolved dispute must include resolution details.';
  END IF;
END//

DELIMITER ;

-- ---------- Demo Data (password for all accounts: password) ----------
INSERT INTO users (user_id, full_name, first_name, last_name, email, password_hash, phone, account_status, user_role) VALUES
(1, 'Admin User', 'Admin', 'User', 'admin@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-000-0001', 'active', 'admin'),
(2, 'Juan Dela Cruz', 'Juan', 'Dela Cruz', 'juan@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-111-1111', 'active', 'provider'),
(3, 'Maria Santos', 'Maria', 'Santos', 'maria@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-222-2222', 'active', 'provider'),
(4, 'Pedro Bautista', 'Pedro', 'Bautista', 'pedro@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-333-3333', 'active', 'provider'),
(5, 'Ana Reyes', 'Ana', 'Reyes', 'ana@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-444-4444', 'active', 'multi'),
(6, 'Carlo Mendoza', 'Carlo', 'Mendoza', 'carlo@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0917-555-5555', 'active', 'provider'),
(7, 'Liza Ramos', 'Liza', 'Ramos', 'liza@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0918-666-6666', 'active', 'customer'),
(8, 'Mark Villanueva', 'Mark', 'Villanueva', 'mark@onehome.test', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', '0918-777-7777', 'active', 'customer');

INSERT INTO admins (admin_id, user_id, admin_level) VALUES
(1, 1, 'super');

INSERT INTO customers (customer_id, user_id, username) VALUES
(1, 7, 'liza_ramos'),
(2, 8, 'mark_v'),
(3, 5, 'ana_reyes');

INSERT INTO providers (provider_id, user_id, business_name, verification_status, provider_status, skills, service_area, available_days, is_available) VALUES
(1, 2, 'Juan Plumbing & Paint Works', 'verified', 'active', 'Pipe repair, leak fixing, water heater installation', 'Baguio City', 'Mon,Tue,Wed,Thu,Fri,Sat', 1),
(2, 3, 'Maria Electrical & Appliances', 'verified', 'active', 'Wiring, outlets, lighting, appliance repair', 'Baguio City', 'Mon,Tue,Wed,Thu,Fri', 1),
(3, 4, 'Pedro Green & Clean', 'verified', 'active', 'Deep cleaning, garden care', 'Baguio City', 'Tue,Wed,Thu,Fri,Sat,Sun', 1),
(4, 5, 'Ana Home Care Solutions', 'verified', 'active', 'Plumbing, cleaning, pest control', 'Baguio City', 'Mon,Wed,Fri,Sat,Sun', 1),
(5, 6, 'Carlo Mendoza Plumbing', 'pending', 'active', 'Plumber (new applicant)', 'Baguio City', 'Mon,Tue,Wed,Thu,Fri', 1);

INSERT INTO addresses (address_id, customer_id, address_label, street_address, city, province, postal_code, is_default) VALUES
(1, 1, 'Home', '14 Session Road', 'Baguio City', 'Benguet', '2600', 1),
(2, 1, 'Rental Unit', '88 Leonard Wood Road', 'Baguio City', 'Benguet', '2600', 0),
(3, 2, 'Home', '22 Camp 7', 'Baguio City', 'Benguet', '2600', 1),
(4, 3, 'Home', '45 Loakan Road', 'Baguio City', 'Benguet', '2600', 1);

INSERT INTO service_categories (category_id, category_name, description, icon, default_price, category_status) VALUES
(1, 'Plumbing', 'Leaks, clogged drains, faucet and toilet repair, pipe installation.', 'bi-droplet-fill', 500.00, 'active'),
(2, 'Electrical Services', 'Wiring, outlets, switches, lighting and circuit breaker problems.', 'bi-lightning-charge-fill', 600.00, 'active'),
(3, 'House Cleaning', 'General and deep cleaning for your whole house.', 'bi-stars', 800.00, 'active'),
(4, 'Appliance Repair', 'Washing machine, refrigerator, TV and other appliance repair.', 'bi-wrench-adjustable', 450.00, 'active'),
(5, 'Pest Control', 'Termite, cockroach, rat and ant treatment.', 'bi-bug-fill', 700.00, 'active'),
(6, 'Painting', 'Interior and exterior wall painting.', 'bi-paint-bucket', 1200.00, 'active'),
(7, 'Gardening', 'Lawn mowing, plant care and garden clean-up.', 'bi-flower1', 400.00, 'active');

INSERT INTO service_offerings (offering_id, provider_id, category_id, title, description, pricing_type, base_price, offering_status) VALUES
(1, 1, 1, 'Standard Plumbing Repair', 'Pipe leaks, faucet replacement, and drain unclogging.', 'fixed', 500.00, 'active'),
(2, 1, 6, 'Room & Wall Repainting', 'Interior wall preparation and 2-coat painting.', 'quotation', 1200.00, 'active'),
(3, 2, 2, 'Electrical Troubleshooting & Outlets', 'Outlet repair, breaker check, and lighting fixture installation.', 'fixed', 600.00, 'active'),
(4, 2, 4, 'Home Appliance Diagnostics & Repair', 'Washing machine, refrigerator, and small appliance repair.', 'fixed', 450.00, 'active'),
(5, 3, 3, 'Whole-House Deep Cleaning', 'Thorough sanitizing and deep cleaning for multi-room homes.', 'quotation', 800.00, 'active'),
(6, 3, 7, 'Lawn & Garden Maintenance', 'Trimming, weeding, and yard clean-up.', 'fixed', 400.00, 'active'),
(7, 4, 1, 'Emergency Leak & Drain Service', 'Fast residential plumbing inspection and repair.', 'quotation', 550.00, 'active'),
(8, 4, 3, 'Express Home Cleaning', 'General home tidying and surface cleaning.', 'fixed', 750.00, 'active'),
(9, 4, 5, 'Residential Pest Treatment', 'Safe cockroach, ant, and termite control.', 'quotation', 700.00, 'active'),
(10, 5, 1, 'General Plumbing Assistance', 'Basic plumbing repairs and fixture checks.', 'fixed', 500.00, 'active');

INSERT INTO service_requests (request_id, customer_id, category_id, address_id, preferred_offering_id, service_snapshot_title, service_snapshot_price, description, preferred_start, request_status, created_at) VALUES
(1, 1, 1, 1, 1, 'Standard Plumbing Repair', 500.00, 'Kitchen sink is leaking under the P-trap.', '2026-08-12 09:00:00', 'matching', '2026-08-11 10:00:00'),
(2, 1, 2, 1, 3, 'Electrical Troubleshooting & Outlets', 600.00, 'Outlet in the living room sparks when plugged in.', '2026-09-05 10:00:00', 'matching', '2026-09-04 08:30:00'),
(3, 2, 1, 3, 1, 'Standard Plumbing Repair', 500.00, 'Clogged bathroom drain.', '2026-09-20 14:00:00', 'matching', '2026-09-19 09:15:00'),
(4, 2, 3, 3, NULL, 'House Cleaning', 800.00, 'Deep cleaning of a 2-storey house before family move-in.', '2026-12-05 09:00:00', 'matching', '2026-11-26 11:00:00'),
(5, 1, 4, 1, 4, 'Home Appliance Diagnostics & Repair', 450.00, 'Washing machine will not spin during rinse cycle.', '2026-12-02 13:00:00', 'matching', '2026-11-25 14:00:00'),
(6, 1, 1, 2, NULL, 'Plumbing', 500.00, 'Water pressure in second-floor shower is very low.', '2026-12-08 10:00:00', 'open', '2026-11-27 09:00:00');

INSERT INTO quotes (quote_id, request_id, provider_id, offering_id, proposed_price, scope, valid_until, proposed_start, proposed_end, quote_status, created_at) VALUES
(1, 1, 1, 1, 500.00, 'Replace leaking sink P-trap washer and seal joints.', '2026-08-12 18:00:00', '2026-08-12 09:00:00', '2026-08-12 11:00:00', 'accepted', '2026-08-11 11:00:00'),
(2, 2, 2, 3, 600.00, 'Inspect living room outlet, replace receptacle, and test breaker.', '2026-09-05 18:00:00', '2026-09-05 10:00:00', '2026-09-05 12:00:00', 'accepted', '2026-09-04 09:00:00'),
(3, 3, 1, 1, 500.00, 'Snake bathroom drain and flush line.', '2026-09-20 18:00:00', '2026-09-20 14:00:00', '2026-09-20 16:00:00', 'accepted', '2026-09-19 10:00:00'),
(4, 4, 3, 5, 950.00, 'Full 2-storey deep clean (3 bedrooms, kitchen, 2 baths) with eco supplies.', '2026-12-04 18:00:00', '2026-12-05 09:00:00', '2026-12-05 13:00:00', 'pending', '2026-11-26 13:00:00'),
(5, 4, 4, 8, 850.00, 'Express 2-storey general cleaning and bathroom sanitization.', '2026-12-04 18:00:00', '2026-12-05 09:00:00', '2026-12-05 12:00:00', 'pending', '2026-11-26 15:00:00'),
(6, 5, 2, 4, 450.00, 'Diagnose washing machine spin motor/belt and test run.', '2026-12-02 18:00:00', '2026-12-02 13:00:00', '2026-12-02 15:00:00', 'accepted', '2026-11-25 16:00:00');

INSERT INTO bookings (booking_id, request_id, quote_id, agreed_price, scheduled_start, scheduled_end, booking_status, created_at, completed_at) VALUES
(1, 1, 1, 500.00, '2026-08-12 09:00:00', '2026-08-12 11:00:00', 'settled', '2026-08-11 12:00:00', '2026-08-12 10:45:00'),
(2, 2, 2, 600.00, '2026-09-05 10:00:00', '2026-09-05 12:00:00', 'settled', '2026-09-04 10:00:00', '2026-09-05 11:50:00'),
(3, 3, 3, 500.00, '2026-09-20 14:00:00', '2026-09-20 16:00:00', 'completed', '2026-09-19 11:00:00', '2026-09-20 15:30:00'),
(4, 5, 6, 450.00, '2026-12-02 13:00:00', '2026-12-02 15:00:00', 'confirmed', '2026-11-25 17:00:00', NULL);

UPDATE service_requests SET request_status = 'booked' WHERE request_id IN (1, 2, 3, 5);

INSERT INTO payments (payment_id, booking_id, amount, currency, payment_type, payment_status, method, card_last4, gateway_reference, notes, created_at) VALUES
(1, 1, 500.00, 'PHP', 'capture', 'successful', 'cash', NULL, 'CASH-BK1-001', 'Cash collected by provider after service', '2026-08-12 11:00:00'),
(2, 2, 600.00, 'PHP', 'authorization', 'successful', 'card', '4242', 'AUTH-BK2-001', 'Simulated card authorization', '2026-09-05 12:25:00'),
(3, 2, 600.00, 'PHP', 'capture', 'successful', 'card', '4242', 'CAP-BK2-001', 'Simulated card capture', '2026-09-05 12:30:00'),
(4, 4, 450.00, 'PHP', 'authorization', 'pending', 'card', NULL, NULL, 'Awaiting completion for capture', '2026-11-25 17:00:00');

INSERT INTO payouts (payout_id, booking_id, provider_id, amount, platform_fee, payout_status, gateway_reference, notes, created_at, paid_at) VALUES
(1, 1, 1, 450.00, 50.00, 'paid', 'PO-BK1-001', '90% provider share settled', '2026-08-12 12:00:00', '2026-08-13 09:00:00'),
(2, 2, 2, 540.00, 60.00, 'paid', 'PO-BK2-001', '90% provider share settled', '2026-09-05 13:00:00', '2026-09-06 09:00:00');

INSERT INTO reviews (review_id, booking_id, customer_id, rating, comment, created_at) VALUES
(1, 1, 1, 5, 'Fast and clean work. Fixed our leaking sink in one hour!', '2026-08-12 14:00:00'),
(2, 2, 1, 4, 'Good service, a little late but the work was great.', '2026-09-05 15:00:00');

INSERT INTO notifications (user_id, title, message, link, is_read) VALUES
(7, 'Plumbing Request Open', 'Your Plumbing request (#6) is open for provider quotes.', 'customer/request_details.php?id=6', 0),
(8, '2 Quotes Awaiting Your Review', 'Pedro Green & Clean and Ana Home Care Solutions submitted quotes for Request #4 (House Cleaning).', 'customer/request_details.php?id=4', 0),
(2, 'New Open Plumbing Request', 'A new Plumbing request (#6) is open in Baguio City.', 'employee/booking_requests.php', 0),
(1, 'Pending Provider Verification', 'Carlo Mendoza Plumbing is awaiting verification.', 'admin/users/index.php?role=provider', 0);

INSERT INTO audit_logs (actor_user_id, entity_type, entity_id, action, details) VALUES
(1, 'payout', 1, 'payout_paid', 'Initial settled payout PO-BK1-001 for Booking #1'),
(1, 'payout', 2, 'payout_paid', 'Initial settled payout PO-BK2-001 for Booking #2');
