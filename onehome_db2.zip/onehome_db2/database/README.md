# Database Notes (`one_home`)

Database name: `one_home`. Import `database/one_home.sql` in phpMyAdmin or via `mysql.exe`. **Importing again resets all data** (`DROP TABLE IF EXISTS`).

## Schema Entities (Aligned with ERD & Business Rules)
1. `users` — Shared identity (`user_id`, `full_name`, `first_name`, `last_name`, `email` UQ, `password_hash`, `phone`, `account_status`, `user_role`, `avatar`, `created_at`)
2. `customers` — Customer profile (`customer_id`, `user_id` FK UQ, `username` UQ)
3. `providers` — Provider profile (`provider_id`, `user_id` FK UQ, `business_name`, `verification_status`, `provider_status`, `skills`, `service_area`, `available_days`, `is_available`)
4. `admins` — Admin profile (`admin_id`, `user_id` FK UQ, `admin_level`)
5. `service_categories` — Catalog categories (`category_id`, `category_name` UQ, `description`, `icon`, `default_price`, `category_status`)
6. `service_offerings` — Provider offerings (`offering_id`, `provider_id` FK, `category_id` FK, `title`, `pricing_type` `fixed`/`quotation`, `base_price`, `offering_status`)
7. `addresses` — Customer service locations (`address_id`, `customer_id` FK, `address_label`, `street_address`, `city`, `province`, `postal_code`, `latitude`, `longitude`, `is_default`)
8. `service_requests` — Customer demand (`request_id`, `customer_id` FK, `category_id` FK, `address_id` FK, `preferred_offering_id` FK, snapshot fields, `description`, `preferred_start`, `request_status`)
9. `quotes` — Provider proposals (`quote_id`, `request_id` FK, `provider_id` FK, `offering_id` FK, `proposed_price`, `scope`, `valid_until`, `proposed_start`, `proposed_end`, `quote_status`)
10. `bookings` — Confirmed agreements (`booking_id`, `request_id` FK UQ, `quote_id` FK UQ, `agreed_price`, `scheduled_start`, `scheduled_end`, `booking_status`, `completed_at`)
11. `payments` — Payment ledger (`payment_id`, `booking_id` FK, `amount`, `currency`, `payment_type` `authorization`/`capture`/`refund`/`adjustment`, `payment_status`, `method`, `card_last4`, `gateway_reference` UQ)
12. `payouts` — Provider compensation ledger (`payout_id`, `booking_id` FK, `provider_id` FK, `amount`, `platform_fee`, `payout_status`, `gateway_reference` UQ, `paid_at`)
13. `reviews` — Customer reviews (`review_id`, `booking_id` FK UQ, `customer_id` FK, `rating` 1..5, `comment`)
14. `disputes` — Dispute cases (`dispute_id`, `booking_id` FK, `opened_by_user_id` FK, `reason`, `dispute_status`, `resolution`, `resolved_at`)
15. `notifications` — Persistent user inbox (`notification_id`, `user_id` FK, `title`, `message`, `link`, `is_read`)
16. `audit_logs` — Operational and financial audit trail (`audit_id`, `actor_user_id` FK, `entity_type`, `entity_id`, `action`, `details`)

## Enforced Database Constraints & Triggers
- Composite FKs:
  - `service_requests(address_id, customer_id)` -> `addresses(address_id, customer_id)`
  - `quotes(offering_id, provider_id)` -> `service_offerings(offering_id, provider_id)`
  - `bookings(quote_id, request_id)` -> `quotes(quote_id, request_id)`
- Check Constraints: non-negative prices/payments/payouts, fixed-price offering requires non-negative `base_price`, `scheduled_end > scheduled_start`, `rating BETWEEN 1 AND 5`.
- Triggers:
  - `trg_quote_insert`: ensures request is open/matching, offering matches category & is active, provider is verified & active.
  - `trg_booking_insert` & `trg_booking_update`: ensures accepted non-expired quote & prevents overlapping confirmed/in-progress/rescheduled provider bookings.
  - `trg_review_insert`: ensures review author matches booking customer and booking is completed/settled.
  - `trg_payout_insert`: ensures payout provider matches booking provider.
  - `trg_dispute_update`: requires non-empty `resolution` when dispute is marked `resolved`.
