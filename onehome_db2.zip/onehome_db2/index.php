<?php
require_once __DIR__ . '/includes/auth.php';
$u = current_user();
if ($u && $u['status'] === 'active')
    redirect(home_for($u['role']));
$title = 'Home';
$services = db_all("SELECT * FROM service_categories WHERE category_status='active' ORDER BY category_name");
require INC . '/header.php'; ?>
<div class="hero text-center p-4 p-md-5 mb-5">
    <div class="oh-hero-eyebrow"><i class="bi bi-geo-alt-fill"></i> Baguio City &middot; Home Service Booking</div>
    <h1 class="display-5 mb-3">Warm, Reliable Care for Your Home</h1>
    <p class="lead mb-4">Book vetted local specialists for plumbing, electrical, deep cleaning, repairs, and more &mdash; scheduled around your day.</p>
    <div class="d-flex flex-wrap justify-content-center gap-3">
        <a class="btn btn-light btn-lg px-4" href="<?= url('register.php') ?>"><i class="bi bi-stars me-1"></i> Get Started</a>
        <a class="btn btn-outline-light btn-lg px-4" href="<?= url('login.php') ?>">Login</a>
    </div>
</div>

<div class="row g-3 mb-5">
    <div class="col-md-4">
        <div class="card oh-stat-card h-100">
            <div class="card-body d-flex align-items-start gap-3">
                <span class="oh-stat-icon"><i class="bi bi-grid-1x2-fill"></i></span>
                <div>
                    <h6 class="mb-1">1. Pick a Service</h6>
                    <p class="small text-muted mb-0">Transparent starting rates for everyday home repairs and upkeep.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card oh-stat-card oh-accent-warning h-100">
            <div class="card-body d-flex align-items-start gap-3">
                <span class="oh-stat-icon"><i class="bi bi-person-check-fill"></i></span>
                <div>
                    <h6 class="mb-1">2. Choose Your Pro</h6>
                    <p class="small text-muted mb-0">Compare ratings, skills, and real-time schedule availability.</p>
                </div>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card oh-stat-card oh-accent-success h-100">
            <div class="card-body d-flex align-items-start gap-3">
                <span class="oh-stat-icon"><i class="bi bi-shield-check"></i></span>
                <div>
                    <h6 class="mb-1">3. Relax &amp; Pay Securely</h6>
                    <p class="small text-muted mb-0">Pay in cash after completion or settle online by card.</p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h3 class="mb-0">Our Services</h3>
    <span class="badge bg-warning">Trusted Local Pros</span>
</div>
<div class="row"><?php foreach ($services as $s)
    echo service_card($s, false); ?></div>
<?php require INC . '/footer.php'; ?>
