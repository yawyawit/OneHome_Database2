<?php
require_once __DIR__ . '/includes/auth.php';
$u = current_user();
if ($u && $u['account_status'] === 'active' && !empty($u['available_roles'])) {
    redirect(home_for($u['role']));
}
$title = 'Register';
$categories = db_all("SELECT * FROM service_categories WHERE category_status='active' ORDER BY category_name");
require INC . '/header.php'; ?>
<div class="row justify-content-center py-2">
    <div class="col-md-8 col-lg-7">
        <div class="card">
            <div class="card-body p-4 p-md-5">
                <div class="mb-4">
                    <h3 class="mb-1">Create an Account</h3>
                    <p class="small text-muted mb-0">Join One Home as a customer, a service provider, or both</p>
                </div>
                <form method="post" action="<?= url('actions/process_register.php') ?>">
                    <?= csrf_field() ?>
                    <label class="form-label">I am registering as</label>
                    <select name="role" id="role" class="form-select mb-3">
                        <option value="customer">Customer (Homeowner)</option>
                        <option value="employee">Service Provider</option>
                        <option value="both">Both Customer &amp; Service Provider</option>
                    </select>
                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Full Name</label>
                            <input name="name" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Contact Number</label>
                            <input name="phone" class="form-control" placeholder="09XX-XXX-XXXX" required>
                        </div>
                    </div>
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control mb-3" required>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Street Address</label>
                            <input name="street_address" class="form-control" placeholder="House #, Street, Barangay" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">City</label>
                            <input name="city" class="form-control" value="Baguio City" required>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label class="form-label">Province</label>
                            <input name="province" class="form-control" value="Benguet" required>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Password (min. 6 characters)</label>
                            <input type="password" name="password" minlength="6" class="form-control" required>
                        </div>
                        <div class="col-md-6 mb-3">
                            <label class="form-label">Confirm Password</label>
                            <input type="password" name="confirm" class="form-control" required>
                        </div>
                    </div>

                    <div id="emp-fields" style="display:none">
                        <div class="alert alert-info">Provider profiles must be verified by an admin before accepting jobs or submitting quotes.</div>
                        <div class="row">
                            <div class="col-md-7 mb-3">
                                <label class="form-label">Business / Display Name</label>
                                <input name="business_name" class="form-control" placeholder="e.g. Juan Plumbing Works">
                            </div>
                            <div class="col-md-5 mb-3">
                                <label class="form-label">Service Area</label>
                                <input name="service_area" class="form-control" value="Baguio City">
                            </div>
                        </div>
                        <label class="form-label">Your skills</label>
                        <input name="skills" class="form-control mb-3" placeholder="e.g. pipe repair, leak fixing">
                        <label class="form-label">Service categories you offer</label>
                        <div class="mb-3">
                            <?php foreach ($categories as $s): ?>
                                <div class="form-check">
                                    <input class="form-check-input" type="checkbox" name="services[]" value="<?= (int) $s['category_id'] ?>" id="s<?= (int) $s['category_id'] ?>">
                                    <label class="form-check-label" for="s<?= (int) $s['category_id'] ?>"><?= e($s['category_name']) ?></label>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <button class="btn btn-primary w-100 py-2 mt-1">Register</button>
                </form>
                <p class="mt-4 mb-0 text-center small text-muted">Already have an account? <a class="fw-semibold" href="<?= url('login.php') ?>">Login</a></p>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var r = document.getElementById('role');
    var e = document.getElementById('emp-fields');
    if (r && e) {
        var sync = function () { e.style.display = (r.value === 'employee' || r.value === 'both') ? 'block' : 'none'; };
        r.addEventListener('change', sync);
        sync();
    }
});
</script>
<?php require INC . '/footer.php'; ?>
