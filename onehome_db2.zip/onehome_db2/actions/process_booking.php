<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
flash('Please submit a service request so verified providers can send you a quote to confirm.', 'info');
redirect('customer/request_service.php');
