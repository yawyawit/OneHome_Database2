<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
post_only();

$u = current_user();
$provId = (int) $u['provider_id'];
$reqId = (int) ($_POST['request_id'] ?? 0);
$offeringId = (int) ($_POST['offering_id'] ?? 0);
$price = $_POST['proposed_price'] ?? '';
$scope = trim($_POST['scope'] ?? '');
$validUntilStr = trim($_POST['valid_until'] ?? '');
$startStr = trim($_POST['proposed_start'] ?? '');
$endStr = trim($_POST['proposed_end'] ?? '');
$back = 'employee/booking_requests.php';

$sr = get_request($reqId);
if (!$sr || !in_array($sr['request_status'], ['open', 'matching'], true)) {
    flash('This service request is no longer open for quotes.', 'danger');
    redirect($back);
}

$off = db_one(
    "SELECT * FROM service_offerings
     WHERE offering_id = ? AND provider_id = ? AND category_id = ? AND offering_status = 'active'",
    [$offeringId, $provId, (int) $sr['category_id']]
);
if (!$off) {
    flash('You must select one of your active offerings in the requested category.', 'danger');
    redirect($back);
}

if (!is_numeric($price) || (float) $price < 0) {
    flash('Proposed price must be a valid non-negative number.', 'danger');
    redirect($back);
}
if ($scope === '') {
    flash('Please describe the scope of work for your quote.', 'danger');
    redirect($back);
}

$validTs = strtotime($validUntilStr);
if (!$validTs || $validTs <= time()) {
    flash('Quote expiration (valid until) must be in the future.', 'danger');
    redirect($back);
}

$propStart = null;
$propEnd = null;
if ($startStr !== '' || $endStr !== '') {
    $st = strtotime($startStr);
    $en = strtotime($endStr);
    if (!$st || !$en || $en <= $st) {
        flash('Proposed end time must be after proposed start time.', 'danger');
        redirect($back);
    }
    $propStart = date('Y-m-d H:i:s', $st);
    $propEnd = date('Y-m-d H:i:s', $en);
    if (!provider_free($provId, $propStart, $propEnd)) {
        flash('Warning: you already have an overlapping confirmed booking during that proposed window.', 'danger');
        redirect($back);
    }
}

$conn->beginTransaction();
$dup = (int) db_val(
    "SELECT COUNT(*) FROM quotes WHERE request_id = ? AND provider_id = ? AND quote_status = 'pending'",
    [$reqId, $provId]
);
if ($dup > 0) {
    $conn->rollBack();
    flash('You already have a pending quote for Request #' . $reqId . '. Withdraw it first if you want to revise.', 'warning');
    redirect('employee/my_quotes.php');
}

$quoteId = (int) db_exec(
    "INSERT INTO quotes (request_id, provider_id, offering_id, proposed_price, scope, valid_until, proposed_start, proposed_end, quote_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')",
    [$reqId, $provId, $offeringId, (float) $price, $scope, date('Y-m-d H:i:s', $validTs), $propStart, $propEnd]
);

if ($sr['request_status'] === 'open') {
    db_exec("UPDATE service_requests SET request_status = 'matching' WHERE request_id = ? AND request_status = 'open'", [$reqId]);
}

audit_log($u['user_id'], 'quote', $quoteId, 'quote_submitted', 'Request #' . $reqId . ' price=' . $price);
notify_user(
    $sr['customer_user_id'],
    'New Quote Received for Request #' . $reqId,
    $u['business_name'] . ' submitted a quote of ' . money($price) . ' for ' . $sr['category_name'] . '.',
    'customer/request_details.php?id=' . $reqId
);
$conn->commit();

flash('Quote #' . $quoteId . ' submitted to ' . $sr['customer_name'] . '!');
redirect('employee/my_quotes.php');
