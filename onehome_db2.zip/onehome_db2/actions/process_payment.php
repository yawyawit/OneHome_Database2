<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$bookingId = (int) ($_POST['booking_id'] ?? 0);
$b = get_booking($bookingId);

if (!$b || (int) $b['customer_id'] !== (int) $u['customer_id']) {
    flash('Booking not found.', 'danger');
    redirect('customer/bookings.php');
}

$action = $_POST['action'] ?? '';
$fin = booking_financials($bookingId, $b['agreed_price']);

if ($action === 'retry_auth' && $b['booking_status'] === 'payment_failed') {
    $num = preg_replace('/\D/', '', $_POST['card_number'] ?? '');
    if (trim($_POST['card_name'] ?? '') === '' || strlen($num) !== 16 || !preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $_POST['expiry'] ?? '') || !preg_match('/^\d{3,4}$/', $_POST['cvv'] ?? '')) {
        flash('Please enter valid card details to retry authorization.', 'danger');
        redirect('customer/booking_details.php?id=' . $bookingId);
    }
    $last4 = substr($num, -4);
    $ok = $last4 !== '0000';
    $ref = 'AUTH-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    $conn->beginTransaction();
    db_exec(
        "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, card_last4, gateway_reference, notes)
         VALUES (?, ?, 'PHP', 'authorization', ?, 'card', ?, ?, ?)",
        [$bookingId, $b['agreed_price'], $ok ? 'successful' : 'failed', $last4, $ref, $ok ? 'Retry card authorization succeeded' : 'Retry card authorization failed']
    );
    if ($ok) {
        db_exec("UPDATE bookings SET booking_status = 'confirmed' WHERE booking_id = ? AND booking_status = 'payment_failed'", [$bookingId]);
    }
    audit_log($u['user_id'], 'payment', $bookingId, $ok ? 'auth_retry_succeeded' : 'auth_retry_failed', 'Ref: ' . $ref);
    $conn->commit();
    flash($ok ? 'Authorization succeeded! Booking confirmed.' : 'Card authorization still failed.', $ok ? 'success' : 'danger');
    redirect('customer/booking_details.php?id=' . $bookingId);
}

if (!in_array($b['booking_status'], ['completed', 'settled'], true) || $fin['balance_due'] <= 0) {
    flash('This booking is not eligible for payment capture.', 'danger');
    redirect('customer/bookings.php');
}

if ($action === 'cash') {
    db_exec(
        "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, notes)
         VALUES (?, ?, 'PHP', 'authorization', 'pending', 'cash', 'Customer selected cash payment after completion')",
        [$bookingId, $fin['balance_due']]
    );
    flash('Cash payment selected. Please pay ' . money($fin['balance_due']) . ' to ' . $b['provider_business_name'] . ' so they can record receipt.', 'info');
    redirect('customer/payment.php?id=' . $bookingId);
}

if ($action !== 'card') {
    flash('Invalid payment action.', 'danger');
    redirect('customer/payment.php?id=' . $bookingId);
}

$num = preg_replace('/\D/', '', $_POST['card_number'] ?? '');
$err = '';
if (trim($_POST['card_name'] ?? '') === '') {
    $err = 'Please enter the name on the card.';
} elseif (strlen($num) !== 16) {
    $err = 'Card number must be 16 digits.';
} elseif (!preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $_POST['expiry'] ?? '')) {
    $err = 'Expiry must look like MM/YY.';
} elseif (!preg_match('/^\d{3,4}$/', $_POST['cvv'] ?? '')) {
    $err = 'CVV must be 3 or 4 digits.';
}
if ($err) {
    flash($err, 'danger');
    redirect('customer/payment.php?id=' . $bookingId . '&method=card');
}

$last4 = substr($num, -4);
$conn->beginTransaction();
db_one("SELECT booking_id FROM bookings WHERE booking_id = ? FOR UPDATE", [$bookingId]);
$fin = booking_financials($bookingId, $b['agreed_price']);
if ($fin['balance_due'] <= 0) {
    $conn->rollBack();
    flash('This booking has already been fully paid.', 'warning');
    redirect('customer/bookings.php');
}

$captureAmount = $fin['balance_due']; // Enforces BR-39: never capture beyond agreed price
$ref = 'CAP-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
$payId = (int) db_exec(
    "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, card_last4, gateway_reference, notes)
     VALUES (?, ?, 'PHP', 'capture', 'successful', 'card', ?, ?, 'Simulated card payment capture')",
    [$bookingId, $captureAmount, $last4, $ref]
);

audit_log($u['user_id'], 'payment', $payId, 'payment_captured', 'Booking #' . $bookingId . ' amount=' . $captureAmount . ' ref=' . $ref);
notify_user($b['provider_user_id'], 'Payment Received for Booking #' . $bookingId, $u['full_name'] . ' paid ' . money($captureAmount) . ' by card.', 'employee/earnings.php');
$conn->commit();

redirect('customer/payment_success.php?id=' . $bookingId);
