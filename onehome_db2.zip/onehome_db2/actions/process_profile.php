<?php
require_once __DIR__ . '/../includes/auth.php';
require_roles(['admin', 'employee', 'customer']);
post_only();

$u = current_user();
$back = $u['role'] === 'admin' ? 'admin/profile.php' : ($u['role'] === 'employee' ? 'employee/edit_profile.php' : 'customer/edit_profile.php');
$a = $_POST['action'] ?? '';

if ($a === 'info') {
    $name = trim($_POST['name'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL) || !preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
        flash('Please enter a valid name, email, and contact number.', 'danger');
        redirect($back);
    }
    if ($email !== $u['email'] || $phone !== (string) $u['phone']) {
        if (!password_verify($_POST['current_password'] ?? '', $u['password_hash'])) {
            flash('Enter your current password to change your email or contact number.', 'danger');
            redirect($back);
        }
    }
    if ((int) db_val("SELECT COUNT(*) FROM users WHERE email = ? AND user_id <> ?", [$email, $u['user_id']]) > 0) {
        flash('That email is already used by another account.', 'danger');
        redirect($back);
    }
    $parts = preg_split('/\s+/', $name, 2);
    db_exec(
        "UPDATE users SET full_name = ?, first_name = ?, last_name = ?, email = ?, phone = ? WHERE user_id = ?",
        [$name, $parts[0] ?? $name, $parts[1] ?? '', $email, $phone, $u['user_id']]
    );
    flash('Identity information updated.');
} elseif ($a === 'password') {
    if (!password_verify($_POST['current_password'] ?? '', $u['password_hash'])) {
        flash('Current password is wrong.', 'danger');
    } elseif (strlen($_POST['new_password'] ?? '') < 6) {
        flash('New password must be at least 6 characters.', 'danger');
    } elseif (($_POST['new_password'] ?? '') !== ($_POST['confirm_password'] ?? '')) {
        flash('New passwords do not match.', 'danger');
    } else {
        db_exec("UPDATE users SET password_hash = ? WHERE user_id = ?", [password_hash($_POST['new_password'], PASSWORD_DEFAULT), $u['user_id']]);
        flash('Password changed.');
    }
} elseif ($a === 'employee' && !empty($u['provider_id'])) {
    $bName = trim($_POST['business_name'] ?? '') ?: $u['business_name'];
    $area = trim($_POST['service_area'] ?? '') ?: 'Baguio City';
    $skills = trim($_POST['skills'] ?? '');
    db_exec(
        "UPDATE providers SET business_name = ?, service_area = ?, skills = ? WHERE provider_id = ?",
        [$bName, $area, $skills, $u['provider_id']]
    );
    $pic = save_upload('avatar', 'images/profiles');
    if ($pic) {
        db_exec("UPDATE users SET avatar = ? WHERE user_id = ?", [$pic, $u['user_id']]);
    }
    flash('Provider profile updated. Manage your service offerings under Offerings.');
} elseif ($a === 'enable_customer' && empty($u['customer_id'])) {
    $username = strtolower(preg_replace('/[^a-z0-9]+/i', '_', $u['full_name'])) . '_' . $u['user_id'];
    db_exec("INSERT INTO customers (user_id, username) VALUES (?, ?)", [$u['user_id'], $username]);
    db_exec("UPDATE users SET user_role = 'multi' WHERE user_id = ? AND user_role = 'provider'", [$u['user_id']]);
    flash('Customer profile enabled! You can now switch between Provider and Customer workspaces.');
} elseif ($a === 'enable_provider' && empty($u['provider_id'])) {
    $bName = trim($_POST['business_name'] ?? '') ?: ($u['full_name'] . ' Services');
    db_exec(
        "INSERT INTO providers (user_id, business_name, verification_status, provider_status, service_area) VALUES (?, ?, 'pending', 'active', 'Baguio City')",
        [$u['user_id'], $bName]
    );
    db_exec("UPDATE users SET user_role = 'multi' WHERE user_id = ? AND user_role = 'customer'", [$u['user_id']]);
    foreach (db_all("SELECT user_id FROM admins") as $adm) {
        notify_user($adm['user_id'], 'Provider Profile Requested', $bName . ' requested provider verification.', 'admin/users/index.php?role=provider');
    }
    flash('Provider profile created and sent for admin verification.', 'info');
}

redirect($back);
