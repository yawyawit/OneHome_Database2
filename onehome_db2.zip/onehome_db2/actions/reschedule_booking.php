<?php
require_once __DIR__ . '/../includes/auth.php';
require_roles(['customer', 'employee']);
post_only();

$u = current_user();
$bookingId = (int) ($_POST['booking_id'] ?? 0);
$b = get_booking($bookingId);

$isCustomer = $u['role'] === 'customer' && $b && (int) $b['customer_id'] === (int) $u['customer_id'];
$isProvider = $u['role'] === 'employee' && $b && (int) $b['provider_id'] === (int) $u['provider_id'];
$back = $u['role'] === 'customer' ? 'customer/booking_details.php?id=' . $bookingId : 'employee/booking_details.php?id=' . $bookingId;

if (!$isCustomer && !$isProvider) {
    flash('Booking not found.', 'danger');
    redirect(home_for($u['role']));
}

if (!can_transition_booking($b['booking_status'], 'rescheduled')) {
    flash('This booking cannot be rescheduled in its current state.', 'danger');
    redirect($back);
}

$startTs = strtotime(trim($_POST['scheduled_start'] ?? ''));
$endTs = strtotime(trim($_POST['scheduled_end'] ?? ''));
if (!$startTs || !$endTs || $endTs <= $startTs || $startTs < time()) {
    flash('Please enter a valid future start and end time (end after start).', 'danger');
    redirect($back);
}

$newStart = date('Y-m-d H:i:s', $startTs);
$newEnd = date('Y-m-d H:i:s', $endTs);

$conn->beginTransaction();
db_one("SELECT provider_id FROM providers WHERE provider_id = ? FOR UPDATE", [(int) $b['provider_id']]);

if (!provider_free((int) $b['provider_id'], $newStart, $newEnd, $bookingId)) {
    $conn->rollBack();
    flash('That time slot overlaps with another confirmed booking for the provider.', 'danger');
    redirect($back);
}

db_exec(
    "UPDATE bookings SET scheduled_start = ?, scheduled_end = ?, booking_status = 'rescheduled' WHERE booking_id = ?",
    [$newStart, $newEnd, $bookingId]
);

audit_log($u['user_id'], 'booking', $bookingId, 'booking_rescheduled', 'From ' . $b['scheduled_start'] . ' to ' . $newStart . ' - ' . $newEnd);

$notifyTarget = $isCustomer ? $b['provider_user_id'] : $b['customer_user_id'];
$notifyLink = $isCustomer ? 'employee/booking_details.php?id=' . $bookingId : 'customer/booking_details.php?id=' . $bookingId;
notify_user($notifyTarget, 'Booking #' . $bookingId . ' Rescheduled', 'New schedule: ' . fdatetime($newStart) . ' - ' . ftime($newEnd), $notifyLink);

$conn->commit();

flash('Booking #' . $bookingId . ' rescheduled.');
redirect($back);
