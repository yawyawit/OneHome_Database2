<?php
require_once __DIR__ . '/../includes/auth.php';
require_roles(['admin', 'employee', 'customer']);
post_only();

$u = current_user();
$target = $_POST['role'] ?? '';
if (!in_array($target, $u['available_roles'], true)) {
    flash('You do not have access to that workspace role.', 'danger');
    redirect(home_for($u['role']));
}

$_SESSION['active_role'] = $target;
flash('Switched to ' . ($target === 'employee' ? 'Provider' : ucfirst($target)) . ' workspace.', 'info');
redirect(home_for($target));
