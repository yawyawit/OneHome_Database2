<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$custId = (int) $u['customer_id'];
$bookingId = (int) ($_POST['booking_id'] ?? 0);
$rating = (int) ($_POST['rating'] ?? 0);

$conn->beginTransaction();
db_one("SELECT booking_id FROM bookings WHERE booking_id = ? FOR UPDATE", [$bookingId]);
$b = get_booking($bookingId);

if (!$b || (int) $b['customer_id'] !== $custId || !in_array($b['booking_status'], ['completed', 'settled'], true)) {
    $conn->rollBack();
    flash('You can only review your own completed bookings.', 'danger');
    redirect('customer/bookings.php');
}
if ($b['reviewed']) {
    $conn->rollBack();
    flash('You already reviewed this booking.', 'warning');
    redirect('customer/my_reviews.php');
}
if ($rating < 1 || $rating > 5) {
    $conn->rollBack();
    flash('Please choose a rating from 1 to 5.', 'danger');
    redirect('customer/review.php?id=' . $bookingId);
}

db_exec(
    "INSERT INTO reviews (booking_id, customer_id, rating, comment) VALUES (?, ?, ?, ?)",
    [$bookingId, $custId, $rating, trim($_POST['comment'] ?? '')]
);
notify_user($b['provider_user_id'], 'New ' . $rating . '★ Review on Booking #' . $bookingId, $u['full_name'] . ' left a review for ' . $b['offering_title'] . '.', 'employee/my_reviews.php');
$conn->commit();

flash('Thank you for your review!');
redirect('customer/my_reviews.php');
