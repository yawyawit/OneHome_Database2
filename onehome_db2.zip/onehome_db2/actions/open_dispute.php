<?php
require_once __DIR__ . '/../includes/auth.php';
require_roles(['customer', 'employee']);
post_only();

$u = current_user();
$bookingId = (int) ($_POST['booking_id'] ?? 0);
$reason = trim($_POST['reason'] ?? '');
$b = get_booking($bookingId);

$isCustomer = $u['role'] === 'customer' && $b && (int) $b['customer_id'] === (int) $u['customer_id'];
$isProvider = $u['role'] === 'employee' && $b && (int) $b['provider_id'] === (int) $u['provider_id'];
$back = $u['role'] === 'customer' ? 'customer/booking_details.php?id=' . $bookingId : 'employee/booking_details.php?id=' . $bookingId;

if (!$isCustomer && !$isProvider) {
    flash('Booking not found.', 'danger');
    redirect(home_for($u['role']));
}
if ($reason === '') {
    flash('Please describe the issue or reason for the dispute.', 'danger');
    redirect($back);
}
if (!in_array($b['booking_status'], ['confirmed', 'rescheduled', 'in_progress', 'completed', 'disputed'], true)) {
    flash('A dispute cannot be opened for a booking in status: ' . $b['booking_status'] . '.', 'danger');
    redirect($back);
}

$conn->beginTransaction();
$disputeId = (int) db_exec(
    "INSERT INTO disputes (booking_id, opened_by_user_id, reason, dispute_status) VALUES (?, ?, ?, 'open')",
    [$bookingId, $u['user_id'], $reason]
);
if ($b['booking_status'] !== 'disputed') {
    db_exec("UPDATE bookings SET booking_status = 'disputed' WHERE booking_id = ?", [$bookingId]);
}
audit_log($u['user_id'], 'dispute', $disputeId, 'dispute_opened', 'Booking #' . $bookingId . ': ' . $reason);

foreach (db_all("SELECT user_id FROM admins") as $adm) {
    notify_user($adm['user_id'], 'New Dispute #' . $disputeId . ' (Booking #' . $bookingId . ')', $u['full_name'] . ' opened a dispute: ' . $reason, 'admin/disputes/view.php?id=' . $disputeId);
}
$otherUserId = $isCustomer ? $b['provider_user_id'] : $b['customer_user_id'];
notify_user($otherUserId, 'Dispute Opened on Booking #' . $bookingId, $u['full_name'] . ' opened dispute #' . $disputeId . '.', $isCustomer ? 'employee/disputes.php' : 'customer/disputes.php');
$conn->commit();

flash('Dispute #' . $disputeId . ' opened. An administrator will review it.');
redirect($u['role'] === 'customer' ? 'customer/disputes.php' : 'employee/disputes.php');
