<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$custId = (int) $u['customer_id'];
$quoteId = (int) ($_POST['quote_id'] ?? 0);
$method = ($_POST['method'] ?? '') === 'card' ? 'card' : 'cash';
$authNow = !empty($_POST['authorize_now']) && $method === 'card';

expire_stale_quotes();

$q = db_one(
    "SELECT q.*, sr.customer_id, sr.request_status, sr.preferred_start, sr.category_id,
            p.user_id AS provider_user_id, p.business_name, p.verification_status, p.provider_status, p.is_available,
            so.offering_status
     FROM quotes q
     JOIN service_requests sr ON sr.request_id = q.request_id
     JOIN providers p ON p.provider_id = q.provider_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     WHERE q.quote_id = ?",
    [$quoteId]
);

if (!$q || (int) $q['customer_id'] !== $custId) {
    flash('Quote not found.', 'danger');
    redirect('customer/requests.php');
}

$back = 'customer/request_details.php?id=' . (int) $q['request_id'];

if ($q['quote_status'] !== 'pending') {
    flash('This quote can no longer be accepted (status: ' . $q['quote_status'] . ').', 'danger');
    redirect($back);
}
if (strtotime($q['valid_until']) < time()) {
    db_exec("UPDATE quotes SET quote_status = 'expired' WHERE quote_id = ? AND quote_status = 'pending'", [$quoteId]);
    flash('This quote has expired. Please request a fresh quote.', 'danger');
    redirect($back);
}
if (!in_array($q['request_status'], ['open', 'matching'], true)) {
    flash('This service request is already ' . $q['request_status'] . '.', 'danger');
    redirect($back);
}
if ($q['verification_status'] !== 'verified' || $q['provider_status'] !== 'active' || $q['offering_status'] !== 'active') {
    flash('This provider or offering is no longer active.', 'danger');
    redirect($back);
}

$startStr = trim($_POST['scheduled_start'] ?? '');
$endStr = trim($_POST['scheduled_end'] ?? '');
if ($startStr === '' && !empty($q['proposed_start'])) {
    $startStr = date('Y-m-d\TH:i', strtotime($q['proposed_start']));
}
if ($endStr === '' && !empty($q['proposed_end'])) {
    $endStr = date('Y-m-d\TH:i', strtotime($q['proposed_end']));
}

$startTs = strtotime($startStr);
$endTs = strtotime($endStr);
if (!$startTs || !$endTs || $endTs <= $startTs) {
    flash('Please specify a valid appointment start and end time (end must be after start).', 'danger');
    redirect($back);
}
if ($startTs < time() - 60) {
    flash('Appointment start time must be in the future.', 'danger');
    redirect($back);
}

$scheduledStart = date('Y-m-d H:i:s', $startTs);
$scheduledEnd = date('Y-m-d H:i:s', $endTs);

$cardLast4 = null;
$authSuccess = true;
if ($authNow) {
    $num = preg_replace('/\D/', '', $_POST['card_number'] ?? '');
    if (trim($_POST['card_name'] ?? '') === '' || strlen($num) !== 16 || !preg_match('/^(0[1-9]|1[0-2])\/\d{2}$/', $_POST['expiry'] ?? '') || !preg_match('/^\d{3,4}$/', $_POST['cvv'] ?? '')) {
        flash('Invalid card details for pre-authorization. Booking was not confirmed.', 'danger');
        redirect($back);
    }
    $cardLast4 = substr($num, -4);
    // Simulate deterministic authorization failure only if card ends in 0000 (for testing UC-06 alt flow)
    if ($cardLast4 === '0000') {
        $authSuccess = false;
    }
}

$conn->beginTransaction();

// Serialize concurrent bookings for the same provider & request
db_one("SELECT provider_id FROM providers WHERE provider_id = ? FOR UPDATE", [(int) $q['provider_id']]);
db_one("SELECT request_id FROM service_requests WHERE request_id = ? FOR UPDATE", [(int) $q['request_id']]);

$existingBooking = db_val("SELECT COUNT(*) FROM bookings WHERE request_id = ? OR quote_id = ?", [(int) $q['request_id'], $quoteId]);
if ((int) $existingBooking > 0) {
    $conn->rollBack();
    flash('A booking already exists for this request or quote.', 'warning');
    redirect($back);
}

if (!provider_free((int) $q['provider_id'], $scheduledStart, $scheduledEnd)) {
    $conn->rollBack();
    flash('The provider already has an overlapping confirmed booking during that time slot. Please choose another time.', 'danger');
    redirect($back);
}

db_exec("UPDATE quotes SET quote_status = 'accepted' WHERE quote_id = ? AND quote_status = 'pending'", [$quoteId]);
if (db_affected_rows() !== 1) {
    $conn->rollBack();
    flash('Quote status changed before confirmation.', 'warning');
    redirect($back);
}

db_exec("UPDATE quotes SET quote_status = 'rejected' WHERE request_id = ? AND quote_id <> ? AND quote_status = 'pending'", [(int) $q['request_id'], $quoteId]);
db_exec("UPDATE service_requests SET request_status = 'booked' WHERE request_id = ?", [(int) $q['request_id']]);

$bookingStatus = $authNow && !$authSuccess ? 'payment_failed' : 'confirmed';
$bookingId = (int) db_exec(
    "INSERT INTO bookings (request_id, quote_id, agreed_price, scheduled_start, scheduled_end, booking_status) VALUES (?, ?, ?, ?, ?, ?)",
    [(int) $q['request_id'], $quoteId, $q['proposed_price'], $scheduledStart, $scheduledEnd, $bookingStatus]
);

if ($authNow) {
    $ref = 'AUTH-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    db_exec(
        "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, card_last4, gateway_reference, notes)
         VALUES (?, ?, 'PHP', 'authorization', ?, 'card', ?, ?, ?)",
        [$bookingId, $q['proposed_price'], $authSuccess ? 'successful' : 'failed', $cardLast4, $ref, $authSuccess ? 'Pre-authorized on booking confirmation' : 'Simulated card authorization declined (ending 0000)']
    );
} else {
    db_exec(
        "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, notes)
         VALUES (?, ?, 'PHP', 'authorization', 'pending', ?, ?)",
        [$bookingId, $q['proposed_price'], $method, 'Payment method selected at booking']
    );
}

audit_log($u['user_id'], 'booking', $bookingId, 'booking_created', 'From Quote #' . $quoteId . '; status=' . $bookingStatus . '; price=' . $q['proposed_price']);

notify_user(
    $q['provider_user_id'],
    'Quote Accepted — Booking #' . $bookingId,
    $u['full_name'] . ' accepted your quote for ' . money($q['proposed_price']) . ' on ' . fdatetime($scheduledStart) . '.',
    'employee/booking_details.php?id=' . $bookingId
);
notify_user(
    $u['user_id'],
    'Booking #' . $bookingId . ' ' . ($bookingStatus === 'confirmed' ? 'Confirmed' : 'Requires Payment Retry'),
    'Booked with ' . $q['business_name'] . ' for ' . fdatetime($scheduledStart) . '.',
    'customer/booking_details.php?id=' . $bookingId
);

$conn->commit();

if ($bookingStatus === 'payment_failed') {
    flash('Booking #' . $bookingId . ' was created, but card authorization failed. Please retry payment or switch method.', 'warning');
    redirect('customer/booking_details.php?id=' . $bookingId);
}
redirect('customer/booking_confirmation.php?id=' . $bookingId);
