<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$custId = (int) $u['customer_id'];
$catId = (int) ($_POST['category_id'] ?? 0);
$offeringId = (int) ($_POST['preferred_offering_id'] ?? 0);
$addressId = (int) ($_POST['address_id'] ?? 0);
$prefDate = trim($_POST['preferred_date'] ?? '');
$prefTime = trim($_POST['preferred_time'] ?? '');
$desc = trim($_POST['description'] ?? '');
$back = 'customer/request_service.php?category_id=' . $catId . ($offeringId ? '&offering_id=' . $offeringId : '');

$cat = db_one("SELECT * FROM service_categories WHERE category_id = ? AND category_status = 'active'", [$catId]);
if (!$cat) {
    flash('Selected service category is not available.', 'danger');
    redirect('customer/services.php');
}

$offering = null;
if ($offeringId > 0) {
    $offering = db_one(
        "SELECT so.*, p.verification_status, p.provider_status
         FROM service_offerings so
         JOIN providers p ON p.provider_id = so.provider_id
         WHERE so.offering_id = ? AND so.category_id = ? AND so.offering_status = 'active'
           AND p.verification_status = 'verified' AND p.provider_status = 'active'",
        [$offeringId, $catId]
    );
    if (!$offering) {
        flash('The selected provider offering is inactive or unavailable.', 'danger');
        redirect($back);
    }
}

$preferredStart = null;
if ($prefDate !== '' || $prefTime !== '') {
    if (!strtotime($prefDate) || $prefDate < date('Y-m-d')) {
        flash('Preferred date must be today or later.', 'danger');
        redirect($back);
    }
    if (!preg_match('/^\d{2}:\d{2}$/', $prefTime)) {
        flash('Please provide a valid preferred time.', 'danger');
        redirect($back);
    }
    if ($prefDate === date('Y-m-d') && $prefTime <= date('H:i')) {
        flash('That preferred time has already passed.', 'danger');
        redirect($back);
    }
    $preferredStart = $prefDate . ' ' . $prefTime . ':00';
}

if ($desc === '') {
    flash('Please describe the work needed.', 'danger');
    redirect($back);
}

$conn->beginTransaction();

if ($addressId === 0) {
    $label = trim($_POST['address_label'] ?? 'Service Location') ?: 'Service Location';
    $street = trim($_POST['street_address'] ?? '');
    $city = trim($_POST['city'] ?? 'Baguio City');
    $province = trim($_POST['province'] ?? 'Benguet');
    $postal = trim($_POST['postal_code'] ?? '');
    if ($street === '' || $city === '' || $province === '') {
        $conn->rollBack();
        flash('Please select a saved address or enter street, city, and province.', 'danger');
        redirect($back);
    }
    $addressId = (int) db_exec(
        "INSERT INTO addresses (customer_id, address_label, street_address, city, province, postal_code) VALUES (?, ?, ?, ?, ?, ?)",
        [$custId, $label, $street, $city, $province, $postal ?: null]
    );
} else {
    $addr = db_one("SELECT * FROM addresses WHERE address_id = ? AND customer_id = ?", [$addressId, $custId]);
    if (!$addr) {
        $conn->rollBack();
        flash('Selected address does not belong to your account.', 'danger');
        redirect($back);
    }
}

$eligibleProviders = db_all(
    "SELECT DISTINCT p.provider_id, p.user_id, p.business_name
     FROM service_offerings so
     JOIN providers p ON p.provider_id = so.provider_id
     JOIN users u ON u.user_id = p.user_id
     WHERE so.category_id = ?
       AND so.offering_status = 'active'
       AND p.verification_status = 'verified'
       AND p.provider_status = 'active'
       AND p.is_available = 1
       AND u.account_status = 'active'",
    [$catId]
);

$snapshotTitle = $offering ? $offering['title'] : $cat['category_name'];
$snapshotPrice = $offering ? ($offering['base_price'] ?? $cat['default_price']) : $cat['default_price'];
$status = $eligibleProviders ? 'matching' : 'open';
$photo = save_upload('photo', 'uploads');

$reqId = (int) db_exec(
    "INSERT INTO service_requests
        (customer_id, category_id, address_id, preferred_offering_id, service_snapshot_title, service_snapshot_price, description, photo, preferred_start, request_status)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
    [$custId, $catId, $addressId, $offering ? (int) $offering['offering_id'] : null, $snapshotTitle, $snapshotPrice, $desc, $photo ?: null, $preferredStart, $status]
);

audit_log($u['user_id'], 'service_request', $reqId, 'request_created', 'Category: ' . $cat['category_name'] . '; status=' . $status);

foreach ($eligibleProviders as $ep) {
    if ($offering && (int) $ep['provider_id'] !== (int) $offering['provider_id']) {
        continue;
    }
    notify_user(
        $ep['user_id'],
        'New ' . $cat['category_name'] . ' Request #' . $reqId,
        $u['full_name'] . ' requested ' . $snapshotTitle . '. Submit a quote to compete for this job.',
        'employee/booking_requests.php'
    );
}

$conn->commit();

if (!$eligibleProviders) {
    flash('Service request #' . $reqId . ' saved as Open. No providers are currently available in this category yet.', 'warning');
} else {
    flash('Service request #' . $reqId . ' submitted! Eligible providers have been notified and can send you quotes.');
}
redirect('customer/request_details.php?id=' . $reqId);
