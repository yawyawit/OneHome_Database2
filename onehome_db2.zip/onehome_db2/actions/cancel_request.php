<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$reqId = (int) ($_POST['request_id'] ?? 0);
$sr = get_request($reqId);

if (!$sr || (int) $sr['customer_id'] !== (int) $u['customer_id']) {
    flash('Request not found.', 'danger');
    redirect('customer/requests.php');
}
if (!in_array($sr['request_status'], ['open', 'matching'], true) || !empty($sr['booking_id'])) {
    flash('Booked or closed requests cannot be cancelled here.', 'danger');
    redirect('customer/request_details.php?id=' . $reqId);
}

$conn->beginTransaction();
db_exec("UPDATE service_requests SET request_status = 'cancelled' WHERE request_id = ? AND request_status IN ('open','matching')", [$reqId]);
db_exec("UPDATE quotes SET quote_status = 'rejected' WHERE request_id = ? AND quote_status = 'pending'", [$reqId]);
audit_log($u['user_id'], 'service_request', $reqId, 'request_cancelled', 'Cancelled by customer before booking');
$conn->commit();

flash('Service request #' . $reqId . ' cancelled.', 'info');
redirect('customer/requests.php');
