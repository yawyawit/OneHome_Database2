<?php
require_once __DIR__ . '/../includes/auth.php';
post_only();

$role = $_POST['role'] ?? 'customer';
if (!in_array($role, ['customer', 'employee', 'both'], true)) {
    $role = 'customer';
}
$name = trim($_POST['name'] ?? '');
$email = trim($_POST['email'] ?? '');
$phone = trim($_POST['phone'] ?? '');
$street = trim($_POST['street_address'] ?? '');
$city = trim($_POST['city'] ?? 'Baguio City');
$province = trim($_POST['province'] ?? 'Benguet');
$pass = $_POST['password'] ?? '';
$businessName = trim($_POST['business_name'] ?? '');
$serviceArea = trim($_POST['service_area'] ?? 'Baguio City') ?: 'Baguio City';
$skills = trim($_POST['skills'] ?? '');

$err = '';
if ($name === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $err = 'Please enter your name and a valid email.';
} elseif (!preg_match('/^[0-9+\-\s]{7,20}$/', $phone)) {
    $err = 'Please enter a valid contact number.';
} elseif ($street === '' || $city === '' || $province === '') {
    $err = 'Please provide your street address, city, and province.';
} elseif (strlen($pass) < 6) {
    $err = 'Password must be at least 6 characters.';
} elseif ($pass !== ($_POST['confirm'] ?? '')) {
    $err = 'Passwords do not match.';
} elseif ((int) db_val("SELECT COUNT(*) FROM users WHERE email = ?", [$email]) > 0) {
    $err = 'That email is already registered.';
}

if ($err) {
    flash($err, 'danger');
    redirect('register.php');
}

$parts = preg_split('/\s+/', $name, 2);
$firstName = $parts[0] ?? $name;
$lastName = $parts[1] ?? '';
$userRole = $role === 'both' ? 'multi' : ($role === 'employee' ? 'provider' : 'customer');

$conn->beginTransaction();
$userId = (int) db_exec(
    "INSERT INTO users (full_name, first_name, last_name, email, password_hash, phone, account_status, user_role) VALUES (?, ?, ?, ?, ?, ?, 'active', ?)",
    [$name, $firstName, $lastName, $email, password_hash($pass, PASSWORD_DEFAULT), $phone, $userRole]
);

if ($role === 'customer' || $role === 'both') {
    $username = strtolower(preg_replace('/[^a-z0-9]+/i', '_', $name)) . '_' . $userId;
    $custId = (int) db_exec(
        "INSERT INTO customers (user_id, username) VALUES (?, ?)",
        [$userId, $username]
    );
    db_exec(
        "INSERT INTO addresses (customer_id, address_label, street_address, city, province, is_default) VALUES (?, 'Home', ?, ?, ?, 1)",
        [$custId, $street, $city, $province]
    );
}

if ($role === 'employee' || $role === 'both') {
    $bName = $businessName !== '' ? $businessName : ($name . ' Services');
    $provId = (int) db_exec(
        "INSERT INTO providers (user_id, business_name, verification_status, provider_status, skills, service_area) VALUES (?, ?, 'pending', 'active', ?, ?)",
        [$userId, $bName, $skills, $serviceArea]
    );
    foreach (($_POST['services'] ?? []) as $catId) {
        $cat = db_one("SELECT * FROM service_categories WHERE category_id = ? AND category_status = 'active'", [(int) $catId]);
        if ($cat) {
            db_exec(
                "INSERT INTO service_offerings (provider_id, category_id, title, description, pricing_type, base_price, offering_status)
                 VALUES (?, ?, ?, ?, 'quotation', ?, 'active')",
                [$provId, (int) $cat['category_id'], $cat['category_name'] . ' Service', $cat['description'], $cat['default_price']]
            );
        }
    }
    $admins = db_all("SELECT user_id FROM admins");
    foreach ($admins as $adm) {
        notify_user($adm['user_id'], 'New Provider Verification', $bName . ' registered and is awaiting verification.', 'admin/users/index.php?role=provider');
    }
}
$conn->commit();

if ($role === 'employee') {
    flash('Provider account created! Please wait for admin verification before logging in.', 'info');
} elseif ($role === 'both') {
    flash('Account created! You can log in now as a Customer while your Provider profile awaits verification.', 'info');
} else {
    flash('Account created! You can log in now.');
}
redirect('login.php');
