<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();

$u = current_user();
$quoteId = (int) ($_POST['quote_id'] ?? 0);
$q = db_one(
    "SELECT q.*, sr.customer_id, p.user_id AS provider_user_id
     FROM quotes q
     JOIN service_requests sr ON sr.request_id = q.request_id
     JOIN providers p ON p.provider_id = q.provider_id
     WHERE q.quote_id = ?",
    [$quoteId]
);

if (!$q || (int) $q['customer_id'] !== (int) $u['customer_id']) {
    flash('Quote not found.', 'danger');
    redirect('customer/requests.php');
}

db_exec("UPDATE quotes SET quote_status = 'rejected' WHERE quote_id = ? AND quote_status = 'pending'", [$quoteId]);
if (db_affected_rows() === 1) {
    notify_user($q['provider_user_id'], 'Quote #' . $quoteId . ' Declined', $u['full_name'] . ' declined your quote for Request #' . $q['request_id'] . '.', 'employee/my_quotes.php');
    audit_log($u['user_id'], 'quote', $quoteId, 'quote_rejected', 'Rejected by customer');
    flash('Quote rejected.', 'info');
} else {
    flash('Quote could not be rejected.', 'warning');
}
redirect('customer/request_details.php?id=' . (int) $q['request_id']);
