<?php
require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
post_only();

$u = current_user();
$provId = (int) $u['provider_id'];
$quoteId = (int) ($_POST['quote_id'] ?? 0);

$q = db_one(
    "SELECT q.*, sr.customer_id, c.user_id AS customer_user_id
     FROM quotes q
     JOIN service_requests sr ON sr.request_id = q.request_id
     JOIN customers c ON c.customer_id = sr.customer_id
     WHERE q.quote_id = ? AND q.provider_id = ?",
    [$quoteId, $provId]
);

if (!$q) {
    flash('Quote not found.', 'danger');
    redirect('employee/my_quotes.php');
}

db_exec("UPDATE quotes SET quote_status = 'withdrawn' WHERE quote_id = ? AND provider_id = ? AND quote_status = 'pending'", [$quoteId, $provId]);
if (db_affected_rows() === 1) {
    audit_log($u['user_id'], 'quote', $quoteId, 'quote_withdrawn', 'Withdrawn by provider');
    notify_user($q['customer_user_id'], 'Quote #' . $quoteId . ' Withdrawn', $u['business_name'] . ' withdrew their quote on Request #' . $q['request_id'] . '.', 'customer/request_details.php?id=' . $q['request_id']);
    flash('Quote #' . $quoteId . ' withdrawn.', 'info');
} else {
    flash('Only pending quotes can be withdrawn.', 'warning');
}
redirect('employee/my_quotes.php');
