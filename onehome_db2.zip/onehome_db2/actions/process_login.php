<?php
require_once __DIR__ . '/../includes/auth.php';
post_only();

$email = trim($_POST['email'] ?? '');
$u = db_one(
    "SELECT u.*, c.customer_id, p.provider_id, p.verification_status, p.provider_status, a.admin_id
     FROM users u
     LEFT JOIN customers c ON c.user_id = u.user_id
     LEFT JOIN providers p ON p.user_id = u.user_id
     LEFT JOIN admins a ON a.user_id = u.user_id
     WHERE u.email = ?",
    [$email]
);

if (!$u || !password_verify($_POST['password'] ?? '', $u['password_hash'])) {
    flash('Wrong email or password.', 'danger');
    redirect('login.php');
}
if ($u['account_status'] === 'suspended') {
    flash('Your account is suspended. Please contact the administrator.', 'danger');
    redirect('login.php');
}
if ($u['account_status'] === 'inactive') {
    flash('Your account is deactivated. Please contact the admin.', 'danger');
    redirect('login.php');
}

$roles = [];
if (!empty($u['admin_id'])) {
    $roles[] = 'admin';
}
if (!empty($u['provider_id']) && $u['verification_status'] === 'verified' && $u['provider_status'] === 'active') {
    $roles[] = 'employee';
}
if (!empty($u['customer_id'])) {
    $roles[] = 'customer';
}

if (empty($roles)) {
    if (!empty($u['provider_id']) && $u['verification_status'] === 'pending') {
        flash('Your provider profile is still pending admin verification.', 'warning');
    } elseif (!empty($u['provider_id']) && $u['verification_status'] === 'rejected') {
        flash('Your provider verification was rejected. Please contact the admin.', 'danger');
    } else {
        flash('No active role profile is available for this account.', 'danger');
    }
    redirect('login.php');
}

session_regenerate_id(true);
$_SESSION['uid'] = (int) $u['user_id'];
$_SESSION['active_role'] = $roles[0];
redirect(home_for($roles[0]));
