<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$title = 'Services';
$q = trim($_GET['q'] ?? '');
$services = db_all(
    "SELECT * FROM service_categories
     WHERE category_status = 'active' AND (category_name LIKE ? OR description LIKE ?)
     ORDER BY category_name",
    ["%$q%", "%$q%"]
);
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center">
    <h2>Browse Service Categories</h2>
    <a class="btn btn-primary" href="<?= url('customer/request_service.php') ?>"><i class="bi bi-plus-circle me-1"></i> Post a Service Request</a>
</div>
<form class="input-group my-3" method="get">
    <input class="form-control" name="q" value="<?= e($q) ?>" placeholder="Search categories...">
    <button class="btn btn-primary">Search</button>
</form>
<?php if (!$services): ?>
    <div class="alert alert-secondary">No service categories found<?= $q ? ' for "' . e($q) . '"' : '' ?>.</div>
<?php endif; ?>
<div class="row"><?php foreach ($services as $s) echo service_card($s); ?></div>
<?php require INC . '/footer.php'; ?>
