<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$b = get_booking((int) ($_GET['id'] ?? 0));
if (!$b || (int) $b['customer_id'] !== (int) $u['customer_id'] || $b['pstatus'] !== 'paid') {
    redirect('customer/bookings.php');
}
$title = 'Payment Successful';
require INC . '/header.php'; ?>
<div class="card text-center">
    <div class="card-body p-5">
        <i class="bi bi-check-circle-fill text-success" style="font-size:4rem"></i>
        <h2>Payment Captured!</h2>
        <p>You paid <b><?= money($b['captured_total']) ?></b> for <?= e($b['offering_title']) ?> (card ending <?= e($b['card_last4'] ?: 'XXXX') ?>).</p>
        <?php if (!$b['reviewed']): ?>
            <a class="btn btn-warning" href="<?= url('customer/review.php?id=' . (int) $b['booking_id']) ?>">Rate &amp; Review <?= e($b['provider_business_name']) ?></a>
        <?php endif; ?>
        <a class="btn btn-outline-primary" href="<?= url('customer/payment_history.php') ?>">Payment History</a>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
