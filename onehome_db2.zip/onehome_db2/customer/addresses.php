<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'add') {
        $label = trim($_POST['address_label'] ?? 'Home');
        $street = trim($_POST['street_address'] ?? '');
        $city = trim($_POST['city'] ?? 'Baguio City');
        $province = trim($_POST['province'] ?? 'Benguet');
        $postal = trim($_POST['postal_code'] ?? '');
        if ($street === '' || $city === '' || $province === '') {
            flash('Street address, city, and province are required.', 'danger');
        } else {
            $isDef = isset($_POST['is_default']) ? 1 : 0;
            if ($isDef) {
                db_exec("UPDATE addresses SET is_default = 0 WHERE customer_id = ?", [$custId]);
            }
            db_exec(
                "INSERT INTO addresses (customer_id, address_label, street_address, city, province, postal_code, is_default) VALUES (?, ?, ?, ?, ?, ?, ?)",
                [$custId, $label ?: 'Address', $street, $city, $province, $postal ?: null, $isDef]
            );
            flash('Service address added.');
        }
    } elseif ($action === 'default') {
        $aid = (int) ($_POST['address_id'] ?? 0);
        db_exec("UPDATE addresses SET is_default = 0 WHERE customer_id = ?", [$custId]);
        db_exec("UPDATE addresses SET is_default = 1 WHERE address_id = ? AND customer_id = ?", [$aid, $custId]);
        flash('Default address updated.');
    } elseif ($action === 'delete') {
        $aid = (int) ($_POST['address_id'] ?? 0);
        $used = (int) db_val("SELECT COUNT(*) FROM service_requests WHERE address_id = ?", [$aid]);
        if ($used > 0) {
            flash('This address is linked to historical service requests and cannot be deleted.', 'warning');
        } else {
            db_exec("DELETE FROM addresses WHERE address_id = ? AND customer_id = ?", [$aid, $custId]);
            flash('Address removed.', 'info');
        }
    }
    redirect('customer/addresses.php');
}

$addresses = db_all("SELECT * FROM addresses WHERE customer_id = ? ORDER BY is_default DESC, address_id DESC", [$custId]);
$title = 'My Addresses';
require INC . '/header.php'; ?>
<h2>My Service Addresses</h2>
<div class="row">
    <div class="col-md-7 mb-4">
        <?php if (!$addresses): ?>
            <div class="alert alert-secondary">No saved addresses yet.</div>
        <?php else: ?>
            <?php foreach ($addresses as $a): ?>
                <div class="card mb-2">
                    <div class="card-body d-flex justify-content-between align-items-center">
                        <div>
                            <b><?= e($a['address_label'] ?: 'Address') ?></b>
                            <?php if ($a['is_default']): ?><span class="badge bg-primary ms-1">Default</span><?php endif; ?>
                            <div class="small text-muted"><?= e($a['street_address'] . ', ' . $a['city'] . ', ' . $a['province'] . ($a['postal_code'] ? ' ' . $a['postal_code'] : '')) ?></div>
                        </div>
                        <div class="d-flex gap-1">
                            <?php if (!$a['is_default']): ?>
                                <form method="post">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="action" value="default">
                                    <input type="hidden" name="address_id" value="<?= (int) $a['address_id'] ?>">
                                    <button class="btn btn-sm btn-outline-primary">Set Default</button>
                                </form>
                            <?php endif; ?>
                            <form method="post" data-confirm="Remove this address?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="address_id" value="<?= (int) $a['address_id'] ?>">
                                <button class="btn btn-sm btn-outline-danger">Delete</button>
                            </form>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="col-md-5">
        <form method="post" class="card card-body">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="add">
            <h5 class="mb-3">Add New Address</h5>
            <label class="form-label">Label</label><input name="address_label" class="form-control mb-2" placeholder="Home, Office, Condo..." required>
            <label class="form-label">Street Address</label><input name="street_address" class="form-control mb-2" required>
            <label class="form-label">City</label><input name="city" class="form-control mb-2" value="Baguio City" required>
            <label class="form-label">Province</label><input name="province" class="form-control mb-2" value="Benguet" required>
            <label class="form-label">Postal Code</label><input name="postal_code" class="form-control mb-2" value="2600">
            <div class="form-check mb-3"><input type="checkbox" class="form-check-input" name="is_default" id="def"><label class="form-check-label" for="def">Set as default address</label></div>
            <button class="btn btn-primary">Save Address</button>
        </form>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
