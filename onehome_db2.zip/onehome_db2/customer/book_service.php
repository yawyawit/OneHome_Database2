<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$qs = $_SERVER['QUERY_STRING'] ? ('?' . $_SERVER['QUERY_STRING']) : '';
redirect('customer/request_service.php' . $qs);
