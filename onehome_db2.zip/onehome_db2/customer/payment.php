<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$b = get_booking((int) ($_GET['id'] ?? 0));
if (!$b || (int) $b['customer_id'] !== (int) $u['customer_id']) {
    flash('Booking not found.', 'danger');
    redirect('customer/bookings.php');
}
if (!in_array($b['booking_status'], ['completed', 'settled'], true)) {
    flash('You can pay once the service is marked completed.', 'warning');
    redirect('customer/booking_details.php?id=' . $b['booking_id']);
}
$fin = booking_financials($b['booking_id'], $b['agreed_price']);
$method = in_array($_GET['method'] ?? '', ['cash', 'card'], true) ? $_GET['method'] : $fin['method'];
$title = 'Payment';
require INC . '/header.php'; ?>
<h2>Payment for Booking #<?= (int) $b['booking_id'] ?></h2>
<div class="row">
    <div class="col-md-5">
        <div class="card mb-3">
            <div class="card-header">Payment Summary</div>
            <div class="card-body">
                <p><b>Service:</b> <?= e($b['offering_title']) ?></p>
                <p><b>Provider:</b> <?= e($b['provider_business_name']) ?></p>
                <p><b>Agreed Price:</b> <?= money($b['agreed_price']) ?></p>
                <p><b>Captured So Far:</b> <?= money($fin['captured']) ?></p>
                <p class="fs-4"><b>Balance Due:</b> <?= money($fin['balance_due']) ?></p>
                <p class="mb-0"><b>Status:</b> <?= badge($fin['pstatus']) ?></p>
            </div>
        </div>
    </div>
    <div class="col-md-7">
        <?php if ($fin['balance_due'] <= 0): ?>
            <div class="alert alert-success">This booking is fully paid. Thank you!</div>
        <?php else: ?>
            <div class="mb-3">
                <a class="btn btn-sm <?= $method === 'cash' ? 'btn-dark' : 'btn-outline-dark' ?>" href="payment.php?id=<?= (int) $b['booking_id'] ?>&method=cash">Pay after service (cash)</a>
                <a class="btn btn-sm <?= $method === 'card' ? 'btn-dark' : 'btn-outline-dark' ?>" href="payment.php?id=<?= (int) $b['booking_id'] ?>&method=card">Pay by card (simulated)</a>
            </div>
            <?php if ($method === 'cash'): ?>
                <div class="card card-body">
                    <p>Pay <b><?= money($fin['balance_due']) ?></b> in cash to <?= e($b['provider_business_name']) ?>. They will record the cash capture once received.</p>
                    <form method="post" action="<?= url('actions/process_payment.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                        <input type="hidden" name="action" value="cash">
                        <button class="btn btn-primary">Confirm Cash Payment Method</button>
                    </form>
                </div>
            <?php else: ?>
                <form method="post" action="<?= url('actions/process_payment.php') ?>" class="card card-body">
                    <?= csrf_field() ?>
                    <div class="alert alert-info small">DEMO ONLY &mdash; no real money is charged. Use any 16 digits, e.g. 4242 4242 4242 4242.</div>
                    <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                    <input type="hidden" name="action" value="card">
                    <label class="form-label">Name on card</label><input name="card_name" class="form-control mb-2" required>
                    <label class="form-label">Card number</label><input name="card_number" id="card_number" class="form-control mb-2" placeholder="1234 5678 9012 3456" required>
                    <div class="row">
                        <div class="col-6 mb-3"><label class="form-label">Expiry (MM/YY)</label><input name="expiry" class="form-control" placeholder="12/28" required></div>
                        <div class="col-6 mb-3"><label class="form-label">CVV</label><input name="cvv" class="form-control" maxlength="4" required></div>
                    </div>
                    <button class="btn btn-success">Capture Payment (<?= money($fin['balance_due']) ?>)</button>
                </form>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
