<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'My Disputes';
$rows = db_all(
    "SELECT d.*, b.booking_status, b.agreed_price, sc.category_name, p.business_name, op.full_name AS opener_name
     FROM disputes d
     JOIN bookings b ON b.booking_id = d.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN providers p ON p.provider_id = q.provider_id
     JOIN users op ON op.user_id = d.opened_by_user_id
     WHERE sr.customer_id = ?
     ORDER BY d.created_at DESC",
    [$custId]
);
require INC . '/header.php'; ?>
<h2>My Disputes</h2>
<p class="text-muted">You can open a dispute from any active or completed booking's details page.</p>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No disputes recorded.</div>
<?php else: ?>
    <?php foreach ($rows as $d): ?>
        <div class="card mb-3">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <h5 class="mb-0">Dispute #<?= (int) $d['dispute_id'] ?> &mdash; Booking #<?= (int) $d['booking_id'] ?> (<?= e($d['category_name']) ?>)</h5>
                    <?= badge($d['dispute_status']) ?>
                </div>
                <div class="small text-muted mb-2">Provider: <?= e($d['business_name']) ?> &middot; Opened by: <?= e($d['opener_name']) ?> &middot; <?= fdatetime($d['created_at']) ?></div>
                <p class="mb-2"><?= nl2br(e($d['reason'])) ?></p>
                <?php if ($d['resolution']): ?>
                    <div class="alert alert-success py-2 mb-2"><b>Resolution:</b> <?= nl2br(e($d['resolution'])) ?></div>
                <?php endif; ?>
                <a class="btn btn-sm btn-outline-primary" href="<?= url('customer/booking_details.php?id=' . (int) $d['booking_id']) ?>">View Booking</a>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
