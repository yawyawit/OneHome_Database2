<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'My Service Requests';
$statuses = ['open', 'matching', 'booked', 'cancelled', 'closed'];
$st = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';
$rows = $st
    ? list_requests('sr.customer_id = ? AND sr.request_status = ?', [$custId, $st])
    : list_requests('sr.customer_id = ?', [$custId]);
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="mb-0">My Service Requests</h2>
    <a class="btn btn-primary" href="<?= url('customer/request_service.php') ?>"><i class="bi bi-plus-circle me-1"></i> New Request</a>
</div>
<div class="mb-3">
    <a class="btn btn-sm <?= $st ? 'btn-outline-dark' : 'btn-dark' ?>" href="requests.php">All</a>
    <?php foreach ($statuses as $s): ?>
        <a class="btn btn-sm <?= $st === $s ? 'btn-dark' : 'btn-outline-dark' ?>" href="requests.php?status=<?= $s ?>"><?= ucfirst($s) ?></a>
    <?php endforeach; ?>
</div>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No service requests found.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped bg-white align-middle">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Category</th>
                    <th>Address</th>
                    <th>Preferred Time</th>
                    <th>Quotes</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th></th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td>#<?= (int) $r['request_id'] ?></td>
                        <td>
                            <div class="fw-semibold"><?= e($r['category_name']) ?></div>
                            <small class="text-muted"><?= e($r['service_snapshot_title']) ?></small>
                        </td>
                        <td><?= e($r['street_address']) ?>, <?= e($r['city']) ?></td>
                        <td><?= $r['preferred_start'] ? fdatetime($r['preferred_start']) : 'Flexible' ?></td>
                        <td>
                            <span class="badge bg-info text-dark"><?= (int) $r['pending_quote_count'] ?> pending</span>
                            <small class="text-muted">(<?= (int) $r['quote_count'] ?> total)</small>
                        </td>
                        <td><?= badge($r['request_status']) ?></td>
                        <td><?= fdate($r['created_at']) ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" href="<?= url('customer/request_details.php?id=' . $r['request_id']) ?>">View Quotes</a>
                            <?php if ($r['booking_id']): ?>
                                <a class="btn btn-sm btn-success" href="<?= url('customer/booking_details.php?id=' . $r['booking_id']) ?>">Booking #<?= (int) $r['booking_id'] ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
