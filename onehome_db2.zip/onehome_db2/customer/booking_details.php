<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$b = get_booking((int) ($_GET['id'] ?? 0));
if (!$b || (int) $b['customer_id'] !== $custId) {
    flash('Booking not found.', 'danger');
    redirect('customer/bookings.php');
}
$fin = booking_financials($b['booking_id'], $b['agreed_price']);
$review = db_one("SELECT * FROM reviews WHERE booking_id = ?", [$b['booking_id']]);
$disputes = db_all("SELECT d.*, u.full_name AS opener_name FROM disputes d JOIN users u ON u.user_id = d.opened_by_user_id WHERE d.booking_id = ? ORDER BY d.created_at DESC", [$b['booking_id']]);
$title = 'Booking #' . $b['booking_id'];
require INC . '/header.php'; ?>
<h2>Booking #<?= (int) $b['booking_id'] ?></h2>
<?php booking_info($b); ?>

<div class="d-flex flex-wrap gap-2 mb-4">
    <?php if (in_array($b['booking_status'], ['completed', 'settled'], true) && $fin['balance_due'] > 0): ?>
        <a class="btn btn-success" href="<?= url('customer/payment.php?id=' . $b['booking_id']) ?>">Pay Balance (<?= money($fin['balance_due']) ?>)</a>
    <?php endif; ?>
    <?php if (in_array($b['booking_status'], ['completed', 'settled'], true) && !$b['reviewed']): ?>
        <a class="btn btn-warning" href="<?= url('customer/review.php?id=' . $b['booking_id']) ?>">Rate &amp; Review</a>
    <?php endif; ?>
    <?php if (can_transition_booking($b['booking_status'], 'cancelled')): ?>
        <form method="post" action="<?= url('customer/cancel_booking.php') ?>" class="d-inline" data-confirm="Cancel this booking?">
            <?= csrf_field() ?>
            <input type="hidden" name="id" value="<?= (int) $b['booking_id'] ?>">
            <button class="btn btn-danger">Cancel Booking</button>
        </form>
    <?php endif; ?>
    <a class="btn btn-secondary" href="<?= url('customer/bookings.php') ?>">Back</a>
</div>

<?php if ($b['booking_status'] === 'payment_failed'): ?>
    <div class="card border-danger mb-4">
        <div class="card-header bg-danger text-white">Retry Card Authorization</div>
        <div class="card-body">
            <form method="post" action="<?= url('actions/process_payment.php') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                <input type="hidden" name="action" value="retry_auth">
                <div class="row g-2">
                    <div class="col-md-4"><input name="card_name" class="form-control" placeholder="Name on card" required></div>
                    <div class="col-md-4"><input name="card_number" class="form-control" placeholder="16 digits (not ending 0000)" required></div>
                    <div class="col-md-2"><input name="expiry" class="form-control" placeholder="MM/YY" required></div>
                    <div class="col-md-2"><input name="cvv" class="form-control" placeholder="CVV" required></div>
                </div>
                <button class="btn btn-primary mt-2">Retry Authorization</button>
            </form>
        </div>
    </div>
<?php endif; ?>

<div class="row">
    <?php if (can_transition_booking($b['booking_status'], 'rescheduled')): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">Reschedule Appointment</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/reschedule_booking.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                        <div class="mb-2">
                            <label class="form-label small">New Start</label>
                            <input type="datetime-local" name="scheduled_start" value="<?= date('Y-m-d\TH:i', strtotime($b['scheduled_start'])) ?>" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">New End</label>
                            <input type="datetime-local" name="scheduled_end" value="<?= date('Y-m-d\TH:i', strtotime($b['scheduled_end'])) ?>" class="form-control" required>
                        </div>
                        <button class="btn btn-outline-primary btn-sm">Update Schedule</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (in_array($b['booking_status'], ['confirmed', 'rescheduled', 'in_progress', 'completed', 'disputed'], true)): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">Report an Issue / Open Dispute</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/open_dispute.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                        <label class="form-label small">Describe the problem or disagreement</label>
                        <textarea name="reason" rows="3" class="form-control mb-2" required></textarea>
                        <button class="btn btn-outline-danger btn-sm">Open Dispute</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<?php if ($review): ?>
    <div class="card mb-3">
        <div class="card-body"><b>Your review:</b> <?= stars($review['rating']) ?><br><?= e($review['comment']) ?></div>
    </div>
<?php endif; ?>

<?php if ($fin['records']): ?>
    <h5>Payment Ledger</h5>
    <table class="table table-sm table-bordered bg-white mb-4">
        <thead class="table-light">
            <tr><th>Type</th><th>Method</th><th>Amount</th><th>Status</th><th>Reference</th><th>Date</th></tr>
        </thead>
        <tbody>
            <?php foreach ($fin['records'] as $pr): ?>
                <tr>
                    <td><?= badge($pr['payment_type']) ?></td>
                    <td><?= pay_label($pr['method']) ?><?= $pr['card_last4'] ? ' (*' . e($pr['card_last4']) . ')' : '' ?></td>
                    <td><?= money($pr['amount']) ?></td>
                    <td><?= badge($pr['payment_status']) ?></td>
                    <td><code><?= e($pr['gateway_reference'] ?: '-') ?></code></td>
                    <td><?= fdatetime($pr['created_at']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>

<?php if ($disputes): ?>
    <h5>Dispute History</h5>
    <?php foreach ($disputes as $d): ?>
        <div class="card mb-2">
            <div class="card-body">
                <div class="d-flex justify-content-between">
                    <b>Dispute #<?= (int) $d['dispute_id'] ?> (opened by <?= e($d['opener_name']) ?>)</b>
                    <?= badge($d['dispute_status']) ?>
                </div>
                <p class="mb-1"><?= nl2br(e($d['reason'])) ?></p>
                <?php if ($d['resolution']): ?>
                    <div class="small text-success"><b>Resolution:</b> <?= nl2br(e($d['resolution'])) ?></div>
                <?php endif; ?>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
