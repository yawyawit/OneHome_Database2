<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$b = get_booking((int) ($_GET['id'] ?? 0));
if (!$b || (int) $b['customer_id'] !== (int) $u['customer_id'] || !in_array($b['booking_status'], ['completed', 'settled'], true)) {
    flash('You can only review completed bookings.', 'warning');
    redirect('customer/bookings.php');
}
if ($b['reviewed']) {
    flash('You already reviewed this booking.', 'info');
    redirect('customer/my_reviews.php');
}
$title = 'Rate & Review';
require INC . '/header.php'; ?>
<h2>Rate <?= e($b['provider_business_name']) ?></h2>
<p class="text-muted"><?= e($b['offering_title']) ?> &mdash; <?= fdate($b['scheduled_start']) ?></p>
<form method="post" action="<?= url('actions/process_review.php') ?>" class="card card-body" style="max-width:600px">
    <?= csrf_field() ?>
    <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
    <label class="form-label">Rating</label>
    <div class="mb-3">
        <div class="oh-star-picker" role="radiogroup" aria-label="Star rating">
            <?php for ($i = 5; $i >= 1; $i--): ?>
                <input type="radio" name="rating" id="star<?= $i ?>" value="<?= $i ?>" required>
                <label for="star<?= $i ?>" title="<?= $i ?> star<?= $i > 1 ? 's' : '' ?>">&#9733;</label>
            <?php endfor; ?>
        </div>
    </div>
    <label class="form-label">Comment (optional)</label>
    <textarea name="comment" rows="4" class="form-control mb-3" placeholder="Share how the service went..."></textarea>
    <div class="d-flex gap-2">
        <button class="btn btn-primary">Submit Review</button>
        <a class="btn btn-secondary" href="<?= url('customer/booking_details.php?id=' . (int) $b['booking_id']) ?>">Cancel</a>
    </div>
</form>
<?php require INC . '/footer.php'; ?>
