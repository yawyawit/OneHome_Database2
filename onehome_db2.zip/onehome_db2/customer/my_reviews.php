<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$title = 'My Reviews';
$rows = db_all(
    "SELECT r.*, p.business_name, sc.category_name, so.title AS offering_title
     FROM reviews r
     JOIN bookings b ON b.booking_id = r.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN providers p ON p.provider_id = q.provider_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     WHERE r.customer_id = ?
     ORDER BY r.created_at DESC",
    [(int) $u['customer_id']]
);
require INC . '/header.php'; ?>
<h2>My Reviews</h2>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">You have not written any reviews yet. Reviews can be written for completed bookings.</div>
<?php endif; ?>
<?php foreach ($rows as $r): ?>
    <div class="card mb-2">
        <div class="card-body">
            <b><?= e($r['business_name']) ?></b> &mdash; <?= e($r['offering_title']) ?> <?= stars($r['rating']) ?>
            <div><?= e($r['comment'] ?: '(no comment)') ?></div>
            <small class="text-muted"><?= fdate($r['created_at']) ?></small>
        </div>
    </div>
<?php endforeach; ?>
<?php require INC . '/footer.php'; ?>
