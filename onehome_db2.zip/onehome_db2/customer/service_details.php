<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$catId = (int) ($_GET['id'] ?? 0);
$s = db_one("SELECT * FROM service_categories WHERE category_id = ? AND category_status = 'active'", [$catId]);
if (!$s) {
    flash('Service category not found.', 'danger');
    redirect('customer/services.php');
}
$offerings = db_all(
    "SELECT so.*, p.business_name, p.skills, p.service_area, p.available_days, u.full_name, u.avatar,
            (SELECT ROUND(AVG(r.rating), 1)
             FROM reviews r
             JOIN bookings b ON b.booking_id = r.booking_id
             JOIN quotes q ON q.quote_id = b.quote_id
             WHERE q.provider_id = p.provider_id) AS avg_rating,
            (SELECT COUNT(r.review_id)
             FROM reviews r
             JOIN bookings b ON b.booking_id = r.booking_id
             JOIN quotes q ON q.quote_id = b.quote_id
             WHERE q.provider_id = p.provider_id) AS review_count
     FROM service_offerings so
     JOIN providers p ON p.provider_id = so.provider_id
     JOIN users u ON u.user_id = p.user_id
     WHERE so.category_id = ? AND so.offering_status = 'active'
       AND p.verification_status = 'verified' AND p.provider_status = 'active' AND u.account_status = 'active'
     ORDER BY avg_rating DESC, so.base_price ASC",
    [$catId]
);
$title = $s['category_name'];
require INC . '/header.php'; ?>
<div class="card mb-4">
    <div class="card-body text-center p-4">
        <i class="bi <?= e($s['icon']) ?> service-icon" style="font-size:4rem"></i>
        <h2 class="mt-2"><?= e($s['category_name']) ?></h2>
        <p class="lead mb-2"><?= e($s['description']) ?></p>
        <p class="text-muted mb-3">Typical starting rate: <b><?= money($s['default_price']) ?></b> &middot; <?= count($offerings) ?> verified provider offering(s)</p>
        <a class="btn btn-primary btn-lg" href="<?= url('customer/request_service.php?category_id=' . $catId) ?>">Submit Open Request (Get Quotes)</a>
        <a class="btn btn-outline-primary btn-lg" href="<?= url('customer/select_employee.php?service_id=' . $catId) ?>">Filter by Availability</a>
        <a class="btn btn-secondary btn-lg" href="<?= url('customer/services.php') ?>">Back</a>
    </div>
</div>

<h4>Provider Offerings in <?= e($s['category_name']) ?></h4>
<?php if (!$offerings): ?>
    <div class="alert alert-warning">No active provider offerings in this category yet. You can still post an open request.</div>
<?php else: ?>
    <div class="row">
        <?php foreach ($offerings as $o): ?>
            <div class="col-md-6 mb-3">
                <div class="card h-100">
                    <div class="card-body">
                        <div class="d-flex justify-content-between align-items-start">
                            <div>
                                <h5 class="mb-1"><?= e($o['title']) ?></h5>
                                <div class="small text-muted"><?= e($o['business_name']) ?> (<?= e($o['full_name']) ?>) &middot; <?= e($o['service_area']) ?></div>
                            </div>
                            <?= badge($o['pricing_type']) ?>
                        </div>
                        <div class="my-2"><?= rating_text($o['avg_rating'], $o['review_count']) ?></div>
                        <p class="small mb-2"><?= e($o['description']) ?></p>
                        <div class="small text-muted mb-3">
                            <b>Base Price:</b> <?= $o['base_price'] !== null ? money($o['base_price']) : 'Quoted on request' ?>
                            &middot; <b>Days:</b> <?= e($o['available_days']) ?>
                        </div>
                        <a class="btn btn-sm btn-primary" href="<?= url('customer/request_service.php?category_id=' . $catId . '&offering_id=' . (int) $o['offering_id']) ?>">Request This Offering</a>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
