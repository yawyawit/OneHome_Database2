<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$catId = (int) ($_GET['service_id'] ?? $_GET['category_id'] ?? 0);
$service = db_one("SELECT * FROM service_categories WHERE category_id = ? AND category_status = 'active'", [$catId]);
if (!$service) {
    flash('Service category not found.', 'danger');
    redirect('customer/services.php');
}
$date = $_GET['date'] ?? '';
$time = $_GET['time'] ?? '';
if ($date && (!strtotime($date) || $date < date('Y-m-d'))) {
    $date = '';
    flash('Please pick a date that is today or later.', 'warning');
}

$offerings = db_all(
    "SELECT so.*, p.provider_id, p.business_name, p.skills, p.available_days, p.service_area, u.full_name, u.avatar,
            (SELECT ROUND(AVG(r.rating), 1)
             FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id
             WHERE q.provider_id = p.provider_id) AS avg_rating,
            (SELECT COUNT(r.review_id)
             FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id
             WHERE q.provider_id = p.provider_id) AS rc
     FROM service_offerings so
     JOIN providers p ON p.provider_id = so.provider_id
     JOIN users u ON u.user_id = p.user_id
     WHERE so.category_id = ? AND so.offering_status = 'active'
       AND p.verification_status = 'verified' AND p.provider_status = 'active' AND p.is_available = 1 AND u.account_status = 'active'
     ORDER BY avg_rating DESC",
    [$catId]
);

if ($date) {
    $offerings = array_filter($offerings, function ($o) use ($date, $time) {
        if (!works_on($o, $date)) {
            return false;
        }
        if ($time !== '') {
            $start = $date . ' ' . $time . ':00';
            $end = date('Y-m-d H:i:s', strtotime($start) + 7200);
            return provider_free((int) $o['provider_id'], $start, $end);
        }
        return true;
    });
}
$title = 'Discover Providers';
require INC . '/header.php'; ?>
<h2>Eligible Providers for <?= e($service['category_name']) ?></h2>
<form class="row g-2 align-items-end my-3" method="get">
    <input type="hidden" name="service_id" value="<?= $catId ?>">
    <div class="col-md-3"><label class="form-label">Preferred date</label><input type="date" name="date" min="<?= date('Y-m-d') ?>" value="<?= e($date) ?>" class="form-control"></div>
    <div class="col-md-3"><label class="form-label">Preferred time</label><input type="time" name="time" value="<?= e($time) ?>" class="form-control"></div>
    <div class="col-md-3"><button class="btn btn-outline-primary">Check Availability</button></div>
    <div class="col-md-3 text-md-end"><a class="btn btn-success" href="<?= url('customer/request_service.php?category_id=' . $catId . '&date=' . urlencode($date) . '&time=' . urlencode($time)) ?>">Open Request (All Providers)</a></div>
</form>

<?php if (!$offerings): ?>
    <div class="alert alert-warning">No providers match that schedule right now. Try a different date/time or post an open request.</div>
<?php endif; ?>

<?php foreach ($offerings as $o): ?>
    <div class="card mb-3">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-md-1"><?= avatar($o['full_name'], $o['avatar']) ?></div>
                <div class="col-md-8">
                    <h5 class="mb-1"><?= e($o['business_name']) ?> &mdash; <small class="text-muted"><?= e($o['title']) ?></small> <?= badge($o['pricing_type']) ?></h5>
                    <div><?= rating_text($o['avg_rating'], $o['rc']) ?></div>
                    <div class="small"><b>Provider:</b> <?= e($o['full_name']) ?> &middot; <b>Area:</b> <?= e($o['service_area']) ?></div>
                    <div class="small"><b>Skills:</b> <?= e($o['skills'] ?: 'Not listed') ?></div>
                    <div class="small"><b>Available days:</b> <?= e(str_replace(',', ', ', $o['available_days'])) ?> &middot; <b>Base Price:</b> <?= $o['base_price'] !== null ? money($o['base_price']) : 'By quote' ?></div>
                </div>
                <div class="col-md-3 text-md-end mt-2">
                    <a class="btn btn-primary" href="<?= url('customer/request_service.php?category_id=' . $catId . '&offering_id=' . (int) $o['offering_id'] . '&date=' . urlencode($date) . '&time=' . urlencode($time)) ?>">Request Quote</a>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; ?>
<a href="<?= url('customer/services.php') ?>">&laquo; Back to categories</a>
<?php require INC . '/footer.php'; ?>
