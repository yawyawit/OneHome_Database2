<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$reqId = (int) ($_GET['id'] ?? 0);
$r = get_request($reqId);

if (!$r || (int) $r['customer_id'] !== $custId) {
    flash('Service request not found.', 'danger');
    redirect('customer/requests.php');
}

$quotes = db_all(
    "SELECT q.*, p.business_name, p.skills, p.available_days, u.full_name AS provider_name, u.avatar,
            so.title AS offering_title, so.pricing_type,
            (SELECT ROUND(AVG(rv.rating), 1)
             FROM reviews rv JOIN bookings b ON b.booking_id = rv.booking_id JOIN quotes q2 ON q2.quote_id = b.quote_id
             WHERE q2.provider_id = p.provider_id) AS avg_rating,
            (SELECT COUNT(rv.review_id)
             FROM reviews rv JOIN bookings b ON b.booking_id = rv.booking_id JOIN quotes q2 ON q2.quote_id = b.quote_id
             WHERE q2.provider_id = p.provider_id) AS review_count
     FROM quotes q
     JOIN providers p ON p.provider_id = q.provider_id
     JOIN users u ON u.user_id = p.user_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     WHERE q.request_id = ?
     ORDER BY (q.quote_status = 'pending') DESC, q.proposed_price ASC",
    [$reqId]
);

$title = 'Request #' . $reqId;
require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="mb-0">Service Request #<?= $reqId ?> <?= badge($r['request_status']) ?></h2>
    <div class="d-flex gap-2">
        <?php if (!empty($r['booking_id'])): ?>
            <a class="btn btn-success" href="<?= url('customer/booking_details.php?id=' . $r['booking_id']) ?>">View Booking #<?= (int) $r['booking_id'] ?></a>
        <?php elseif (in_array($r['request_status'], ['open', 'matching'], true)): ?>
            <form method="post" action="<?= url('actions/cancel_request.php') ?>" data-confirm="Cancel this service request?">
                <?= csrf_field() ?>
                <input type="hidden" name="request_id" value="<?= $reqId ?>">
                <button class="btn btn-outline-danger">Cancel Request</button>
            </form>
        <?php endif; ?>
        <a class="btn btn-secondary" href="<?= url('customer/requests.php') ?>">Back</a>
    </div>
</div>

<div class="card mb-4">
    <div class="card-body">
        <div class="row">
            <div class="col-md-6">
                <p class="mb-1"><b>Category:</b> <?= e($r['category_name']) ?></p>
                <p class="mb-1"><b>Service Snapshot:</b> <?= e($r['service_snapshot_title']) ?> (ref <?= money($r['service_snapshot_price']) ?>)</p>
                <p class="mb-1"><b>Address:</b> <?= e($r['street_address'] . ', ' . $r['city'] . ', ' . $r['province']) ?></p>
                <p class="mb-0"><b>Preferred Time:</b> <?= $r['preferred_start'] ? fdatetime($r['preferred_start']) : 'Flexible' ?></p>
            </div>
            <div class="col-md-6">
                <p class="mb-1"><b>Description:</b></p>
                <p class="mb-1"><?= nl2br(e($r['description'])) ?></p>
                <?php if (!empty($r['photo'])): ?>
                    <img src="<?= url('uploads/' . $r['photo']) ?>" class="img-thumbnail mt-2" style="max-width:220px">
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<h4>Provider Quotes (<?= count($quotes) ?>)</h4>
<?php if (!$quotes): ?>
    <div class="alert alert-info">No quotes submitted yet. Verified providers in <?= e($r['category_name']) ?> have been notified.</div>
<?php else: ?>
    <?php foreach ($quotes as $q):
        $defaultStart = $q['proposed_start'] ? date('Y-m-d\TH:i', strtotime($q['proposed_start'])) : ($r['preferred_start'] ? date('Y-m-d\TH:i', strtotime($r['preferred_start'])) : date('Y-m-d\TH:i', strtotime('+1 day 09:00')));
        $defaultEnd = $q['proposed_end'] ? date('Y-m-d\TH:i', strtotime($q['proposed_end'])) : date('Y-m-d\TH:i', strtotime($defaultStart) + 7200);
        $canAccept = $q['quote_status'] === 'pending' && strtotime($q['valid_until']) >= time() && in_array($r['request_status'], ['open', 'matching'], true);
    ?>
        <div class="card mb-3 <?= $q['quote_status'] === 'accepted' ? 'border-success' : '' ?>">
            <div class="card-body">
                <div class="row align-items-start">
                    <div class="col-md-7">
                        <div class="d-flex align-items-center gap-3 mb-2">
                            <?= avatar($q['provider_name'], $q['avatar'], 48) ?>
                            <div>
                                <h5 class="mb-0"><?= e($q['business_name']) ?> <?= badge($q['quote_status']) ?></h5>
                                <div class="small text-muted"><?= e($q['provider_name']) ?> &middot; <?= e($q['offering_title']) ?> (<?= badge($q['pricing_type']) ?>)</div>
                                <div><?= rating_text($q['avg_rating'], $q['review_count']) ?></div>
                            </div>
                        </div>
                        <p class="mb-1"><b>Scope:</b> <?= nl2br(e($q['scope'])) ?></p>
                        <div class="small text-muted">
                            <b>Proposed Window:</b> <?= $q['proposed_start'] ? fdatetime($q['proposed_start']) . ' - ' . ftime($q['proposed_end']) : 'Flexible' ?>
                            &middot; <b>Valid Until:</b> <?= fdatetime($q['valid_until']) ?>
                        </div>
                    </div>
                    <div class="col-md-5 text-md-end">
                        <div class="fs-3 fw-bold text-primary mb-2"><?= money($q['proposed_price']) ?></div>
                        <?php if ($canAccept): ?>
                            <form method="post" action="<?= url('actions/accept_quote.php') ?>" class="text-start border rounded p-3 bg-light mb-2">
                                <?= csrf_field() ?>
                                <input type="hidden" name="quote_id" value="<?= (int) $q['quote_id'] ?>">
                                <div class="row g-2 mb-2">
                                    <div class="col-6">
                                        <label class="form-label small mb-0">Appointment Start</label>
                                        <input type="datetime-local" name="scheduled_start" value="<?= e($defaultStart) ?>" class="form-control form-control-sm" required>
                                    </div>
                                    <div class="col-6">
                                        <label class="form-label small mb-0">Appointment End</label>
                                        <input type="datetime-local" name="scheduled_end" value="<?= e($defaultEnd) ?>" class="form-control form-control-sm" required>
                                    </div>
                                </div>
                                <div class="mb-2">
                                    <label class="form-label small mb-0">Payment Preference</label>
                                    <select name="method" class="form-select form-select-sm quote-pay-method">
                                        <option value="cash">Cash after service</option>
                                        <option value="card">Card (simulated)</option>
                                    </select>
                                </div>
                                <div class="quote-auth-box" style="display:none">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input quote-auth-check" type="checkbox" name="authorize_now" value="1" id="auth<?= (int) $q['quote_id'] ?>">
                                        <label class="form-check-label small" for="auth<?= (int) $q['quote_id'] ?>">Pre-authorize card on confirmation</label>
                                    </div>
                                    <div class="quote-card-fields" style="display:none">
                                        <input name="card_name" class="form-control form-control-sm mb-1" placeholder="Name on card">
                                        <input name="card_number" class="form-control form-control-sm mb-1" placeholder="16 digits (4242...; ending 0000 simulates decline)">
                                        <div class="row g-1">
                                            <div class="col-6"><input name="expiry" class="form-control form-control-sm" placeholder="MM/YY"></div>
                                            <div class="col-6"><input name="cvv" class="form-control form-control-sm" placeholder="CVV"></div>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-success btn-sm w-100 mt-2">Accept Quote &amp; Confirm Booking</button>
                            </form>
                            <form method="post" action="<?= url('actions/reject_quote.php') ?>" class="d-inline" data-confirm="Reject this quote?">
                                <?= csrf_field() ?>
                                <input type="hidden" name="quote_id" value="<?= (int) $q['quote_id'] ?>">
                                <button class="btn btn-sm btn-outline-danger">Decline Quote</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; ?>
<?php endif; ?>
<script>
document.addEventListener('DOMContentLoaded', function () {
    document.querySelectorAll('.quote-pay-method').forEach(function (sel) {
        var form = sel.closest('form');
        var authBox = form.querySelector('.quote-auth-box');
        var authCheck = form.querySelector('.quote-auth-check');
        var cardFields = form.querySelector('.quote-card-fields');
        var sync = function () {
            authBox.style.display = sel.value === 'card' ? 'block' : 'none';
            cardFields.style.display = (sel.value === 'card' && authCheck.checked) ? 'block' : 'none';
        };
        sel.addEventListener('change', sync);
        authCheck.addEventListener('change', sync);
    });
});
</script>
<?php require INC . '/footer.php'; ?>
