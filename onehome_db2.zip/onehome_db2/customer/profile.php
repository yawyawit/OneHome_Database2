<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'My Profile';
$totalBookings = (int) db_val("SELECT COUNT(*) FROM bookings b JOIN service_requests sr ON sr.request_id = b.request_id WHERE sr.customer_id = ?", [$custId]);
$totalRequests = (int) db_val("SELECT COUNT(*) FROM service_requests WHERE customer_id = ?", [$custId]);
$addrCount = (int) db_val("SELECT COUNT(*) FROM addresses WHERE customer_id = ?", [$custId]);
require INC . '/header.php'; ?>
<h2>My Profile</h2>
<div class="card mb-3" style="max-width:650px">
    <div class="card-body">
        <p><b>Name:</b> <?= e($u['full_name']) ?></p>
        <p><b>Username:</b> <?= e($u['customer_username'] ?: '-') ?></p>
        <p><b>Email:</b> <?= e($u['email']) ?></p>
        <p><b>Contact number:</b> <?= e($u['phone']) ?></p>
        <p><b>Saved addresses:</b> <?= $addrCount ?> <a class="small ms-2" href="<?= url('customer/addresses.php') ?>">Manage</a></p>
        <p><b>Service requests:</b> <?= $totalRequests ?> &middot; <b>Bookings:</b> <?= $totalBookings ?></p>
        <a class="btn btn-primary" href="<?= url('customer/edit_profile.php') ?>">Edit Profile &amp; Settings</a>
        <a class="btn btn-outline-secondary" href="<?= url('customer/my_reviews.php') ?>">My Reviews</a>
        <a class="btn btn-outline-danger" href="<?= url('logout.php') ?>">Log out</a>
    </div>
</div>
<?php if (empty($u['provider_id'])): ?>
    <div class="card" style="max-width:650px">
        <div class="card-body">
            <h5>Also Offer Services on One Home?</h5>
            <p class="small text-muted">One user identity can hold both Customer and Service Provider profiles.</p>
            <form method="post" action="<?= url('actions/process_profile.php') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="enable_provider">
                <div class="input-group">
                    <input name="business_name" class="form-control" placeholder="Your business/display name" required>
                    <button class="btn btn-outline-primary">Apply as Service Provider</button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
