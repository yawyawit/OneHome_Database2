<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];

$catId = (int) ($_GET['category_id'] ?? $_GET['service_id'] ?? 0);
$offeringId = (int) ($_GET['offering_id'] ?? 0);
$date = $_GET['date'] ?? '';
$time = $_GET['time'] ?? '';

$categories = db_all("SELECT * FROM service_categories WHERE category_status = 'active' ORDER BY category_name");
if ($catId === 0 && $categories) {
    $catId = (int) $categories[0]['category_id'];
}

$selectedOffering = null;
if ($offeringId > 0) {
    $selectedOffering = db_one(
        "SELECT so.*, p.business_name FROM service_offerings so JOIN providers p ON p.provider_id = so.provider_id WHERE so.offering_id = ? AND so.offering_status = 'active'",
        [$offeringId]
    );
    if ($selectedOffering) {
        $catId = (int) $selectedOffering['category_id'];
    }
}

$addresses = db_all("SELECT * FROM addresses WHERE customer_id = ? ORDER BY is_default DESC, address_id DESC", [$custId]);
$title = 'Submit Service Request';
require INC . '/header.php'; ?>
<h2>Submit Service Request</h2>
<p class="text-muted">Describe your home service need and location. Verified providers in this category will submit quotes for you to compare and book.</p>

<div class="row">
    <div class="col-lg-8">
        <form method="post" enctype="multipart/form-data" action="<?= url('actions/process_request.php') ?>" class="card card-body">
            <?= csrf_field() ?>
            <div class="mb-3">
                <label class="form-label">Service Category</label>
                <select name="category_id" class="form-select" required>
                    <?php foreach ($categories as $c): ?>
                        <option value="<?= (int) $c['category_id'] ?>" <?= (int) $c['category_id'] === $catId ? 'selected' : '' ?>>
                            <?= e($c['category_name']) ?> (Typical from <?= money($c['default_price']) ?>)
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>

            <?php if ($selectedOffering): ?>
                <input type="hidden" name="preferred_offering_id" value="<?= (int) $selectedOffering['offering_id'] ?>">
                <div class="alert alert-info py-2">
                    <b>Preferred Offering:</b> <?= e($selectedOffering['title']) ?> by <?= e($selectedOffering['business_name']) ?>
                    (<?= badge($selectedOffering['pricing_type']) ?> <?= $selectedOffering['base_price'] !== null ? money($selectedOffering['base_price']) : '' ?>)
                </div>
            <?php endif; ?>

            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Preferred Date (optional)</label>
                    <input type="date" name="preferred_date" min="<?= date('Y-m-d') ?>" value="<?= e($date) ?>" class="form-control">
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Preferred Time (optional)</label>
                    <input type="time" name="preferred_time" value="<?= e($time) ?>" class="form-control">
                </div>
            </div>

            <div class="mb-3">
                <div class="d-flex justify-content-between align-items-center mb-1">
                    <label class="form-label mb-0">Service Address</label>
                    <a class="small" href="<?= url('customer/addresses.php') ?>">Manage saved addresses</a>
                </div>
                <select name="address_id" id="address_select" class="form-select mb-2">
                    <?php foreach ($addresses as $a): ?>
                        <option value="<?= (int) $a['address_id'] ?>">
                            <?= e(($a['address_label'] ? $a['address_label'] . ': ' : '') . $a['street_address'] . ', ' . $a['city'] . ', ' . $a['province']) ?>
                        </option>
                    <?php endforeach; ?>
                    <option value="0" <?= !$addresses ? 'selected' : '' ?>>+ Add a new service address</option>
                </select>

                <div id="new_address_fields" class="border rounded p-3 bg-light" style="<?= $addresses ? 'display:none' : '' ?>">
                    <div class="row">
                        <div class="col-md-4 mb-2"><label class="form-label small">Label</label><input name="address_label" class="form-control form-control-sm" placeholder="Home / Office"></div>
                        <div class="col-md-8 mb-2"><label class="form-label small">Street Address</label><input name="street_address" class="form-control form-control-sm" placeholder="House #, Street, Barangay"></div>
                        <div class="col-md-4 mb-2"><label class="form-label small">City</label><input name="city" class="form-control form-control-sm" value="Baguio City"></div>
                        <div class="col-md-4 mb-2"><label class="form-label small">Province</label><input name="province" class="form-control form-control-sm" value="Benguet"></div>
                        <div class="col-md-4 mb-2"><label class="form-label small">Postal Code</label><input name="postal_code" class="form-control form-control-sm" value="2600"></div>
                    </div>
                </div>
            </div>

            <div class="mb-3">
                <label class="form-label">Describe the problem or work needed</label>
                <textarea name="description" rows="4" class="form-control" placeholder="Include relevant details, room/area, or urgency..." required></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Photo (optional, max 2MB)</label>
                <input type="file" name="photo" accept="image/*" class="form-control">
            </div>

            <div class="d-flex gap-2">
                <button class="btn btn-primary btn-lg">Submit Service Request</button>
                <a class="btn btn-secondary btn-lg" href="<?= url('customer/services.php') ?>">Cancel</a>
            </div>
        </form>
    </div>
    <div class="col-lg-4">
        <div class="card">
            <div class="card-header">How Matching Works</div>
            <div class="card-body small">
                <ol class="ps-3 mb-0">
                    <li class="mb-2"><b>Request:</b> Your need and address are shared with verified providers in the category.</li>
                    <li class="mb-2"><b>Quotes:</b> Providers propose a price, scope, and schedule window.</li>
                    <li class="mb-2"><b>Agreement:</b> Accept the best quote to lock in a confirmed booking.</li>
                    <li><b>Settlement:</b> Pay securely after service completion and leave a review.</li>
                </ol>
            </div>
        </div>
    </div>
</div>
<script>
document.addEventListener('DOMContentLoaded', function () {
    var sel = document.getElementById('address_select');
    var box = document.getElementById('new_address_fields');
    if (sel && box) {
        var sync = function () { box.style.display = sel.value === '0' ? 'block' : 'none'; };
        sel.addEventListener('change', sync);
        sync();
    }
});
</script>
<?php require INC . '/footer.php'; ?>
