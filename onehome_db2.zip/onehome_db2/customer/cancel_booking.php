<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
post_only();
$u = current_user();
$b = get_booking((int) ($_POST['id'] ?? 0));
if (!$b || (int) $b['customer_id'] !== (int) $u['customer_id']) {
    flash('Booking not found.', 'danger');
    redirect('customer/bookings.php');
}
if (!can_transition_booking($b['booking_status'], 'cancelled')) {
    flash('This booking can no longer be cancelled.', 'danger');
    redirect('customer/booking_details.php?id=' . $b['booking_id']);
}
$reason = trim($_POST['reason'] ?? 'Cancelled by customer');
$conn->beginTransaction();
db_exec(
    "UPDATE bookings SET booking_status = 'cancelled', cancellation_reason = ? WHERE booking_id = ? AND booking_status IN ('pending_confirmation','payment_failed','confirmed','rescheduled')",
    [$reason, $b['booking_id']]
);
if (db_affected_rows() === 1) {
    audit_log($u['user_id'], 'booking', $b['booking_id'], 'booking_cancelled', $reason);
    notify_user($b['provider_user_id'], 'Booking #' . $b['booking_id'] . ' Cancelled', $u['full_name'] . ' cancelled this booking.', 'employee/booking_details.php?id=' . $b['booking_id']);
    $conn->commit();
    flash('Your booking was cancelled.', 'info');
} else {
    $conn->rollBack();
    flash('This booking can no longer be cancelled.', 'warning');
}
redirect('customer/bookings.php');
