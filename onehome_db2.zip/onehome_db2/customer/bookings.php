<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'My Bookings';
$statuses = ['pending_confirmation', 'payment_failed', 'confirmed', 'rescheduled', 'in_progress', 'completed', 'settled', 'disputed', 'cancelled', 'refunded'];
$st = in_array($_GET['status'] ?? '', $statuses, true) ? $_GET['status'] : '';
$rows = $st
    ? list_bookings('sr.customer_id = ? AND b.booking_status = ?', [$custId, $st])
    : list_bookings('sr.customer_id = ?', [$custId]);
require INC . '/header.php'; ?>
<h2>My Bookings</h2>
<div class="mb-3 d-flex flex-wrap gap-1">
    <a class="btn btn-sm <?= $st ? 'btn-outline-dark' : 'btn-dark' ?>" href="bookings.php">All</a>
    <?php foreach ($statuses as $s): ?>
        <a class="btn btn-sm <?= $st === $s ? 'btn-dark' : 'btn-outline-dark' ?>" href="bookings.php?status=<?= $s ?>"><?= ucwords(str_replace('_', ' ', $s)) ?></a>
    <?php endforeach; ?>
</div>
<?php bookings_table($rows, 'customer'); ?>
<?php require INC . '/footer.php'; ?>
