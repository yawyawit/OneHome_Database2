<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'Payment History';
$rows = db_all(
    "SELECT p.*, b.agreed_price, b.booking_status, sc.category_name, so.title AS offering_title, pr.business_name
     FROM payments p
     JOIN bookings b ON b.booking_id = p.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     JOIN providers pr ON pr.provider_id = q.provider_id
     WHERE sr.customer_id = ?
     ORDER BY p.created_at DESC",
    [$custId]
);
require INC . '/header.php'; ?>
<h2>Payment Ledger History</h2>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No payment transactions yet.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped bg-white align-middle">
            <thead class="table-light">
                <tr><th>Booking</th><th>Service</th><th>Type</th><th>Method</th><th>Amount</th><th>Status</th><th>Reference</th><th>Date</th></tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $r): ?>
                    <tr>
                        <td><a href="<?= url('customer/booking_details.php?id=' . (int) $r['booking_id']) ?>">#<?= (int) $r['booking_id'] ?></a></td>
                        <td><?= e($r['offering_title']) ?><br><small class="text-muted"><?= e($r['business_name']) ?></small></td>
                        <td><?= badge($r['payment_type']) ?></td>
                        <td><?= pay_label($r['method']) ?><?= $r['card_last4'] ? ' (*' . e($r['card_last4']) . ')' : '' ?></td>
                        <td><?= money($r['amount']) ?> <?= e($r['currency']) ?></td>
                        <td><?= badge($r['payment_status']) ?></td>
                        <td><code><?= e($r['gateway_reference'] ?: '-') ?></code></td>
                        <td><?= fdatetime($r['created_at']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
