<?php require_once __DIR__ . '/../includes/auth.php';
require_role('customer');
$u = current_user();
$custId = (int) $u['customer_id'];
$title = 'Dashboard';
$categories = db_all("SELECT * FROM service_categories WHERE category_status='active' ORDER BY category_name LIMIT 4");
$openRequests = list_requests("sr.customer_id = ? AND sr.request_status IN ('open','matching')", [$custId], 'sr.created_at DESC');
$upcoming = list_bookings("sr.customer_id = ? AND b.booking_status IN ('pending_confirmation','payment_failed','confirmed','rescheduled','in_progress')", [$custId], 'b.scheduled_start ASC');
$completedRows = list_bookings("sr.customer_id = ? AND b.booking_status IN ('completed','settled')", [$custId]);
$toPay = 0;
foreach ($completedRows as $cr) {
    if ($cr['balance_due'] > 0) {
        $toPay++;
    }
}
require INC . '/header.php'; ?>
<div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2 mb-3">
    <div>
        <h2 class="mb-1">Welcome back, <?= e($u['full_name']) ?>!</h2>
        <p class="text-muted small mb-0">Request home services, compare provider quotes, and manage your bookings.</p>
    </div>
    <div class="d-flex flex-wrap gap-2">
        <a class="btn btn-primary btn-sm" href="<?= url('customer/request_service.php') ?>"><i class="bi bi-plus-circle me-1"></i> New Service Request</a>
        <a class="btn btn-outline-primary btn-sm" href="<?= url('customer/requests.php') ?>"><i class="bi bi-card-list me-1"></i> My Requests</a>
        <a class="btn btn-outline-primary btn-sm" href="<?= url('customer/bookings.php') ?>"><i class="bi bi-calendar-check me-1"></i> Bookings</a>
        <a class="btn btn-outline-secondary btn-sm" href="<?= url('customer/addresses.php') ?>"><i class="bi bi-geo-alt me-1"></i> Addresses</a>
    </div>
</div>

<form class="input-group my-3 mb-4" method="get" action="<?= url('customer/services.php') ?>">
    <input class="form-control" name="q" placeholder="Search service categories (e.g. plumbing, cleaning, electrical)...">
    <button class="btn btn-primary px-4"><i class="bi bi-search me-1"></i> Search</button>
</form>

<?php if ($toPay): ?>
    <div class="alert alert-warning d-flex align-items-center justify-content-between gap-2">
        <span><i class="bi bi-exclamation-triangle-fill me-2"></i>You have <b><?= $toPay ?></b> completed booking(s) with an unpaid balance.</span>
        <a class="btn btn-sm btn-warning" href="<?= url('customer/bookings.php?status=completed') ?>">View &amp; Pay</a>
    </div>
<?php endif; ?>

<div class="row">
    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-chat-square-quote me-2"></i>Active Service Requests</span>
                <span class="badge bg-info text-dark"><?= count($openRequests) ?></span>
            </div>
            <div class="card-body">
                <?php if (!$openRequests): ?>
                    <p class="text-muted mb-0">No open service requests. Submit a request to receive quotes from verified providers.</p>
                <?php else: ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach (array_slice($openRequests, 0, 4) as $r): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center gap-2 px-0">
                                <div>
                                    <b><?= e($r['category_name']) ?></b> &middot; <?= badge($r['request_status']) ?>
                                    <div class="small text-muted"><?= e($r['street_address']) ?>, <?= e($r['city']) ?> &middot; <b><?= (int) $r['pending_quote_count'] ?></b> pending quote(s)</div>
                                </div>
                                <a class="btn btn-sm btn-outline-primary" href="<?= url('customer/request_details.php?id=' . $r['request_id']) ?>">Compare Quotes</a>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <div class="col-lg-6 mb-4">
        <div class="card h-100">
            <div class="card-header d-flex justify-content-between align-items-center">
                <span><i class="bi bi-calendar2-week me-2"></i>Upcoming Bookings</span>
                <span class="badge bg-primary"><?= count($upcoming) ?></span>
            </div>
            <div class="card-body">
                <?php if (!$upcoming): ?>
                    <p class="text-muted mb-0">No upcoming bookings yet.</p>
                <?php else: ?>
                    <ul class="list-group list-group-flush">
                        <?php foreach (array_slice($upcoming, 0, 4) as $b): ?>
                            <li class="list-group-item d-flex justify-content-between align-items-center gap-2 px-0">
                                <div>
                                    <b><?= e($b['offering_title']) ?></b> with <?= e($b['provider_business_name']) ?>
                                    <div class="small text-muted"><?= fdatetime($b['scheduled_start']) ?></div>
                                </div>
                                <span class="d-flex align-items-center gap-2"><?= badge($b['booking_status']) ?> <a class="btn btn-sm btn-outline-primary" href="<?= url('customer/booking_details.php?id=' . $b['booking_id']) ?>">View</a></span>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div class="d-flex justify-content-between align-items-center mb-3">
    <h4 class="mb-0">Service Categories</h4>
    <a class="btn btn-sm btn-outline-primary" href="<?= url('customer/services.php') ?>">See all categories &raquo;</a>
</div>
<div class="row"><?php foreach ($categories as $s) echo service_card($s); ?></div>
<?php require INC . '/footer.php'; ?>
