</main>
<footer class="oh-footer text-center small">
    <div class="container d-flex flex-column flex-sm-row justify-content-between align-items-center gap-2">
        <span><span class="oh-footer-accent"><i class="bi bi-house-heart-fill me-1"></i>One Home</span> &copy;
            <?= date('Y') ?> &mdash; Trusted Home Service Booking</span>
        <span>Baguio City &middot; Pine Green Soft UI</span>
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= url('js/script.js') ?>"></script>
</body>

</html>
