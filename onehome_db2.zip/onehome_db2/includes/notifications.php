<?php
function show_flash()
{
    if (!empty($_SESSION['flash'])) {
        list($m, $t) = $_SESSION['flash'];
        unset($_SESSION['flash']);
        $icons = [
            'success' => 'bi-check-circle-fill',
            'danger' => 'bi-exclamation-octagon-fill',
            'warning' => 'bi-exclamation-triangle-fill',
            'info' => 'bi-info-circle-fill',
        ];
        $icon = $icons[$t] ?? 'bi-bell-fill';
        echo '<div class="alert alert-' . e($t) . ' alert-dismissible fade show d-flex align-items-center gap-2" role="alert">'
            . '<i class="bi ' . $icon . ' fs-5"></i>'
            . '<div class="flex-grow-1">' . e($m) . '</div>'
            . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
    }
}

function notify_user($userId, $title, $message, $link = null)
{
    if (!$userId) {
        return 0;
    }
    return db_exec(
        "INSERT INTO notifications (user_id, title, message, link) VALUES (?, ?, ?, ?)",
        [(int) $userId, $title, $message, $link]
    );
}

function unread_notifications_count($userId)
{
    return (int) db_val("SELECT COUNT(*) FROM notifications WHERE user_id = ? AND is_read = 0", [(int) $userId]);
}

function user_notifications($userId, $limit = 25)
{
    $limit = max(1, min(100, (int) $limit));
    return db_all("SELECT * FROM notifications WHERE user_id = ? ORDER BY is_read ASC, created_at DESC LIMIT $limit", [(int) $userId]);
}

function mark_notification_read($notificationId, $userId)
{
    db_exec("UPDATE notifications SET is_read = 1 WHERE notification_id = ? AND user_id = ?", [(int) $notificationId, (int) $userId]);
}

function mark_all_notifications_read($userId)
{
    db_exec("UPDATE notifications SET is_read = 1 WHERE user_id = ? AND is_read = 0", [(int) $userId]);
}

// Count open/matching service requests eligible for this provider that they haven't quoted yet
function new_requests_count($providerId)
{
    return (int) db_val(
        "SELECT COUNT(DISTINCT sr.request_id)
         FROM service_requests sr
         JOIN service_offerings so ON so.category_id = sr.category_id
         WHERE so.provider_id = ?
           AND so.offering_status = 'active'
           AND sr.request_status IN ('open', 'matching')
           AND NOT EXISTS (
               SELECT 1 FROM quotes q
               WHERE q.request_id = sr.request_id AND q.provider_id = ? AND q.quote_status IN ('pending','accepted')
           )",
        [(int) $providerId, (int) $providerId]
    );
}

function pending_employees_count()
{
    return (int) db_val("SELECT COUNT(*) FROM providers WHERE verification_status = 'pending'");
}

function open_disputes_count()
{
    return (int) db_val("SELECT COUNT(*) FROM disputes WHERE dispute_status IN ('open', 'under_review')");
}
