<?php require_once __DIR__ . '/notifications.php';
$u = current_user();
$cssVer = @filemtime(__DIR__ . '/../css/style.css') ?: '1'; ?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#1E4D3B">
    <title><?= e($title ?? 'One Home') ?> | One Home</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap"
        rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="<?= url('css/style.css?v=' . $cssVer) ?>" rel="stylesheet">
</head>

<body>
    <?php require __DIR__ . '/navbar.php'; ?>
    <main class="container py-4">
        <?php show_flash(); ?>
