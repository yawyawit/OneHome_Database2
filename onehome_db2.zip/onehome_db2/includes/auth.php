<?php
// Included at the top of every page: starts the session and loads core helpers.
if (session_status() === PHP_SESSION_NONE) {
    ini_set('session.use_strict_mode', '1');
    ini_set('session.use_only_cookies', '1');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => !empty($_SERVER['HTTPS']) && strtolower((string) $_SERVER['HTTPS']) !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

define('INC', __DIR__);
require_once INC . '/dbconn.php';
require_once INC . '/functions.php';
require_once INC . '/notifications.php';

function csrf_token()
{
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field()
{
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf()
{
    $sent = (string) ($_POST['csrf_token'] ?? '');
    if ($sent === '' || !hash_equals(csrf_token(), $sent)) {
        http_response_code(403);
        flash('Security check failed (expired form). Please try again.', 'danger');
        $ref = $_SERVER['HTTP_REFERER'] ?? '';
        if ($ref) {
            header('Location: ' . $ref);
            exit;
        }
        redirect('index.php');
    }
}

function current_user($refresh = false)
{
    static $user = null;
    if ($refresh) {
        $user = null;
    }
    if ($user === null && !empty($_SESSION['uid'])) {
        $row = db_one(
            "SELECT u.*,
                    c.customer_id, c.username AS customer_username,
                    p.provider_id, p.business_name, p.verification_status, p.provider_status,
                    p.skills, p.service_area, p.available_days, p.is_available,
                    a.admin_id, a.admin_level
             FROM users u
             LEFT JOIN customers c ON c.user_id = u.user_id
             LEFT JOIN providers p ON p.user_id = u.user_id
             LEFT JOIN admins a ON a.user_id = u.user_id
             WHERE u.user_id = ?",
            [$_SESSION['uid']]
        );
        if ($row) {
            // Backward-compatible keys used in templates
            $row['id'] = (int) $row['user_id'];
            $row['name'] = $row['full_name'];
            $row['status'] = $row['account_status'];

            $roles = [];
            if (!empty($row['admin_id'])) {
                $roles[] = 'admin';
            }
            if (!empty($row['provider_id']) && $row['verification_status'] === 'verified' && $row['provider_status'] === 'active') {
                $roles[] = 'employee';
            }
            if (!empty($row['customer_id'])) {
                $roles[] = 'customer';
            }
            $row['available_roles'] = $roles;

            $active = $_SESSION['active_role'] ?? '';
            if (!in_array($active, $roles, true)) {
                $active = $roles[0] ?? '';
                if ($active !== '') {
                    $_SESSION['active_role'] = $active;
                }
            }
            $row['role'] = $active;
            $user = $row;
        }
    }
    return $user;
}

function role_home_routes()
{
    return [
        'admin' => 'admin/dashboard.php',
        'employee' => 'employee/dashboard.php',
        'customer' => 'customer/dashboard.php',
    ];
}

function home_for($role)
{
    $routes = role_home_routes();
    return $routes[$role] ?? 'index.php';
}

function require_role($role)
{
    require_roles([$role]);
}

function require_roles(array $roles)
{
    $u = current_user();
    $routes = role_home_routes();
    if (!$u || $u['account_status'] !== 'active' || empty($u['available_roles'])) {
        unset($_SESSION['uid'], $_SESSION['active_role']);
        session_regenerate_id(true);
        flash('Please log in first.', 'warning');
        redirect('login.php');
    }

    // Check if the user possesses any of the allowed workspace roles
    $matched = null;
    foreach ($roles as $r) {
        $normalized = $r === 'provider' ? 'employee' : $r;
        if (in_array($normalized, $u['available_roles'], true)) {
            $matched = $normalized;
            break;
        }
    }

    if ($matched === null) {
        flash('Access denied. You are not allowed to open that page.', 'danger');
        redirect(home_for($u['role']));
    }

    // If the user has multiple roles (BR-03), automatically switch workspace when visiting an allowed route
    if (!in_array($u['role'], $roles, true)) {
        $_SESSION['active_role'] = $matched;
        current_user(true);
    }
}
