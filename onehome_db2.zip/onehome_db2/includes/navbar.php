<nav class="navbar navbar-expand-lg oh-navbar">
    <div class="container">
        <a class="navbar-brand" href="<?= url($u ? home_for($u['role']) : 'index.php') ?>">
            <span class="oh-brand-mark"><i class="bi bi-house-heart-fill"></i></span>
            <span>One Home</span>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#nav"
            aria-controls="nav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="bi bi-list fs-4"></i>
        </button>
        <div class="collapse navbar-collapse" id="nav">
            <ul class="navbar-nav me-auto my-2 my-lg-0">
                <?php
                $links = [];
                $currentScript = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '');
                if ($u && $u['account_status'] === 'active') {
                    if ($u['role'] === 'customer') {
                        $links = [
                            'customer/dashboard.php' => 'Home',
                            'customer/services.php' => 'Services',
                            'customer/requests.php' => 'My Requests',
                            'customer/bookings.php' => 'Bookings',
                            'customer/payment_history.php' => 'Payments',
                            'customer/disputes.php' => 'Disputes',
                            'customer/profile.php' => 'Profile',
                        ];
                    } elseif ($u['role'] === 'employee') {
                        $links = [
                            'employee/dashboard.php' => 'Dashboard',
                            'employee/booking_requests.php' => 'Open Requests',
                            'employee/my_quotes.php' => 'My Quotes',
                            'employee/offerings.php' => 'Offerings',
                            'employee/my_schedule.php' => 'Schedule',
                            'employee/my_jobs.php' => 'Jobs',
                            'employee/earnings.php' => 'Earnings',
                            'employee/disputes.php' => 'Disputes',
                            'employee/profile.php' => 'Profile',
                        ];
                    } elseif ($u['role'] === 'admin') {
                        $links = [
                            'admin/dashboard.php' => 'Dashboard',
                            'admin/users/index.php' => 'Users',
                            'admin/services/index.php' => 'Categories',
                            'admin/bookings/index.php' => 'Bookings',
                            'admin/payments/index.php' => 'Payments',
                            'admin/payouts/index.php' => 'Payouts',
                            'admin/disputes/index.php' => 'Disputes',
                            'admin/reviews/index.php' => 'Reviews',
                            'admin/reports/index.php' => 'Reports',
                        ];
                    }
                }
                foreach ($links as $href => $label) {
                    $n = 0;
                    if ($href === 'employee/booking_requests.php' && !empty($u['provider_id'])) {
                        $n = new_requests_count($u['provider_id']);
                    } elseif ($href === 'admin/users/index.php') {
                        $n = pending_employees_count();
                    } elseif ($href === 'admin/disputes/index.php') {
                        $n = open_disputes_count();
                    }
                    $isActive = substr($currentScript, -strlen($href)) === $href ? ' active' : '';
                    echo '<li class="nav-item"><a class="nav-link' . $isActive . '" href="' . url($href) . '">' . $label . ($n ? ' <span class="badge bg-danger ms-1">' . $n . '</span>' : '') . '</a></li>';
                }
                ?>
            </ul>
            <ul class="navbar-nav align-items-lg-center gap-2">
                <?php if ($u && $u['account_status'] === 'active'): ?>
                    <?php $unreadNotifs = unread_notifications_count($u['user_id']); ?>
                    <li class="nav-item">
                        <a class="btn btn-outline-secondary btn-sm position-relative" href="<?= url('notifications.php') ?>" title="Notifications">
                            <i class="bi bi-bell"></i>
                            <?php if ($unreadNotifs > 0): ?>
                                <span class="badge bg-danger ms-1"><?= $unreadNotifs ?></span>
                            <?php endif; ?>
                        </a>
                    </li>
                    <?php if (count($u['available_roles']) > 1): ?>
                        <li class="nav-item dropdown">
                            <a class="btn btn-outline-primary btn-sm dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown">
                                <?= $u['role'] === 'employee' ? 'Provider Mode' : ucfirst($u['role']) . ' Mode' ?>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end">
                                <?php foreach ($u['available_roles'] as $r): ?>
                                    <li>
                                        <form method="post" action="<?= url('actions/switch_role.php') ?>">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="role" value="<?= e($r) ?>">
                                            <button class="dropdown-item <?= $r === $u['role'] ? 'active' : '' ?>">
                                                Switch to <?= $r === 'employee' ? 'Provider' : ucfirst($r) ?>
                                            </button>
                                        </form>
                                    </li>
                                <?php endforeach; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                    <li class="nav-item">
                        <span class="oh-user-pill">
                            <span class="oh-role-dot"></span>
                            <span><?= e($u['full_name']) ?></span>
                            <span class="text-muted fw-normal">(<?= $u['role'] === 'employee' ? 'provider' : e($u['role']) ?>)</span>
                        </span>
                    </li>
                    <li class="nav-item">
                        <a class="btn btn-outline-primary btn-sm" href="<?= url('logout.php') ?>">
                            <i class="bi bi-box-arrow-right me-1"></i>Logout
                        </a>
                    </li>
                <?php else: ?>
                    <?php
                    $isLogin = substr($currentScript, -strlen('login.php')) === 'login.php' ? ' active' : '';
                    $isReg = substr($currentScript, -strlen('register.php')) === 'register.php' ? ' active' : '';
                    ?>
                    <li class="nav-item"><a class="nav-link<?= $isLogin ?>" href="<?= url('login.php') ?>">Login</a></li>
                    <li class="nav-item"><a class="btn btn-primary btn-sm px-3<?= $isReg ?>"
                            href="<?= url('register.php') ?>">Get Started</a></li>
                <?php endif; ?>
            </ul>
        </div>
    </div>
</nav>
