<?php
define('PLATFORM_FEE_RATE', 0.10);

function e($s)
{
    return htmlspecialchars((string) $s, ENT_QUOTES, 'UTF-8');
}

function url($p)
{
    return BASE_URL . '/' . ltrim($p, '/');
}

function redirect($p)
{
    header('Location: ' . url($p));
    exit;
}

function flash($msg, $type = 'success')
{
    $_SESSION['flash'] = [$msg, $type];
}

function post_only()
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        http_response_code(405);
        die('Invalid request.');
    }
    if (function_exists('verify_csrf')) {
        verify_csrf();
    }
}

function money($n)
{
    return '₱' . number_format((float) $n, 2);
}

function fdate($d)
{
    return $d ? date('M d, Y', strtotime($d)) : '-';
}

function ftime($t)
{
    return $t ? date('g:i A', strtotime($t)) : '-';
}

function fdatetime($dt)
{
    return $dt ? date('M d, Y g:i A', strtotime($dt)) : '-';
}

function stars($n)
{
    $n = (int) round((float) $n);
    $n = max(0, min(5, $n));
    return '<span class="star">' . str_repeat('★', $n) . str_repeat('☆', 5 - $n) . '</span>';
}

function rating_text($avg, $count)
{
    return $count ? stars($avg) . ' ' . $avg . ' (' . $count . ')' : '<span class="text-muted">No ratings yet</span>';
}

function badge($s)
{
    $key = strtolower((string) $s);
    $map = [
        'open' => ['primary', 'Open'],
        'matching' => ['info text-dark', 'Matching Quotes'],
        'booked' => ['success', 'Booked'],
        'closed' => ['secondary', 'Closed'],
        'pending' => ['warning text-dark', 'Pending'],
        'pending_confirmation' => ['warning text-dark', 'Pending Confirmation'],
        'payment_failed' => ['danger', 'Payment Failed'],
        'confirmed' => ['info text-dark', 'Confirmed'],
        'rescheduled' => ['info text-dark', 'Rescheduled'],
        'in_progress' => ['primary', 'In Progress'],
        'completed' => ['success', 'Completed'],
        'settled' => ['success', 'Settled'],
        'cancelled' => ['secondary', 'Cancelled'],
        'declined' => ['danger', 'Declined'],
        'rejected' => ['danger', 'Rejected'],
        'withdrawn' => ['secondary', 'Withdrawn'],
        'expired' => ['secondary', 'Expired'],
        'accepted' => ['success', 'Accepted'],
        'disputed' => ['danger', 'Disputed'],
        'refunded' => ['dark', 'Refunded'],
        'successful' => ['success', 'Successful'],
        'paid' => ['success', 'Paid'],
        'unpaid' => ['warning text-dark', 'Unpaid'],
        'partially_paid' => ['info text-dark', 'Partial'],
        'processing' => ['primary', 'Processing'],
        'failed' => ['danger', 'Failed'],
        'reversed' => ['dark', 'Reversed'],
        'under_review' => ['warning text-dark', 'Under Review'],
        'resolved' => ['success', 'Resolved'],
        'active' => ['success', 'Active'],
        'verified' => ['success', 'Verified'],
        'suspended' => ['danger', 'Suspended'],
        'inactive' => ['danger', 'Inactive'],
        'authorization' => ['info text-dark', 'Authorization'],
        'capture' => ['success', 'Capture'],
        'refund' => ['dark', 'Refund'],
        'adjustment' => ['secondary', 'Adjustment'],
        'fixed' => ['primary', 'Fixed Price'],
        'quotation' => ['info text-dark', 'Quotation'],
    ];
    $cfg = $map[$key] ?? ['secondary', ucwords(str_replace('_', ' ', (string) $s))];
    return '<span class="badge bg-' . $cfg[0] . '">' . e($cfg[1]) . '</span>';
}

function pay_label($m)
{
    return $m === 'card' ? 'Card (simulated)' : 'Cash after service';
}

// ---------- Database helpers (prepared statements) ----------
function db_run($sql, $params = [])
{
    global $conn;
    try {
        $st = $conn->prepare($sql);
        $st->execute($params);
        return $st;
    } catch (PDOException $e) {
        error_log('Database query failed: ' . $e->getMessage());
        if ($conn->inTransaction()) {
            $conn->rollBack();
        }
        http_response_code(500);
        exit('A database error occurred: ' . e($e->getMessage()));
    }
}

function db_all($sql, $params = [])
{
    return db_run($sql, $params)->fetchAll();
}

function db_one($sql, $params = [])
{
    $a = db_all($sql, $params);
    return $a ? $a[0] : null;
}

function db_val($sql, $params = [])
{
    $r = db_one($sql, $params);
    return $r ? array_values($r)[0] : 0;
}

function db_exec($sql, $params = [])
{
    global $conn;
    $st = db_run($sql, $params);
    $GLOBALS['db_last_statement'] = $st;
    return $conn->lastInsertId();
}

function db_affected_rows()
{
    return isset($GLOBALS['db_last_statement']) ? $GLOBALS['db_last_statement']->rowCount() : 0;
}

function audit_log($actorUserId, $entityType, $entityId, $action, $details = '')
{
    db_exec(
        "INSERT INTO audit_logs (actor_user_id, entity_type, entity_id, action, details) VALUES (?, ?, ?, ?, ?)",
        [$actorUserId ? (int) $actorUserId : null, $entityType, (int) $entityId, $action, $details]
    );
}

// ---------- Uploads & avatars ----------
function save_upload($field, $folder)
{
    if (empty($_FILES[$field]['name']) || $_FILES[$field]['error'] !== 0) {
        return '';
    }
    $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, ['jpg', 'jpeg', 'png', 'gif'], true) || $_FILES[$field]['size'] > 2 * 1024 * 1024 || !@getimagesize($_FILES[$field]['tmp_name'])) {
        return '';
    }
    $name = uniqid('img_') . '.' . $ext;
    move_uploaded_file($_FILES[$field]['tmp_name'], __DIR__ . '/../' . $folder . '/' . $name);
    return $name;
}

function avatar($name, $file = '', $size = 60)
{
    if ($file && file_exists(__DIR__ . '/../images/profiles/' . $file)) {
        return '<img src="' . url('images/profiles/' . $file) . '" class="avatar" style="width:' . $size . 'px;height:' . $size . 'px">';
    }
    return '<span class="avatar-initial" style="width:' . $size . 'px;height:' . $size . 'px;font-size:' . ($size / 2.5) . 'px">' . e(strtoupper(substr((string) $name, 0, 1))) . '</span>';
}

// ---------- Schedule & State Machine Rules ----------
function works_on($provider, $date)
{
    $days = array_filter(explode(',', (string) ($provider['available_days'] ?? '')));
    return in_array(date('D', strtotime($date)), $days, true);
}

function provider_free($providerId, $startDt, $endDt, $ignoreBookingId = 0)
{
    return (int) db_val(
        "SELECT COUNT(*)
         FROM bookings b
         JOIN quotes q ON q.quote_id = b.quote_id
         WHERE q.provider_id = ?
           AND b.booking_id <> ?
           AND b.booking_status IN ('confirmed', 'in_progress', 'rescheduled')
           AND b.scheduled_start < ?
           AND b.scheduled_end > ?",
        [(int) $providerId, (int) $ignoreBookingId, $endDt, $startDt]
    ) === 0;
}

function booking_allowed_transitions()
{
    return [
        'pending_confirmation' => ['confirmed', 'payment_failed', 'cancelled'],
        'payment_failed' => ['pending_confirmation', 'confirmed', 'cancelled'],
        'confirmed' => ['in_progress', 'rescheduled', 'cancelled', 'disputed'],
        'rescheduled' => ['confirmed', 'in_progress', 'cancelled', 'disputed'],
        'in_progress' => ['completed', 'cancelled', 'disputed'],
        'completed' => ['settled', 'disputed', 'refunded'],
        'disputed' => ['completed', 'settled', 'refunded'],
        'cancelled' => [],
        'settled' => [],
        'refunded' => [],
    ];
}

function can_transition_booking($fromStatus, $toStatus)
{
    $map = booking_allowed_transitions();
    return in_array($toStatus, $map[$fromStatus] ?? [], true);
}

function expire_stale_quotes()
{
    db_exec("UPDATE quotes SET quote_status = 'expired' WHERE quote_status = 'pending' AND valid_until < NOW()");
}

// ---------- Financial Ledger Summary ----------
function booking_financials($bookingId, $agreedPrice = null)
{
    if ($agreedPrice === null) {
        $agreedPrice = (float) db_val("SELECT agreed_price FROM bookings WHERE booking_id = ?", [(int) $bookingId]);
    } else {
        $agreedPrice = (float) $agreedPrice;
    }

    $rows = db_all("SELECT payment_type, payment_status, amount, method, card_last4, gateway_reference, created_at FROM payments WHERE booking_id = ? ORDER BY created_at DESC", [(int) $bookingId]);
    $authorized = 0.0;
    $captured = 0.0;
    $refunded = 0.0;
    $adjusted = 0.0;
    $lastMethod = 'cash';
    $lastCard = null;
    $lastPaidAt = null;
    $hasFailedAuth = false;

    foreach ($rows as $r) {
        if ($r['method']) {
            $lastMethod = $r['method'];
        }
        if ($r['card_last4']) {
            $lastCard = $r['card_last4'];
        }
        if ($r['payment_status'] === 'successful') {
            if ($r['payment_type'] === 'authorization') {
                $authorized += (float) $r['amount'];
            } elseif ($r['payment_type'] === 'capture') {
                $captured += (float) $r['amount'];
                if ($lastPaidAt === null) {
                    $lastPaidAt = $r['created_at'];
                }
            } elseif ($r['payment_type'] === 'refund') {
                $refunded += (float) $r['amount'];
            } elseif ($r['payment_type'] === 'adjustment') {
                $adjusted += (float) $r['amount'];
            }
        } elseif ($r['payment_status'] === 'failed' && $r['payment_type'] === 'authorization') {
            $hasFailedAuth = true;
        }
    }

    $netCollected = max(0.0, round($captured - $refunded + $adjusted, 2));
    $netCaptured = max(0.0, round($captured - $refunded, 2));
    $balanceDue = max(0.0, round($agreedPrice - $captured, 2));

    $eligibleEarnings = round($netCaptured * (1.0 - PLATFORM_FEE_RATE), 2);
    $payoutActive = (float) db_val(
        "SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE booking_id = ? AND payout_status IN ('pending','processing','paid')",
        [(int) $bookingId]
    );
    $payoutPaid = (float) db_val(
        "SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE booking_id = ? AND payout_status = 'paid'",
        [(int) $bookingId]
    );
    $remainingPayout = max(0.0, round($eligibleEarnings - $payoutActive, 2));

    $pstatus = 'unpaid';
    if ($refunded > 0 && $refunded >= $captured && $captured > 0) {
        $pstatus = 'refunded';
    } elseif ($captured >= $agreedPrice && $agreedPrice > 0) {
        $pstatus = 'paid';
    } elseif ($captured > 0) {
        $pstatus = 'partially_paid';
    } elseif ($hasFailedAuth) {
        $pstatus = 'failed';
    }

    return [
        'agreed_price' => $agreedPrice,
        'authorized' => round($authorized, 2),
        'captured' => round($captured, 2),
        'refunded' => round($refunded, 2),
        'adjusted' => round($adjusted, 2),
        'net_collected' => $netCollected,
        'balance_due' => $balanceDue,
        'eligible_earnings' => $eligibleEarnings,
        'payout_active' => round($payoutActive, 2),
        'payout_paid' => round($payoutPaid, 2),
        'remaining_payout' => $remainingPayout,
        'pstatus' => $pstatus,
        'method' => $lastMethod,
        'card_last4' => $lastCard,
        'paid_at' => $lastPaidAt,
        'records' => $rows,
    ];
}

// ---------- Service Requests & Bookings Queries ----------
function list_requests($where = '1', $params = [], $order = 'sr.created_at DESC')
{
    expire_stale_quotes();
    return db_all(
        "SELECT sr.*,
                sc.category_name, sc.icon AS category_icon, sc.default_price,
                a.address_label, a.street_address, a.city, a.province, a.postal_code,
                c.user_id AS customer_user_id, cu.full_name AS customer_name, cu.phone AS customer_phone, cu.email AS customer_email,
                so.title AS preferred_offering_title, so.pricing_type AS preferred_pricing_type, so.base_price AS preferred_base_price,
                p_pref.provider_id AS preferred_provider_id, p_pref.business_name AS preferred_business_name,
                (SELECT COUNT(*) FROM quotes q WHERE q.request_id = sr.request_id) AS quote_count,
                (SELECT COUNT(*) FROM quotes q WHERE q.request_id = sr.request_id AND q.quote_status = 'pending') AS pending_quote_count,
                (SELECT b.booking_id FROM bookings b WHERE b.request_id = sr.request_id LIMIT 1) AS booking_id
         FROM service_requests sr
         JOIN service_categories sc ON sc.category_id = sr.category_id
         JOIN addresses a ON a.address_id = sr.address_id
         JOIN customers c ON c.customer_id = sr.customer_id
         JOIN users cu ON cu.user_id = c.user_id
         LEFT JOIN service_offerings so ON so.offering_id = sr.preferred_offering_id
         LEFT JOIN providers p_pref ON p_pref.provider_id = so.provider_id
         WHERE $where
         ORDER BY $order",
        $params
    );
}

function get_request($id)
{
    $r = list_requests('sr.request_id = ?', [(int) $id]);
    return $r ? $r[0] : null;
}

function list_bookings($where = '1', $params = [], $order = 'b.scheduled_start DESC')
{
    $rows = db_all(
        "SELECT b.*,
                b.booking_id AS id,
                b.agreed_price AS price,
                b.booking_status AS status,
                DATE(b.scheduled_start) AS booking_date,
                TIME(b.scheduled_start) AS booking_time,
                sr.customer_id, sr.category_id, sr.address_id, sr.description, sr.photo,
                sr.service_snapshot_title, sr.service_snapshot_price, sr.request_status,
                sc.category_name AS sname, sc.category_name,
                CONCAT(a.street_address, ', ', a.city, ', ', a.province) AS address,
                a.address_label, a.street_address, a.city, a.province,
                q.provider_id, q.offering_id, q.scope AS quote_scope, q.proposed_price,
                so.title AS offering_title, so.pricing_type,
                c.user_id AS customer_user_id, cu.full_name AS cname, cu.phone AS cphone, cu.email AS cemail,
                p.user_id AS provider_user_id, p.business_name AS provider_business_name,
                pu.full_name AS ename, pu.phone AS ephone, pu.email AS eemail,
                (SELECT COUNT(*) FROM reviews r WHERE r.booking_id = b.booking_id) AS reviewed,
                (SELECT COUNT(*) FROM disputes d WHERE d.booking_id = b.booking_id AND d.dispute_status IN ('open','under_review')) AS open_disputes
         FROM bookings b
         JOIN service_requests sr ON sr.request_id = b.request_id
         JOIN quotes q ON q.quote_id = b.quote_id
         JOIN service_categories sc ON sc.category_id = sr.category_id
         JOIN service_offerings so ON so.offering_id = q.offering_id
         JOIN addresses a ON a.address_id = sr.address_id
         JOIN customers c ON c.customer_id = sr.customer_id
         JOIN users cu ON cu.user_id = c.user_id
         JOIN providers p ON p.provider_id = q.provider_id
         JOIN users pu ON pu.user_id = p.user_id
         WHERE $where
         ORDER BY $order",
        $params
    );

    foreach ($rows as &$row) {
        $fin = booking_financials($row['booking_id'], $row['agreed_price']);
        $row['pstatus'] = $fin['pstatus'];
        $row['pmethod'] = $fin['method'];
        $row['card_last4'] = $fin['card_last4'];
        $row['paid_at'] = $fin['paid_at'];
        $row['captured_total'] = $fin['captured'];
        $row['refunded_total'] = $fin['refunded'];
        $row['balance_due'] = $fin['balance_due'];
        $row['eligible_earnings'] = $fin['eligible_earnings'];
        $row['payout_paid'] = $fin['payout_paid'];
    }
    return $rows;
}

function get_booking($id)
{
    $r = list_bookings('b.booking_id = ?', [(int) $id]);
    return $r ? $r[0] : null;
}

function booking_info($b)
{ ?>
    <div class="table-responsive mb-3">
        <table class="table table-bordered bg-white">
            <tr>
                <th width="28%">Booking #</th>
                <td>#<?= (int) $b['booking_id'] ?> <small class="text-muted">(Request #<?= (int) $b['request_id'] ?> &middot; Quote #<?= (int) $b['quote_id'] ?>)</small></td>
            </tr>
            <tr>
                <th>Service</th>
                <td><?= e($b['category_name']) ?> &mdash; <b><?= e($b['offering_title']) ?></b> (<?= badge($b['pricing_type']) ?>)</td>
            </tr>
            <tr>
                <th>Customer</th>
                <td><?= e($b['cname']) ?> &middot; <?= e($b['cphone']) ?> &middot; <?= e($b['cemail']) ?></td>
            </tr>
            <tr>
                <th>Service Provider</th>
                <td><?= e($b['provider_business_name']) ?> (<?= e($b['ename']) ?>) &middot; <?= e($b['ephone']) ?></td>
            </tr>
            <tr>
                <th>Appointment Schedule</th>
                <td><?= fdatetime($b['scheduled_start']) ?> to <?= ftime($b['scheduled_end']) ?></td>
            </tr>
            <tr>
                <th>Service Location</th>
                <td><?= $b['address_label'] ? '<span class="badge bg-light text-dark border me-1">' . e($b['address_label']) . '</span>' : '' ?><?= e($b['address']) ?></td>
            </tr>
            <tr>
                <th>Scope &amp; Work Details</th>
                <td>
                    <div><?= nl2br(e($b['description'])) ?></div>
                    <?php if (!empty($b['quote_scope'])): ?>
                        <div class="small text-muted mt-1"><b>Agreed Quote Scope:</b> <?= nl2br(e($b['quote_scope'])) ?></div>
                    <?php endif; ?>
                </td>
            </tr>
            <?php if (!empty($b['photo'])): ?>
                <tr>
                    <th>Photo</th>
                    <td><img src="<?= url('uploads/' . $b['photo']) ?>" class="img-thumbnail" style="max-width:250px"></td>
                </tr>
            <?php endif; ?>
            <tr>
                <th>Agreed Price</th>
                <td class="fw-bold"><?= money($b['agreed_price']) ?></td>
            </tr>
            <tr>
                <th>Payment Status</th>
                <td>
                    <?= pay_label($b['pmethod']) ?> &mdash; <?= badge($b['pstatus']) ?>
                    <span class="small text-muted ms-2">Captured: <?= money($b['captured_total']) ?> &middot; Balance: <?= money($b['balance_due']) ?></span>
                    <?php if ($b['refunded_total'] > 0): ?>
                        <span class="small text-danger ms-2">Refunded: <?= money($b['refunded_total']) ?></span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Booking Status</th>
                <td>
                    <?= badge($b['booking_status']) ?>
                    <?php if (!empty($b['completed_at'])): ?>
                        <small class="text-muted ms-2">Completed on <?= fdatetime($b['completed_at']) ?></small>
                    <?php endif; ?>
                    <?php if (!empty($b['cancellation_reason'])): ?>
                        <div class="small text-danger mt-1">Reason: <?= e($b['cancellation_reason']) ?></div>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
    </div>
<?php }

function bookings_table($rows, $role)
{
    if (!$rows) {
        echo '<div class="alert alert-secondary">No bookings found.</div>';
        return;
    }
    $link = [
        'customer' => 'customer/booking_details.php?id=',
        'employee' => 'employee/booking_details.php?id=',
        'admin' => 'admin/bookings/view.php?id=',
    ][$role]; ?>
    <div class="table-responsive">
        <table class="table table-striped table-hover bg-white align-middle">
            <thead class="table-light">
                <tr>
                    <th>#</th>
                    <th>Service</th>
                    <th><?= $role === 'customer' ? 'Provider' : 'Customer' ?></th>
                    <?php if ($role === 'admin'): ?><th>Provider</th><?php endif; ?>
                    <th>Schedule</th>
                    <th>Agreed Price</th>
                    <th>Booking</th>
                    <th>Payment</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $b): ?>
                    <tr>
                        <td>#<?= (int) $b['booking_id'] ?></td>
                        <td>
                            <div class="fw-semibold"><?= e($b['category_name']) ?></div>
                            <small class="text-muted"><?= e($b['offering_title']) ?></small>
                        </td>
                        <td><?= e($role === 'customer' ? $b['provider_business_name'] : $b['cname']) ?></td>
                        <?php if ($role === 'admin'): ?>
                            <td><?= e($b['provider_business_name']) ?></td>
                        <?php endif; ?>
                        <td><?= fdate($b['scheduled_start']) ?><br><small><?= ftime($b['scheduled_start']) ?> - <?= ftime($b['scheduled_end']) ?></small></td>
                        <td><?= money($b['agreed_price']) ?></td>
                        <td><?= badge($b['booking_status']) ?></td>
                        <td><?= badge($b['pstatus']) ?></td>
                        <td>
                            <a class="btn btn-sm btn-outline-primary" href="<?= url($link . $b['booking_id']) ?>">View</a>
                            <?php if ($role === 'employee') {
                                echo job_buttons($b);
                            } ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php }

function job_buttons($b)
{
    $id = (int) $b['booking_id'];
    $f = function ($file, $label, $class, $action = '') use ($id) {
        return '<form method="post" action="' . url('employee/' . $file) . '" class="d-inline">'
            . csrf_field()
            . '<input type="hidden" name="id" value="' . $id . '">'
            . ($action ? '<input type="hidden" name="action" value="' . e($action) . '">' : '')
            . '<button class="btn btn-sm btn-' . $class . '">' . $label . '</button></form> ';
    };
    $s = $b['booking_status'];
    $o = '';
    if (in_array($s, ['confirmed', 'rescheduled'], true)) {
        $o .= $f('update_job_status.php', 'Start Job', 'primary', 'start');
    } elseif ($s === 'in_progress') {
        $o .= $f('update_job_status.php', 'Mark Completed', 'success', 'complete');
    } elseif (in_array($s, ['completed', 'settled'], true) && $b['balance_due'] > 0 && $b['pmethod'] === 'cash') {
        $o .= $f('update_job_status.php', 'Cash Received', 'warning', 'paid');
    }
    return $o;
}

// ---------- Reusable UI pieces ----------
function stat_card($label, $value, $icon = 'bi-bar-chart', $color = 'primary')
{
    return '<div class="col-6 col-md-4 col-lg-3 mb-3">'
        . '<div class="card oh-stat-card oh-accent-' . e($color) . ' h-100">'
        . '<div class="card-body d-flex align-items-start gap-3">'
        . '<span class="oh-stat-icon"><i class="bi ' . e($icon) . '"></i></span>'
        . '<div><div class="text-muted small fw-semibold">' . e($label) . '</div>'
        . '<div class="fs-4 fw-bold mt-1">' . $value . '</div></div>'
        . '</div></div></div>';
}

function service_card($s, $book = true)
{
    $id = (int) ($s['category_id'] ?? $s['id']);
    $name = $s['category_name'] ?? $s['name'];
    $price = $s['default_price'] ?? $s['price'] ?? 0;
    ob_start(); ?>
    <div class="col-md-6 col-lg-3 mb-4">
        <div class="card oh-service-card h-100 text-center">
            <div class="card-body d-flex flex-column">
                <div class="oh-service-icon-wrap">
                    <i class="bi <?= e($s['icon']) ?> service-icon"></i>
                </div>
                <h5 class="mt-1 mb-2"><?= e($name) ?></h5>
                <p class="small text-muted flex-grow-1"><?= e($s['description']) ?></p>
                <div class="mt-2"><span class="oh-service-price">From <?= money($price) ?></span></div>
            </div>
            <?php if ($book): ?>
                <div class="card-footer d-flex justify-content-center gap-2">
                    <a class="btn btn-sm btn-outline-secondary"
                        href="<?= url('customer/service_details.php?id=' . $id) ?>">Details</a>
                    <a class="btn btn-sm btn-primary"
                        href="<?= url('customer/request_service.php?category_id=' . $id) ?>">Request Quotes</a>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <?php return ob_get_clean();
}

function service_form($s = null)
{
    $icons = [
        'bi-droplet-fill' => 'Droplet (Plumbing)',
        'bi-lightning-charge-fill' => 'Lightning (Electrical)',
        'bi-stars' => 'Stars (Cleaning)',
        'bi-wrench-adjustable' => 'Wrench (Repair)',
        'bi-bug-fill' => 'Bug (Pest Control)',
        'bi-paint-bucket' => 'Paint bucket',
        'bi-flower1' => 'Flower (Gardening)',
        'bi-tools' => 'Tools (Other)',
        'bi-house-gear-fill' => 'House (Other)',
    ];
    $name = $s['category_name'] ?? '';
    $price = $s['default_price'] ?? '';
    $active = ($s['category_status'] ?? 'active') === 'active'; ?>
    <form method="post" class="card card-body">
        <?= csrf_field() ?>
        <label class="form-label">Category Name</label>
        <input class="form-control mb-2" name="category_name" value="<?= e($name) ?>" required>
        <label class="form-label">Description</label>
        <textarea class="form-control mb-2" name="description" rows="3" required><?= e($s['description'] ?? '') ?></textarea>
        <label class="form-label">Typical Starting Price (₱)</label>
        <input type="number" min="0" step="0.01" class="form-control mb-2" name="default_price" value="<?= e($price) ?>" required>
        <label class="form-label">Icon</label>
        <select name="icon" class="form-select mb-3">
            <?php foreach ($icons as $k => $v): ?>
                <option value="<?= $k ?>" <?= ($s['icon'] ?? '') === $k ? 'selected' : '' ?>><?= $v ?></option>
            <?php endforeach; ?>
        </select>
        <?php if ($s): ?>
            <div class="form-check mb-3">
                <input type="checkbox" class="form-check-input" name="is_active" id="ia" <?= $active ? 'checked' : '' ?>>
                <label class="form-check-label" for="ia">Active (available for new offerings and requests)</label>
            </div>
        <?php endif; ?>
        <div>
            <button class="btn btn-primary">Save Category</button>
            <a class="btn btn-secondary" href="<?= url('admin/services/index.php') ?>">Cancel</a>
        </div>
    </form>
<?php }

function account_forms($u)
{ ?>
    <div class="row">
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header">Account Identity</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/process_profile.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="info">
                        <label class="form-label">Full Name</label>
                        <input class="form-control mb-2" name="name" value="<?= e($u['full_name']) ?>" required>
                        <label class="form-label">Email</label>
                        <input type="email" class="form-control mb-2" name="email" value="<?= e($u['email']) ?>" required>
                        <label class="form-label">Contact Number</label>
                        <input class="form-control mb-2" name="phone" value="<?= e($u['phone']) ?>" required>
                        <label class="form-label">Current Password <small class="text-muted">(required only when changing email or phone)</small></label>
                        <input type="password" class="form-control mb-3" name="current_password">
                        <button class="btn btn-primary">Save Changes</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6">
            <div class="card mb-4">
                <div class="card-header">Change Password</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/process_profile.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="action" value="password">
                        <label class="form-label">Current Password</label>
                        <input type="password" class="form-control mb-2" name="current_password" required>
                        <label class="form-label">New Password (min. 6 characters)</label>
                        <input type="password" class="form-control mb-2" name="new_password" minlength="6" required>
                        <label class="form-label">Confirm New Password</label>
                        <input type="password" class="form-control mb-3" name="confirm_password" required>
                        <button class="btn btn-warning">Change Password</button>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php }
