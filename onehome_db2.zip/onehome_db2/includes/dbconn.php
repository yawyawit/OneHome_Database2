<?php
try {
    $conn = new PDO(
        'mysql:host=localhost;port=3306;dbname=one_home;charset=utf8mb4',
        'root',
        '',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]
    );
} catch (PDOException $e) {
    error_log('Database connection failed: ' . $e->getMessage());
    http_response_code(500);
    exit('Database connection failed. Check the database service and configuration.');
}

$docroot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
$root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
define('BASE_URL', rtrim(substr($root, strlen($docroot)), '/'));
