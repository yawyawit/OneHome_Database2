<?php
require_once __DIR__ . '/includes/auth.php';
$u = current_user();
if ($u && $u['status'] === 'active')
    redirect(home_for($u['role']));
$title = 'Login';
require INC . '/header.php'; ?>
<div class="row justify-content-center py-3">
    <div class="col-md-6 col-lg-5">
        <div class="card">
            <div class="card-body p-4 p-md-5">
                <div class="text-center mb-4">
                    <span class="oh-brand-mark mb-2" style="width:48px;height:48px;font-size:1.4rem;"><i
                            class="bi bi-house-heart-fill"></i></span>
                    <h3 class="mb-1">Welcome Back</h3>
                    <p class="small text-muted mb-0">Sign in to manage your One Home bookings</p>
                </div>
                <form method="post" action="<?= url('actions/process_login.php') ?>">
                    <?= csrf_field() ?>
                    <label class="form-label">Email</label>
                    <input type="email" name="email" class="form-control mb-3" placeholder="you@example.com" required>
                    <label class="form-label">Password</label>
                    <input type="password" name="password" class="form-control mb-4" placeholder="Enter your password"
                        required>
                    <button class="btn btn-primary w-100 py-2">Login</button>
                </form>
                <p class="mt-4 mb-0 text-center small text-muted">No account yet? <a class="fw-semibold"
                        href="<?= url('register.php') ?>">Register here</a></p>
            </div>
        </div>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
