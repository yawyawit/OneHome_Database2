document.addEventListener('DOMContentLoaded', function () {
    // Register page: show employee fields only when "Employee" is chosen
    var role = document.getElementById('role');
    var emp = document.getElementById('emp-fields');
    if (role && emp) {
        var toggle = function () { emp.style.display = role.value === 'employee' ? 'block' : 'none'; };
        role.addEventListener('change', toggle);
        toggle();
    }

    // Ask "Are you sure?" on forms that have data-confirm
    document.querySelectorAll('form[data-confirm]').forEach(function (f) {
        f.addEventListener('submit', function (e) {
            if (!confirm(f.dataset.confirm)) e.preventDefault();
        });
    });

    // Format card number as 1234 5678 9012 3456
    var card = document.getElementById('card_number');
    if (card) {
        card.addEventListener('input', function () {
            var v = card.value.replace(/\D/g, '').substring(0, 16);
            card.value = v.replace(/(.{4})/g, '$1 ').trim();
        });
    }

    // Soft UI progressive enhancement: password visibility toggles
    document.querySelectorAll('input[type="password"]').forEach(function (input) {
        if (input.closest('.oh-pw-wrap')) return;
        var wrap = document.createElement('div');
        wrap.className = 'oh-pw-wrap';
        if (input.classList.contains('mb-2')) {
            wrap.classList.add('mb-2');
            input.classList.remove('mb-2');
        } else if (input.classList.contains('mb-3')) {
            wrap.classList.add('mb-3');
            input.classList.remove('mb-3');
        } else if (input.classList.contains('mb-4')) {
            wrap.classList.add('mb-4');
            input.classList.remove('mb-4');
        }
        input.parentNode.insertBefore(wrap, input);
        wrap.appendChild(input);

        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'oh-pw-toggle';
        btn.setAttribute('aria-label', 'Show password');
        btn.innerHTML = '<i class="bi bi-eye"></i>';
        btn.addEventListener('click', function () {
            var show = input.type === 'password';
            input.type = show ? 'text' : 'password';
            btn.setAttribute('aria-label', show ? 'Hide password' : 'Show password');
            btn.innerHTML = show ? '<i class="bi bi-eye-slash"></i>' : '<i class="bi bi-eye"></i>';
        });
        wrap.appendChild(btn);
    });

    // Soft UI progressive enhancement: image upload preview
    document.querySelectorAll('input[type="file"][accept*="image"]').forEach(function (fileInput) {
        fileInput.addEventListener('change', function () {
            var existing = fileInput.parentNode.querySelector('.oh-upload-preview');
            if (existing) existing.remove();
            var file = fileInput.files && fileInput.files[0];
            if (!file || !file.type.startsWith('image/')) return;
            var reader = new FileReader();
            reader.onload = function (ev) {
                var box = document.createElement('div');
                box.className = 'oh-upload-preview mb-3';
                var img = document.createElement('img');
                img.src = ev.target.result;
                img.className = 'img-thumbnail';
                img.style.maxHeight = '140px';
                box.appendChild(img);
                fileInput.insertAdjacentElement('afterend', box);
            };
            reader.readAsDataURL(file);
        });
    });
});
