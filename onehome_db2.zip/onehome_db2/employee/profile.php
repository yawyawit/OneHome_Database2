<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'Provider Profile';
$offerings = db_all("SELECT title, offering_status FROM service_offerings WHERE provider_id = ? ORDER BY title", [$provId]);
$avg = db_val("SELECT ROUND(AVG(r.rating), 1) FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id WHERE q.provider_id = ?", [$provId]);
$rc = (int) db_val("SELECT COUNT(*) FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id WHERE q.provider_id = ?", [$provId]);
require INC . '/header.php'; ?>
<h2>Provider Profile</h2>
<div class="card mb-3" style="max-width:680px">
    <div class="card-body">
        <div class="mb-3"><?= avatar($u['full_name'], $u['avatar'], 90) ?></div>
        <p><b>Business Name:</b> <?= e($u['business_name']) ?> <?= badge($u['verification_status']) ?></p>
        <p><b>Contact Person:</b> <?= e($u['full_name']) ?></p>
        <p><b>Email:</b> <?= e($u['email']) ?> &middot; <b>Phone:</b> <?= e($u['phone']) ?></p>
        <p><b>Service Area:</b> <?= e($u['service_area']) ?></p>
        <p><b>Skills:</b> <?= e($u['skills'] ?: 'Not listed') ?></p>
        <p><b>Offerings:</b> <?= e(implode(', ', array_column($offerings, 'title')) ?: 'None yet') ?></p>
        <p><b>Working days:</b> <?= e(str_replace(',', ', ', $u['available_days'])) ?></p>
        <p><b>Rating:</b> <?= rating_text($avg, $rc) ?></p>
        <a class="btn btn-primary" href="<?= url('employee/edit_profile.php') ?>">Edit Profile</a>
        <a class="btn btn-outline-primary" href="<?= url('employee/offerings.php') ?>">Manage Offerings</a>
        <a class="btn btn-outline-primary" href="<?= url('employee/availability.php') ?>">Availability</a>
        <a class="btn btn-outline-secondary" href="<?= url('employee/my_reviews.php') ?>">Reviews</a>
    </div>
</div>
<?php if (empty($u['customer_id'])): ?>
    <div class="card" style="max-width:680px">
        <div class="card-body">
            <h5>Need to Book Home Services as a Customer?</h5>
            <p class="small text-muted">Enable a Customer profile under your same User account (BR-03).</p>
            <form method="post" action="<?= url('actions/process_profile.php') ?>">
                <?= csrf_field() ?>
                <input type="hidden" name="action" value="enable_customer">
                <button class="btn btn-outline-primary">Enable Customer Workspace</button>
            </form>
        </div>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
