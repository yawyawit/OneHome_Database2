<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$all = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $days = array_values(array_intersect($all, $_POST['days'] ?? []));
    db_exec(
        "UPDATE providers SET available_days = ?, is_available = ? WHERE provider_id = ?",
        [implode(',', $days), isset($_POST['is_available']) ? 1 : 0, $provId]
    );
    flash('Availability saved.');
    redirect('employee/availability.php');
}
$mine = explode(',', (string) $u['available_days']);
$title = 'Availability';
require INC . '/header.php'; ?>
<h2>My Availability</h2>
<form method="post" class="card card-body" style="max-width:500px">
    <?= csrf_field() ?>
    <label class="form-label">Days I can work</label>
    <div class="mb-3">
        <?php foreach ($all as $d): ?>
            <div class="form-check form-check-inline">
                <input class="form-check-input" type="checkbox" name="days[]" value="<?= $d ?>" id="d<?= $d ?>" <?= in_array($d, $mine, true) ? 'checked' : '' ?>>
                <label class="form-check-label" for="d<?= $d ?>"><?= $d ?></label>
            </div>
        <?php endforeach; ?>
    </div>
    <div class="form-check form-switch mb-3">
        <input class="form-check-input" type="checkbox" name="is_available" id="ia" <?= $u['is_available'] ? 'checked' : '' ?>>
        <label class="form-check-label" for="ia">I am accepting new service requests (turn off for leave)</label>
    </div>
    <button class="btn btn-primary">Save</button>
</form>
<?php require INC . '/footer.php'; ?>
