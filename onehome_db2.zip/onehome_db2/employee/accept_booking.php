<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
flash('Bookings are created when a customer accepts a submitted quote.', 'info');
redirect('employee/booking_requests.php');
