<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
post_only();

$u = current_user();
$provId = (int) $u['provider_id'];
$bookingId = (int) ($_POST['id'] ?? 0);
$b = get_booking($bookingId);
$a = $_POST['action'] ?? '';

if (!$b || (int) $b['provider_id'] !== $provId) {
    flash('Job not found.', 'danger');
    redirect('employee/my_jobs.php');
}

if ($a === 'start' && can_transition_booking($b['booking_status'], 'in_progress')) {
    db_exec(
        "UPDATE bookings SET booking_status = 'in_progress' WHERE booking_id = ? AND booking_status IN ('confirmed','rescheduled')",
        [$bookingId]
    );
    if (db_affected_rows() === 1) {
        audit_log($u['user_id'], 'booking', $bookingId, 'job_started', 'Transitioned to in_progress');
        notify_user($b['customer_user_id'], 'Work Started on Booking #' . $bookingId, $u['business_name'] . ' started your service.', 'customer/booking_details.php?id=' . $bookingId);
        flash('Job started.');
    } else {
        flash('The job status changed; please refresh.', 'warning');
    }
} elseif ($a === 'complete' && can_transition_booking($b['booking_status'], 'completed')) {
    db_exec(
        "UPDATE bookings SET booking_status = 'completed', completed_at = NOW() WHERE booking_id = ? AND booking_status = 'in_progress'",
        [$bookingId]
    );
    if (db_affected_rows() === 1) {
        audit_log($u['user_id'], 'booking', $bookingId, 'job_completed', 'Transitioned to completed');
        notify_user($b['customer_user_id'], 'Service Completed — Booking #' . $bookingId, $u['business_name'] . ' marked your job completed. You can now settle payment and leave a review.', 'customer/booking_details.php?id=' . $bookingId);
        flash('Job completed! Customer has been notified to settle payment and review.');
    } else {
        flash('The job status changed; please refresh.', 'warning');
    }
} elseif ($a === 'paid' && in_array($b['booking_status'], ['completed', 'settled'], true)) {
    $conn->beginTransaction();
    db_one("SELECT booking_id FROM bookings WHERE booking_id = ? FOR UPDATE", [$bookingId]);
    $fin = booking_financials($bookingId, $b['agreed_price']);
    if ($fin['balance_due'] <= 0 || $fin['method'] !== 'cash') {
        $conn->rollBack();
        flash('No cash balance is due for this booking.', 'warning');
    } else {
        $ref = 'CASH-' . $bookingId . '-' . strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
        $payId = (int) db_exec(
            "INSERT INTO payments (booking_id, amount, currency, payment_type, payment_status, method, gateway_reference, notes)
             VALUES (?, ?, 'PHP', 'capture', 'successful', 'cash', ?, 'Cash collected by provider after service')",
            [$bookingId, $fin['balance_due'], $ref]
        );
        audit_log($u['user_id'], 'payment', $payId, 'cash_captured', 'Booking #' . $bookingId . ' amount=' . $fin['balance_due']);
        notify_user($b['customer_user_id'], 'Cash Payment Recorded (Booking #' . $bookingId . ')', $u['business_name'] . ' confirmed receipt of ' . money($fin['balance_due']) . '.', 'customer/booking_details.php?id=' . $bookingId);
        $conn->commit();
        flash('Cash payment captured!');
    }
} else {
    flash('That action is not allowed in the booking\'s current state.', 'danger');
}

redirect('employee/booking_details.php?id=' . $bookingId);
