<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$title = 'Edit Provider Profile';
require INC . '/header.php'; ?>
<h2>Edit Provider Profile</h2>
<div class="card mb-4">
    <div class="card-header">Business &amp; Work Profile</div>
    <div class="card-body">
        <form method="post" enctype="multipart/form-data" action="<?= url('actions/process_profile.php') ?>">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="employee">
            <div class="mb-3"><?= avatar($u['full_name'], $u['avatar'], 70) ?></div>
            <label class="form-label">Profile picture (jpg/png, max 2MB)</label>
            <input type="file" name="avatar" accept="image/*" class="form-control mb-3">
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label class="form-label">Business / Display Name</label>
                    <input name="business_name" value="<?= e($u['business_name']) ?>" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label class="form-label">Service Area</label>
                    <input name="service_area" value="<?= e($u['service_area']) ?>" class="form-control" required>
                </div>
            </div>
            <label class="form-label">Skills &amp; specializations</label>
            <input name="skills" value="<?= e($u['skills']) ?>" class="form-control mb-3">
            <button class="btn btn-primary">Save Provider Profile</button>
            <a class="btn btn-outline-secondary" href="<?= url('employee/offerings.php') ?>">Manage Offerings</a>
            <a class="btn btn-outline-secondary" href="<?= url('employee/availability.php') ?>">Set Availability</a>
        </form>
    </div>
</div>
<?php account_forms($u); ?>
<?php require INC . '/footer.php'; ?>
