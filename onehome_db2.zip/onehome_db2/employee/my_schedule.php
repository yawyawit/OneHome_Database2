<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'My Schedule';
$rows = list_bookings("q.provider_id = ? AND b.booking_status IN ('confirmed','rescheduled','in_progress')", [$provId], 'b.scheduled_start ASC');
require INC . '/header.php'; ?>
<h2>My Schedule</h2>
<p>Working days: <b><?= e(str_replace(',', ', ', $u['available_days'])) ?></b> &middot; Accepting requests:
    <?= $u['is_available'] ? badge('active') : badge('inactive') ?>
    <a href="<?= url('employee/availability.php') ?>">Manage availability</a>
</p>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No upcoming jobs.</div>
<?php else: ?>
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light">
            <tr><th>Date</th><th>Window</th><th>Service</th><th>Customer</th><th>Location</th><th>Status</th><th></th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $b):
                $isToday = date('Y-m-d', strtotime($b['scheduled_start'])) === date('Y-m-d'); ?>
                <tr class="<?= $isToday ? 'table-warning' : '' ?>">
                    <td><?= fdate($b['scheduled_start']) ?><?= $isToday ? ' <b>(Today)</b>' : '' ?></td>
                    <td><?= ftime($b['scheduled_start']) ?> - <?= ftime($b['scheduled_end']) ?></td>
                    <td><?= e($b['offering_title']) ?></td>
                    <td><?= e($b['cname']) ?></td>
                    <td><?= e($b['address']) ?></td>
                    <td><?= badge($b['booking_status']) ?></td>
                    <td><a class="btn btn-sm btn-outline-primary" href="<?= url('employee/booking_details.php?id=' . (int) $b['booking_id']) ?>">Details</a></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
