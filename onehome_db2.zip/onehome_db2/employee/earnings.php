<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'Earnings & Payouts';
$rows = list_bookings("q.provider_id = ? AND b.booking_status IN ('completed','settled')", [$provId]);

$eligibleTotal = 0.0;
$paidOutTotal = 0.0;
$uncollectedFromCustomer = 0.0;
foreach ($rows as $b) {
    $eligibleTotal += (float) $b['eligible_earnings'];
    $paidOutTotal += (float) $b['payout_paid'];
    $uncollectedFromCustomer += (float) $b['balance_due'];
}
$pendingPayout = max(0.0, round($eligibleTotal - $paidOutTotal, 2));

require INC . '/header.php'; ?>
<h2>Earnings &amp; Payouts</h2>
<div class="row mt-3">
    <?= stat_card('Payouts paid', money($paidOutTotal), 'bi-cash-coin', 'success') ?>
    <?= stat_card('Eligible awaiting payout', money($pendingPayout), 'bi-hourglass-split', 'warning') ?>
    <?= stat_card('Unpaid by customer', money($uncollectedFromCustomer), 'bi-credit-card', 'info') ?>
    <?= stat_card('Completed jobs', count($rows), 'bi-check-circle', 'primary') ?>
</div>
<a href="<?= url('employee/payment_history.php') ?>" class="btn btn-outline-primary mb-3">View Payout Ledger</a>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No completed jobs yet.</div>
<?php else: ?>
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light">
            <tr><th>Booking</th><th>Service</th><th>Customer</th><th>Agreed Price</th><th>Customer Payment</th><th>Eligible Earnings (90%)</th><th>Payout Paid</th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $b): ?>
                <tr>
                    <td><a href="<?= url('employee/booking_details.php?id=' . (int) $b['booking_id']) ?>">#<?= (int) $b['booking_id'] ?></a></td>
                    <td><?= e($b['offering_title']) ?></td>
                    <td><?= e($b['cname']) ?></td>
                    <td><?= money($b['agreed_price']) ?></td>
                    <td><?= badge($b['pstatus']) ?></td>
                    <td class="fw-semibold"><?= money($b['eligible_earnings']) ?></td>
                    <td><?= money($b['payout_paid']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<p class="small text-muted">Eligible earnings are 90% of net captured customer payments (after 10% platform fee). Payouts are initiated and reconciled by administration.</p>
<?php require INC . '/footer.php'; ?>
