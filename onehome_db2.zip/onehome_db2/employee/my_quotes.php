<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
expire_stale_quotes();

$rows = db_all(
    "SELECT q.*, sr.description AS request_desc, sr.request_status, sc.category_name, so.title AS offering_title,
            cu.full_name AS customer_name, b.booking_id
     FROM quotes q
     JOIN service_requests sr ON sr.request_id = q.request_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     JOIN customers c ON c.customer_id = sr.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     LEFT JOIN bookings b ON b.quote_id = q.quote_id
     WHERE q.provider_id = ?
     ORDER BY q.created_at DESC",
    [$provId]
);
$title = 'My Quotes';
require INC . '/header.php'; ?>
<h2>My Submitted Quotes</h2>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">You haven't submitted any quotes yet. <a href="<?= url('employee/booking_requests.php') ?>">Browse open requests</a>.</div>
<?php else: ?>
    <div class="table-responsive">
        <table class="table table-striped bg-white align-middle">
            <thead class="table-light">
                <tr><th>Quote</th><th>Request</th><th>Customer</th><th>Offering</th><th>Proposed Price</th><th>Valid Until</th><th>Status</th><th>Actions</th></tr>
            </thead>
            <tbody>
                <?php foreach ($rows as $q): ?>
                    <tr>
                        <td>#<?= (int) $q['quote_id'] ?></td>
                        <td>
                            <b>#<?= (int) $q['request_id'] ?> <?= e($q['category_name']) ?></b>
                            <div class="small text-muted"><?= e(mb_strimwidth($q['scope'], 0, 60, '...')) ?></div>
                        </td>
                        <td><?= e($q['customer_name']) ?></td>
                        <td><?= e($q['offering_title']) ?></td>
                        <td class="fw-semibold"><?= money($q['proposed_price']) ?></td>
                        <td><?= fdatetime($q['valid_until']) ?></td>
                        <td><?= badge($q['quote_status']) ?></td>
                        <td>
                            <?php if ($q['quote_status'] === 'pending'): ?>
                                <form method="post" action="<?= url('actions/withdraw_quote.php') ?>" class="d-inline" data-confirm="Withdraw this quote?">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="quote_id" value="<?= (int) $q['quote_id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger">Withdraw</button>
                                </form>
                            <?php endif; ?>
                            <?php if (!empty($q['booking_id'])): ?>
                                <a class="btn btn-sm btn-success" href="<?= url('employee/booking_details.php?id=' . (int) $q['booking_id']) ?>">Booking #<?= (int) $q['booking_id'] ?></a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php endif; ?>
<?php require INC . '/footer.php'; ?>
