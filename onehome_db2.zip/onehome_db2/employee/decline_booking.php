<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
flash('To pass on a request, simply do not submit a quote (or withdraw a pending quote).', 'info');
redirect('employee/booking_requests.php');
