<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'Payout History';
$rows = db_all(
    "SELECT po.*, sc.category_name, so.title AS offering_title, cu.full_name AS customer_name
     FROM payouts po
     JOIN bookings b ON b.booking_id = po.booking_id
     JOIN service_requests sr ON sr.request_id = b.request_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_categories sc ON sc.category_id = sr.category_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     JOIN customers c ON c.customer_id = sr.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     WHERE po.provider_id = ?
     ORDER BY po.created_at DESC",
    [$provId]
);
require INC . '/header.php'; ?>
<h2>Payout Ledger</h2>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No payouts recorded yet.</div>
<?php else: ?>
    <table class="table table-striped bg-white align-middle">
        <thead class="table-light">
            <tr><th>Payout</th><th>Booking</th><th>Service</th><th>Customer</th><th>Payout Amount</th><th>Fee</th><th>Status</th><th>Reference</th><th>Paid On</th></tr>
        </thead>
        <tbody>
            <?php foreach ($rows as $po): ?>
                <tr>
                    <td>#<?= (int) $po['payout_id'] ?></td>
                    <td><a href="<?= url('employee/booking_details.php?id=' . (int) $po['booking_id']) ?>">#<?= (int) $po['booking_id'] ?></a></td>
                    <td><?= e($po['offering_title']) ?></td>
                    <td><?= e($po['customer_name']) ?></td>
                    <td class="fw-semibold"><?= money($po['amount']) ?></td>
                    <td><?= money($po['platform_fee']) ?></td>
                    <td><?= badge($po['payout_status']) ?></td>
                    <td><code><?= e($po['gateway_reference'] ?: '-') ?></code></td>
                    <td><?= $po['paid_at'] ? fdate($po['paid_at']) : '-' ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
<?php endif; ?>
<a href="<?= url('employee/earnings.php') ?>">&laquo; Back to earnings</a>
<?php require INC . '/footer.php'; ?>
