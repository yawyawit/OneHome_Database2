<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'My Reviews';
$rows = db_all(
    "SELECT r.*, cu.full_name AS cname, so.title AS offering_title
     FROM reviews r
     JOIN bookings b ON b.booking_id = r.booking_id
     JOIN quotes q ON q.quote_id = b.quote_id
     JOIN service_offerings so ON so.offering_id = q.offering_id
     JOIN customers c ON c.customer_id = r.customer_id
     JOIN users cu ON cu.user_id = c.user_id
     WHERE q.provider_id = ?
     ORDER BY r.created_at DESC",
    [$provId]
);
$avg = db_val(
    "SELECT ROUND(AVG(r.rating), 1) FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id WHERE q.provider_id = ?",
    [$provId]
);
$low = 0;
foreach ($rows as $r) {
    if ($r['rating'] <= 3) {
        $low++;
    }
}
require INC . '/header.php'; ?>
<h2>My Reviews &amp; Ratings</h2>
<div class="row mt-3">
    <?= stat_card('Average rating', $rows ? stars($avg) . ' ' . $avg : 'No ratings yet', 'bi-star', 'warning') ?>
    <?= stat_card('Total reviews', count($rows), 'bi-chat-quote', 'primary') ?>
</div>
<?php if ($low): ?>
    <div class="alert alert-info">Tip: <?= $low ?> review(s) have 3 stars or below. Read the comments to improve future service delivery.</div>
<?php endif; ?>
<?php if (!$rows): ?>
    <div class="alert alert-secondary">No reviews yet.</div>
<?php endif; ?>
<?php foreach ($rows as $r): ?>
    <div class="card mb-2 <?= $r['rating'] <= 3 ? 'border-warning' : '' ?>">
        <div class="card-body">
            <b><?= e($r['cname']) ?></b> &mdash; <?= e($r['offering_title']) ?> <?= stars($r['rating']) ?>
            <div><?= e($r['comment'] ?: '(no comment)') ?></div>
            <small class="text-muted"><?= fdate($r['created_at']) ?></small>
        </div>
    </div>
<?php endforeach; ?>
<?php require INC . '/footer.php'; ?>
