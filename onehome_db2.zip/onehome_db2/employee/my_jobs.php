<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'My Jobs';
$past = ($_GET['tab'] ?? '') === 'past';
$rows = $past
    ? list_bookings("q.provider_id = ? AND b.booking_status IN ('completed','settled','cancelled','refunded','disputed')", [$provId])
    : list_bookings("q.provider_id = ? AND b.booking_status IN ('pending_confirmation','payment_failed','confirmed','rescheduled','in_progress')", [$provId], 'b.scheduled_start ASC');
require INC . '/header.php'; ?>
<h2>My Jobs</h2>
<div class="mb-3">
    <a class="btn btn-sm <?= $past ? 'btn-outline-dark' : 'btn-dark' ?>" href="my_jobs.php">Current Jobs</a>
    <a class="btn btn-sm <?= $past ? 'btn-dark' : 'btn-outline-dark' ?>" href="my_jobs.php?tab=past">Past &amp; Disputed Jobs</a>
</div>
<?php bookings_table($rows, 'employee'); ?>
<?php require INC . '/footer.php'; ?>
