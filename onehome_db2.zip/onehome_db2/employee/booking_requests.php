<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'Open Service Requests';

expire_stale_quotes();

$myOfferings = db_all(
    "SELECT so.*, sc.category_name
     FROM service_offerings so
     JOIN service_categories sc ON sc.category_id = so.category_id
     WHERE so.provider_id = ? AND so.offering_status = 'active' AND sc.category_status = 'active'
     ORDER BY sc.category_name, so.title",
    [$provId]
);

$offeringsByCat = [];
foreach ($myOfferings as $off) {
    $offeringsByCat[(int) $off['category_id']][] = $off;
}

$rows = list_requests(
    "sr.request_status IN ('open','matching')
     AND EXISTS (
         SELECT 1 FROM service_offerings so
         WHERE so.provider_id = ? AND so.category_id = sr.category_id AND so.offering_status = 'active'
     )",
    [$provId],
    'sr.created_at DESC'
);

require INC . '/header.php'; ?>
<div class="d-flex justify-content-between align-items-center mb-3">
    <h2 class="mb-0">Open Service Requests</h2>
    <a class="btn btn-outline-primary btn-sm" href="<?= url('employee/offerings.php') ?>">Manage My Offerings</a>
</div>
<?php if (!$myOfferings): ?>
    <div class="alert alert-warning">You have no active service offerings yet. <a href="<?= url('employee/offerings.php') ?>">Publish an offering</a> to receive matching requests and submit quotes.</div>
<?php elseif (!$rows): ?>
    <div class="alert alert-secondary">No open requests match your active service offerings right now.</div>
<?php endif; ?>

<?php foreach ($rows as $sr):
    $catOfferings = $offeringsByCat[(int) $sr['category_id']] ?? [];
    $existingQuote = db_one(
        "SELECT * FROM quotes WHERE request_id = ? AND provider_id = ? ORDER BY created_at DESC LIMIT 1",
        [(int) $sr['request_id'], $provId]
    );
    $prefStartVal = $sr['preferred_start'] ? date('Y-m-d\TH:i', strtotime($sr['preferred_start'])) : date('Y-m-d\TH:i', strtotime('+1 day 09:00'));
    $prefEndVal = date('Y-m-d\TH:i', strtotime($prefStartVal) + 7200);
    $validDefault = date('Y-m-d\TH:i', strtotime('+3 days 18:00'));
    $defaultPrice = $catOfferings[0]['base_price'] ?? $sr['default_price'];
?>
    <div class="card mb-3 <?= !empty($sr['preferred_offering_id']) && in_array((int) $sr['preferred_offering_id'], array_column($catOfferings, 'offering_id'), true) ? 'border-primary' : '' ?>">
        <div class="card-body">
            <div class="d-flex justify-content-between align-items-start mb-2">
                <div>
                    <h5 class="mb-1"><?= e($sr['category_name']) ?> &mdash; Request #<?= (int) $sr['request_id'] ?> <?= badge($sr['request_status']) ?></h5>
                    <div class="small text-muted">
                        Customer: <b><?= e($sr['customer_name']) ?></b> &middot;
                        Location: <?= e($sr['street_address'] . ', ' . $sr['city'] . ', ' . $sr['province']) ?> &middot;
                        Preferred: <?= $sr['preferred_start'] ? fdatetime($sr['preferred_start']) : 'Flexible' ?>
                    </div>
                </div>
                <?php if ($sr['preferred_offering_id']): ?>
                    <span class="badge bg-primary">Direct Request</span>
                <?php endif; ?>
            </div>
            <p class="mb-2"><?= nl2br(e($sr['description'])) ?></p>
            <?php if (!empty($sr['photo'])): ?>
                <img src="<?= url('uploads/' . $sr['photo']) ?>" class="img-thumbnail mb-3" style="max-width:200px">
            <?php endif; ?>

            <?php if ($existingQuote && $existingQuote['quote_status'] === 'pending'): ?>
                <div class="alert alert-info py-2 mb-0">
                    You already have a <b>Pending</b> quote (#<?= (int) $existingQuote['quote_id'] ?>) for <b><?= money($existingQuote['proposed_price']) ?></b>.
                    <a href="<?= url('employee/my_quotes.php') ?>" class="ms-2">Manage in My Quotes</a>
                </div>
            <?php else: ?>
                <form method="post" action="<?= url('actions/submit_quote.php') ?>" class="border rounded p-3 bg-light">
                    <?= csrf_field() ?>
                    <input type="hidden" name="request_id" value="<?= (int) $sr['request_id'] ?>">
                    <div class="row g-2 mb-2">
                        <div class="col-md-5">
                            <label class="form-label small mb-0">Your Offering</label>
                            <select name="offering_id" class="form-select form-select-sm" required>
                                <?php foreach ($catOfferings as $co): ?>
                                    <option value="<?= (int) $co['offering_id'] ?>" <?= (int) $sr['preferred_offering_id'] === (int) $co['offering_id'] ? 'selected' : '' ?>>
                                        <?= e($co['title']) ?> (<?= ucfirst($co['pricing_type']) ?><?= $co['base_price'] !== null ? ' · ' . money($co['base_price']) : '' ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label class="form-label small mb-0">Proposed Price (₱)</label>
                            <input type="number" step="0.01" min="0" name="proposed_price" value="<?= e($defaultPrice) ?>" class="form-control form-control-sm" required>
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small mb-0">Quote Valid Until</label>
                            <input type="datetime-local" name="valid_until" value="<?= e($validDefault) ?>" class="form-control form-control-sm" required>
                        </div>
                    </div>
                    <div class="row g-2 mb-2">
                        <div class="col-md-4">
                            <label class="form-label small mb-0">Proposed Start</label>
                            <input type="datetime-local" name="proposed_start" value="<?= e($prefStartVal) ?>" class="form-control form-control-sm">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small mb-0">Proposed End</label>
                            <input type="datetime-local" name="proposed_end" value="<?= e($prefEndVal) ?>" class="form-control form-control-sm">
                        </div>
                        <div class="col-md-4">
                            <label class="form-label small mb-0">Work Scope / Terms</label>
                            <input name="scope" class="form-control form-control-sm" placeholder="Materials, duration, inclusions..." required>
                        </div>
                    </div>
                    <button class="btn btn-primary btn-sm">Submit Quote</button>
                </form>
            <?php endif; ?>
        </div>
    </div>
<?php endforeach; ?>
<?php require INC . '/footer.php'; ?>
