<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$title = 'Provider Dashboard';

$newReq = new_requests_count($provId);
$pendingQuotes = (int) db_val("SELECT COUNT(*) FROM quotes WHERE provider_id = ? AND quote_status = 'pending'", [$provId]);
$upcoming = (int) db_val(
    "SELECT COUNT(*) FROM bookings b JOIN quotes q ON q.quote_id = b.quote_id
     WHERE q.provider_id = ? AND b.booking_status IN ('confirmed','rescheduled','in_progress')",
    [$provId]
);
$done = (int) db_val(
    "SELECT COUNT(*) FROM bookings b JOIN quotes q ON q.quote_id = b.quote_id
     WHERE q.provider_id = ? AND b.booking_status IN ('completed','settled')",
    [$provId]
);
$paidOut = (float) db_val("SELECT COALESCE(SUM(amount), 0) FROM payouts WHERE provider_id = ? AND payout_status = 'paid'", [$provId]);
$avg = db_val(
    "SELECT ROUND(AVG(r.rating), 1) FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id WHERE q.provider_id = ?",
    [$provId]
);
$rc = (int) db_val(
    "SELECT COUNT(*) FROM reviews r JOIN bookings b ON b.booking_id = r.booking_id JOIN quotes q ON q.quote_id = b.quote_id WHERE q.provider_id = ?",
    [$provId]
);
$next = list_bookings("q.provider_id = ? AND b.booking_status IN ('confirmed','rescheduled','in_progress')", [$provId], 'b.scheduled_start ASC');
require INC . '/header.php'; ?>
<h2>Hello, <?= e($u['business_name']) ?>!</h2>
<p class="text-muted small">Provider: <?= e($u['full_name']) ?> &middot; Verification: <?= badge($u['verification_status']) ?> &middot; Area: <?= e($u['service_area']) ?></p>

<div class="row mt-3">
    <?= stat_card('Open matching requests', $newReq, 'bi-inbox', 'danger') ?>
    <?= stat_card('Pending quotes', $pendingQuotes, 'bi-chat-square-quote', 'info') ?>
    <?= stat_card('Upcoming jobs', $upcoming, 'bi-calendar-event', 'primary') ?>
    <?= stat_card('Completed jobs', $done, 'bi-check-circle', 'success') ?>
    <?= stat_card('Payouts received', money($paidOut), 'bi-cash-coin', 'success') ?>
    <?= stat_card('Average rating', $rc ? stars($avg) . ' ' . $avg : 'No ratings yet', 'bi-star', 'warning') ?>
</div>

<?php if ($newReq): ?>
    <div class="alert alert-warning">You have <b><?= $newReq ?></b> eligible service request(s) open for quotes.
        <a href="<?= url('employee/booking_requests.php') ?>">Review &amp; Submit Quotes</a>
    </div>
<?php endif; ?>

<h4 class="mt-3">Upcoming Jobs</h4>
<?php bookings_table(array_slice($next, 0, 5), 'employee'); ?>
<?php require INC . '/footer.php'; ?>
