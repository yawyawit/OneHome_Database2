<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = $_POST['action'] ?? '';
    if ($action === 'create') {
        $catId = (int) ($_POST['category_id'] ?? 0);
        $titleTxt = trim($_POST['title'] ?? '');
        $desc = trim($_POST['description'] ?? '');
        $ptype = ($_POST['pricing_type'] ?? '') === 'fixed' ? 'fixed' : 'quotation';
        $basePrice = $_POST['base_price'] ?? '';
        $cat = db_one("SELECT * FROM service_categories WHERE category_id = ? AND category_status = 'active'", [$catId]);
        if (!$cat || $titleTxt === '') {
            flash('Please choose an active category and offering title.', 'danger');
        } elseif ($ptype === 'fixed' && (!is_numeric($basePrice) || (float) $basePrice < 0)) {
            flash('Fixed-price offerings require a valid non-negative base price.', 'danger');
        } elseif ($basePrice !== '' && (!is_numeric($basePrice) || (float) $basePrice < 0)) {
            flash('Base price must be non-negative.', 'danger');
        } else {
            db_exec(
                "INSERT INTO service_offerings (provider_id, category_id, title, description, pricing_type, base_price, offering_status)
                 VALUES (?, ?, ?, ?, ?, ?, 'active')",
                [$provId, $catId, $titleTxt, $desc, $ptype, $basePrice === '' ? null : (float) $basePrice]
            );
            flash('Service offering published.');
        }
    } elseif ($action === 'toggle') {
        $oid = (int) ($_POST['offering_id'] ?? 0);
        $newStatus = ($_POST['status'] ?? '') === 'inactive' ? 'inactive' : 'active';
        db_exec("UPDATE service_offerings SET offering_status = ? WHERE offering_id = ? AND provider_id = ?", [$newStatus, $oid, $provId]);
        flash($newStatus === 'inactive' ? 'Offering deactivated (historical records preserved).' : 'Offering activated.', 'info');
    }
    redirect('employee/offerings.php');
}

$categories = db_all("SELECT * FROM service_categories WHERE category_status = 'active' ORDER BY category_name");
$offerings = db_all(
    "SELECT so.*, sc.category_name
     FROM service_offerings so
     JOIN service_categories sc ON sc.category_id = so.category_id
     WHERE so.provider_id = ?
     ORDER BY so.offering_status ASC, sc.category_name, so.title",
    [$provId]
);
$title = 'My Service Offerings';
require INC . '/header.php'; ?>
<h2>My Service Offerings</h2>
<p class="text-muted">Publish specific services under active categories. Deactivating an offering stops new quotes/requests without erasing historical bookings.</p>

<div class="row">
    <div class="col-lg-7 mb-4">
        <?php if (!$offerings): ?>
            <div class="alert alert-secondary">No service offerings published yet.</div>
        <?php else: ?>
            <?php foreach ($offerings as $o): ?>
                <div class="card mb-2">
                    <div class="card-body d-flex justify-content-between align-items-start gap-2">
                        <div>
                            <h5 class="mb-1"><?= e($o['title']) ?> <?= badge($o['offering_status']) ?> <?= badge($o['pricing_type']) ?></h5>
                            <div class="small text-muted">Category: <?= e($o['category_name']) ?> &middot; Base price: <?= $o['base_price'] !== null ? money($o['base_price']) : 'Quoted' ?></div>
                            <div class="small mt-1"><?= e($o['description']) ?></div>
                        </div>
                        <form method="post">
                            <?= csrf_field() ?>
                            <input type="hidden" name="action" value="toggle">
                            <input type="hidden" name="offering_id" value="<?= (int) $o['offering_id'] ?>">
                            <input type="hidden" name="status" value="<?= $o['offering_status'] === 'active' ? 'inactive' : 'active' ?>">
                            <button class="btn btn-sm <?= $o['offering_status'] === 'active' ? 'btn-outline-danger' : 'btn-outline-success' ?>">
                                <?= $o['offering_status'] === 'active' ? 'Deactivate' : 'Activate' ?>
                            </button>
                        </form>
                    </div>
                </div>
            <?php endforeach; ?>
        <?php endif; ?>
    </div>
    <div class="col-lg-5">
        <form method="post" class="card card-body">
            <?= csrf_field() ?>
            <input type="hidden" name="action" value="create">
            <h5 class="mb-3">Publish New Offering</h5>
            <label class="form-label">Category</label>
            <select name="category_id" class="form-select mb-2" required>
                <?php foreach ($categories as $c): ?>
                    <option value="<?= (int) $c['category_id'] ?>"><?= e($c['category_name']) ?></option>
                <?php endforeach; ?>
            </select>
            <label class="form-label">Offering Title</label>
            <input name="title" class="form-control mb-2" placeholder="e.g. Pipe Leak Repair" required>
            <label class="form-label">Pricing Type</label>
            <select name="pricing_type" class="form-select mb-2">
                <option value="quotation">Quotation-based</option>
                <option value="fixed">Fixed Price</option>
            </select>
            <label class="form-label">Base Price (₱)</label>
            <input type="number" step="0.01" min="0" name="base_price" class="form-control mb-2" placeholder="Required for fixed price">
            <label class="form-label">Description</label>
            <textarea name="description" rows="3" class="form-control mb-3"></textarea>
            <button class="btn btn-primary">Publish Offering</button>
        </form>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
