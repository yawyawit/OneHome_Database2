<?php require_once __DIR__ . '/../includes/auth.php';
require_role('employee');
$u = current_user();
$provId = (int) $u['provider_id'];
$b = get_booking((int) ($_GET['id'] ?? 0));
if (!$b || (int) $b['provider_id'] !== $provId) {
    flash('Booking not found.', 'danger');
    redirect('employee/my_jobs.php');
}
$fin = booking_financials($b['booking_id'], $b['agreed_price']);
$payouts = db_all("SELECT * FROM payouts WHERE booking_id = ? ORDER BY created_at DESC", [$b['booking_id']]);
$title = 'Job #' . $b['booking_id'];
require INC . '/header.php'; ?>
<h2>Job #<?= (int) $b['booking_id'] ?></h2>
<?php booking_info($b); ?>
<div class="mb-4">
    <?= job_buttons($b) ?>
    <a class="btn btn-secondary" href="<?= url('employee/my_jobs.php') ?>">Back to My Jobs</a>
</div>

<div class="row">
    <?php if (can_transition_booking($b['booking_status'], 'rescheduled')): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">Reschedule Appointment</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/reschedule_booking.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                        <div class="mb-2">
                            <label class="form-label small">New Start</label>
                            <input type="datetime-local" name="scheduled_start" value="<?= date('Y-m-d\TH:i', strtotime($b['scheduled_start'])) ?>" class="form-control" required>
                        </div>
                        <div class="mb-3">
                            <label class="form-label small">New End</label>
                            <input type="datetime-local" name="scheduled_end" value="<?= date('Y-m-d\TH:i', strtotime($b['scheduled_end'])) ?>" class="form-control" required>
                        </div>
                        <button class="btn btn-outline-primary btn-sm">Update Schedule</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>

    <?php if (in_array($b['booking_status'], ['confirmed', 'rescheduled', 'in_progress', 'completed', 'disputed'], true)): ?>
        <div class="col-md-6 mb-4">
            <div class="card h-100">
                <div class="card-header">Report Issue / Open Dispute</div>
                <div class="card-body">
                    <form method="post" action="<?= url('actions/open_dispute.php') ?>">
                        <?= csrf_field() ?>
                        <input type="hidden" name="booking_id" value="<?= (int) $b['booking_id'] ?>">
                        <textarea name="reason" rows="3" class="form-control mb-2" placeholder="Describe the issue..." required></textarea>
                        <button class="btn btn-outline-danger btn-sm">Open Dispute</button>
                    </form>
                </div>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="card mb-3">
    <div class="card-header">Payout Summary (<?= (100 - (int) (PLATFORM_FEE_RATE * 100)) ?>% Provider Share)</div>
    <div class="card-body">
        <p class="mb-1"><b>Eligible Provider Earnings:</b> <?= money($fin['eligible_earnings']) ?> &middot; <b>Paid Out:</b> <?= money($fin['payout_paid']) ?> &middot; <b>Remaining Eligible:</b> <?= money($fin['remaining_payout']) ?></p>
        <?php if ($payouts): ?>
            <table class="table table-sm table-bordered mt-2 mb-0">
                <thead class="table-light"><tr><th>Payout #</th><th>Amount</th><th>Platform Fee</th><th>Status</th><th>Reference</th><th>Date</th></tr></thead>
                <tbody>
                    <?php foreach ($payouts as $po): ?>
                        <tr>
                            <td>#<?= (int) $po['payout_id'] ?></td>
                            <td><?= money($po['amount']) ?></td>
                            <td><?= money($po['platform_fee']) ?></td>
                            <td><?= badge($po['payout_status']) ?></td>
                            <td><code><?= e($po['gateway_reference'] ?: '-') ?></code></td>
                            <td><?= fdatetime($po['created_at']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
