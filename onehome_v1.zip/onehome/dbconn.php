<?php
date_default_timezone_set('Asia/Manila');
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
try {
    $conn = new mysqli('localhost', 'root', '', 'onehome_db');
    $conn->set_charset('utf8mb4');
    $conn->query("SET time_zone = '+08:00'");
} catch (mysqli_sql_exception $e) {
    http_response_code(500);
    die('Database connection failed. Start MySQL in XAMPP and import onehome.sql in phpMyAdmin.');
}
