<?php
require_once __DIR__ . '/includes/functions.php';
if (!empty($_SESSION['USER_ROLE'])) redirect(home_for_role($_SESSION['USER_ROLE']));
$error='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $first=trim($_POST['first_name']??''); $last=trim($_POST['last_name']??''); $email=strtolower(trim($_POST['email']??'')); $contact=trim($_POST['contact']??''); $password=$_POST['password']??''; $confirm=$_POST['confirm_password']??''; $role=$_POST['user_role']??'customer';
    $business=trim($_POST['business_name']??''); $city=trim($_POST['service_area_city']??'');
    $street=trim($_POST['street_address']??''); $homeCity=trim($_POST['city']??''); $province=trim($_POST['province']??''); $postal=trim($_POST['postal_code']??'');
    if ($first==='' || $last==='' || !filter_var($email,FILTER_VALIDATE_EMAIL) || $contact==='' || !in_array($role,['customer','provider'],true)) $error='Please complete all required account fields correctly.';
    elseif (strlen($password)<8) $error='Password must contain at least 8 characters.';
    elseif ($password!==$confirm) $error='Passwords do not match.';
    elseif ($role==='provider' && ($business==='' || $city==='')) $error='Provider accounts need a business name and service-area city.';
    elseif ($role==='customer' && ($street==='' || $homeCity==='' || $province==='')) $error='Customers need to add a home address.';
    else {
        try {
            $conn->begin_transaction();
            $hash=password_hash($password,PASSWORD_DEFAULT);
            $stmt=$conn->prepare('INSERT INTO users (first_name,last_name,email,contact,password,user_role) VALUES (?,?,?,?,?,?)');
            $stmt->bind_param('ssssss',$first,$last,$email,$contact,$hash,$role); $stmt->execute(); $userId=(int)$stmt->insert_id; $stmt->close();
            if ($role==='customer') {
                $stmt=$conn->prepare('INSERT INTO customers (user_id) VALUES (?)'); $stmt->bind_param('i',$userId); $stmt->execute(); $customerId=(int)$stmt->insert_id; $stmt->close();
                $label='Home'; $default=1;
                $stmt=$conn->prepare('INSERT INTO address (customer_id,address_label,street_address,city,province,postal_code,is_default) VALUES (?,?,?,?,?,?,?)');
                $stmt->bind_param('isssssi',$customerId,$label,$street,$homeCity,$province,$postal,$default); $stmt->execute(); $stmt->close();
            } else {
                $bio='';
                $stmt=$conn->prepare("INSERT INTO providers (user_id,business_name,business_description,service_area_city,provider_status,verification_status) VALUES (?,?,?,?,'active','pending')");
                $stmt->bind_param('isss',$userId,$business,$bio,$city); $stmt->execute(); $stmt->close();
            }
            $conn->commit();
            if ($role==='provider') set_flash('success','Provider account created. An administrator must verify your account before you can send quotes.');
            else set_flash('success','Your account is ready. Log in to request a service.');
            redirect('/onehome/login.php');
        } catch (mysqli_sql_exception $e) {
            $conn->rollback();
            $error = $e->getCode()===1062 ? 'An account with this email already exists.' : 'Unable to create the account. Please check your details and try again.';
        }
    }
}
$pageTitle='Create account'; include __DIR__ . '/includes/header.php';
?>
<div class="auth-layout"><div class="auth-intro"><p class="eyebrow">JOIN ONEHOME</p><h1>Let’s take care of what your home needs.</h1><p>Create a customer account to request help, or join as a service provider to offer your skills and respond to matching requests.</p><div class="hero-note"><strong>Customer:</strong> create requests, compare quotes, book a provider, and leave a review.<br><br><strong>Provider:</strong> set up your service offers and submit quotes after verification.</div></div><section class="auth-card"><h2>Create account</h2><p>Start with your contact details.</p><?php if($error): ?><div class="alert alert-error"><?php echo h($error); ?></div><?php endif; ?><form method="post" id="registerForm"><input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>"><div class="form-grid"><div class="field"><label>First name</label><input name="first_name" required value="<?php echo h($_POST['first_name']??''); ?>"></div><div class="field"><label>Last name</label><input name="last_name" required value="<?php echo h($_POST['last_name']??''); ?>"></div><div class="field full"><label>Email address</label><input type="email" name="email" required value="<?php echo h($_POST['email']??''); ?>"></div><div class="field full"><label>Contact number</label><input name="contact" required value="<?php echo h($_POST['contact']??''); ?>"></div><div class="field full"><label>Account type</label><select name="user_role" id="roleSelect"><option value="customer" <?php echo ($_POST['user_role']??'customer')==='customer'?'selected':''; ?>>Customer</option><option value="provider" <?php echo ($_POST['user_role']??'')==='provider'?'selected':''; ?>>Service provider</option></select></div><div class="field provider-field full"><label>Business / provider name</label><input name="business_name" value="<?php echo h($_POST['business_name']??''); ?>"></div><div class="field provider-field full"><label>Service-area city</label><input name="service_area_city" placeholder="e.g. Baguio City" value="<?php echo h($_POST['service_area_city']??''); ?>"></div><div class="field customer-field full"><label>Street address</label><input name="street_address" value="<?php echo h($_POST['street_address']??''); ?>"></div><div class="field customer-field"><label>City</label><input name="city" value="<?php echo h($_POST['city']??''); ?>"></div><div class="field customer-field"><label>Province</label><input name="province" value="<?php echo h($_POST['province']??''); ?>"></div><div class="field customer-field full"><label>Postal code (optional)</label><input name="postal_code" value="<?php echo h($_POST['postal_code']??''); ?>"></div><div class="field"><label>Password (8+ characters)</label><input type="password" name="password" minlength="8" required></div><div class="field"><label>Confirm password</label><input type="password" name="confirm_password" minlength="8" required></div></div><button class="btn btn-primary" type="submit">Create account</button></form><div class="auth-foot">Already registered? <a href="/onehome/login.php">Log in</a></div></section></div>
<script>
const roleSelect=document.getElementById('roleSelect');
function toggleRoleFields(){const provider=roleSelect.value==='provider';document.querySelectorAll('.provider-field').forEach(el=>{el.style.display=provider?'flex':'none';el.querySelectorAll('input').forEach(i=>i.required=provider)});document.querySelectorAll('.customer-field').forEach(el=>{el.style.display=provider?'none':'flex';el.querySelectorAll('input').forEach(i=>i.required=!provider&&i.name!=='postal_code')})}roleSelect.addEventListener('change',toggleRoleFields);toggleRoleFields();
</script>
<?php include __DIR__ . '/includes/footer.php'; ?>
