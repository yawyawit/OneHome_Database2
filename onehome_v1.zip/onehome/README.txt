ONEHOME — HOME SERVICE MARKETPLACE
==================================

ABOUT
OneHome follows the supplied “OneHome System Anatomical Outline” and its marketplace model. Customers request a service; matching providers respond with quotes; the customer accepts one quote to create a booking; the provider performs the job; completion is confirmed; and payment/payout records are handled separately.

CORE TRANSACTION
Request -> Match -> Quote -> Agreement / Booking -> Service -> Completion -> Payment / Payout

REQUIREMENTS
- XAMPP with Apache, MySQL/MariaDB and PHP 8.1 or newer
- phpMyAdmin
- MySQLi extension enabled

INSTALLATION
1. Extract the project folder so it is: C:\xampp\htdocs\onehome\
2. Start Apache and MySQL in XAMPP.
3. Open http://localhost/phpmyadmin/.
4. Import onehome.sql. It creates the onehome_db database and sample records.
5. Open http://localhost/onehome/.

IMPORTANT DATABASE NOTE
Importing onehome.sql drops and recreates OneHome's tables and sample records. Back up existing data before importing. The connection settings are in dbconn.php (default XAMPP user root with an empty password).

DEMO ACCOUNTS
Administrator: admin@onehome.local / admin123
Customer:      customer@onehome.local / demo123
Provider 1:    cleaning@onehome.local / provider123
Provider 2:    repairs@onehome.local / provider123

ROLES AND MAIN FEATURES
Customer
- Register and manage account/profile and saved addresses.
- Browse active services from verified providers.
- Create a service request with location, work description and preferred start time.
- Review provider quotes, compare scope/price/schedule, and accept one.
- View bookings, request rescheduling, cancel eligible bookings, confirm service completion, record demo payment, leave a review or report an issue.
- Receive in-app notifications.

Provider
- Register (new provider accounts start pending verification) and manage business profile/service-area city.
- Maintain service offerings, categories, descriptions and base prices.
- See open requests matching an active offering and the service-area city.
- Submit or update a quote with the work scope, total price, proposed schedule, and expiry.
- Track accepted quotes/bookings, request a reschedule, mark work In Progress and report service completion.
- View payout records.

Administrator
- Review/verify or reject provider accounts; activate/deactivate providers and users.
- Add, edit and deactivate service categories.
- Monitor requests and bookings; cancel open requests or confirmed bookings when appropriate.
- Reconcile pending payment records, review refunds and disputes, create provider payout records and update payout status.
- Moderate reviews without deleting their history.

DATABASE TABLES
users             Accounts, role and authentication
customers         Customer identity extension
providers         Provider profile, verification and service-area city
admins            Administrator identity extension
address           Saved customer addresses
service_category  Service catalog categories
service_offering  Provider's service offerings and pricing guide
service_request   Customer demand: scope, location and preferred time
quote             Provider quote, scope, price, schedule and expiry
booking           Accepted agreement and service lifecycle
booking_change    Reschedule proposals and accepted/declined history
payment           Separate customer payment records
refund            Refund operations and their review/status history
payout            Provider compensation ledger
review            Customer ratings/comments tied to completed bookings
dispute           Issue report and documented resolution
notification      In-app activity messages

KEY DATA RULES
- Only active and verified providers with active offers are included in matching.
- Matching currently compares the provider service-area city with the request address city, as a simple prototype location rule.
- A request can have at most one booking and a quote can only be booked once.
- The accepted quote stores the agreed amount and appointment in the booking record; later changes to service offers do not rewrite old bookings.
- Provider overlap checks prevent accepting quotes that conflict with active bookings, and rescheduling checks for overlapping bookings.
- Booking status and payment status are independent.
- A provider reports service completion; the customer confirms it. An admin can resolve disputed bookings with a recorded outcome.
- Refunds are recorded separately from original payments. Payouts are separate and are only eligible after booking completion and recorded payment, with no unresolved dispute/refund review.

PROTOTYPE LIMITATIONS
- GCash is a simulation only; no real money is transferred.
- Payout and refund status updates are ledger records; no banking or payment gateway is connected.
- Notifications are in-app only; no external email/SMS provider is configured.
- Provider matching uses city and category. GPS, postal coverage polygons, travel time, and provider calendars are not implemented.
- A single quote per provider/request is supported, and a request creates at most one booking.
- No provider payout commission or platform fee is calculated. The payout amount defaults to the agreed booking price.
- Set up the project in a local development environment; it has not been hardened or deployed as a production marketplace.
