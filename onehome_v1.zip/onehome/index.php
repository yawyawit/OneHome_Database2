<?php
require_once __DIR__ . '/includes/functions.php';
if (!empty($_SESSION['USER_ROLE'])) redirect(home_for_role($_SESSION['USER_ROLE']));
$pageTitle = 'Home services, matched to you';
$activeNav = 'home';
$categories = $conn->query("SELECT category_name, description FROM service_category WHERE category_status='active' ORDER BY category_name LIMIT 8")->fetch_all(MYSQLI_ASSOC);
include __DIR__ . '/includes/header.php';
?>
<section class="hero">
  <div><p class="eyebrow">LOCAL HELP. TRUSTED PROVIDERS.</p><h1>Home care made simpler, from <span>request to done.</span></h1><p class="hero-copy">Tell OneHome what needs fixing or caring for. Compare provider quotes, choose a schedule and price, then follow your booking through completion.</p><div class="hero-actions"><a class="btn btn-primary" href="/onehome/register.php">Create an account →</a><a class="btn btn-light" href="/onehome/login.php">Log in</a></div><div class="hero-note"><strong>How it works:</strong> Request a service · Get matched with providers · Agree on the quote · Track the job · Settle payment.</div></div>
  <div class="hero-art"><div class="float-chip one">✓ Verified providers</div><div class="art-house"><div class="house-icon">⌂</div><strong>Your home, in good hands.</strong><p>One place for household services.</p></div><div class="float-chip two">↗ Quotes you can compare</div></div>
</section>
<section class="section"><div class="section-heading"><div><p class="eyebrow">SERVICE CATEGORIES</p><h2>What can we help with?</h2><p>Start a request and providers in your area can respond.</p></div><a href="/onehome/register.php" class="btn btn-secondary">Request a service</a></div><div class="category-grid">
<?php $symbols=['House Cleaning'=>'✦','Plumbing'=>'⌁','Electrical Repair'=>'ϟ','Laundry'=>'◌','Appliance Repair'=>'⌘','Gardening'=>'❋','Painting'=>'▧','Carpentry'=>'⌂']; foreach($categories as $cat): ?><article class="category-card"><div class="category-symbol"><?php echo h($symbols[$cat['category_name']] ?? '✧'); ?></div><h3><?php echo h($cat['category_name']); ?></h3><p><?php echo h($cat['description']); ?></p></article><?php endforeach; ?>
</div></section>
<section class="section"><div class="section-heading"><div><p class="eyebrow">BUILT AROUND THE TRANSACTION</p><h2>From your request to completion</h2></div></div><div class="card-grid"><article class="category-card"><div class="category-symbol">01</div><h3>Request</h3><p>Describe the job, choose your address, and set a preferred time.</p></article><article class="category-card"><div class="category-symbol">02</div><h3>Match & compare</h3><p>Providers with matching services and coverage can send quotes.</p></article><article class="category-card"><div class="category-symbol">03</div><h3>Agree & book</h3><p>Review the scope, price, and appointment before accepting a quote.</p></article><article class="category-card"><div class="category-symbol">04</div><h3>Complete & settle</h3><p>Track progress, confirm completion, and record payment separately.</p></article></div></section>
<?php include __DIR__ . '/includes/footer.php'; ?>
