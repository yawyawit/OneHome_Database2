-- OneHome marketplace database
-- Import into phpMyAdmin. WARNING: this script recreates these tables and demo data.
CREATE DATABASE IF NOT EXISTS onehome_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE onehome_db;
SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS notification;
DROP TABLE IF EXISTS refund;
DROP TABLE IF EXISTS dispute;
DROP TABLE IF EXISTS review;
DROP TABLE IF EXISTS payout;
DROP TABLE IF EXISTS payment;
DROP TABLE IF EXISTS booking_change;
DROP TABLE IF EXISTS booking;
DROP TABLE IF EXISTS quote;
DROP TABLE IF EXISTS service_request;
DROP TABLE IF EXISTS service_offering;
DROP TABLE IF EXISTS service_category;
DROP TABLE IF EXISTS address;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS providers;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

CREATE TABLE users (
  user_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(60) NOT NULL,
  last_name VARCHAR(60) NOT NULL,
  email VARCHAR(150) NOT NULL,
  contact VARCHAR(25) NOT NULL,
  password VARCHAR(255) NOT NULL,
  account_status ENUM('active','suspended') NOT NULL DEFAULT 'active',
  user_role ENUM('customer','provider','admin') NOT NULL DEFAULT 'customer',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (user_id),
  UNIQUE KEY uq_users_email (email),
  KEY idx_users_role_status (user_role, account_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE customers (
  customer_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (customer_id),
  UNIQUE KEY uq_customer_user (user_id),
  CONSTRAINT fk_customer_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE admins (
  admin_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  admin_level VARCHAR(20) NOT NULL DEFAULT 'operations',
  PRIMARY KEY (admin_id),
  UNIQUE KEY uq_admin_user (user_id),
  CONSTRAINT fk_admin_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE providers (
  provider_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  business_name VARCHAR(100) NOT NULL,
  business_description VARCHAR(500) NOT NULL DEFAULT '',
  service_area_city VARCHAR(80) NOT NULL,
  provider_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  verification_status ENUM('pending','verified','rejected') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (provider_id),
  UNIQUE KEY uq_provider_user (user_id),
  KEY idx_provider_status (provider_status, verification_status, service_area_city),
  CONSTRAINT fk_provider_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE address (
  address_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  address_label VARCHAR(35) NOT NULL DEFAULT 'Home',
  street_address VARCHAR(150) NOT NULL,
  city VARCHAR(80) NOT NULL,
  province VARCHAR(80) NOT NULL,
  postal_code VARCHAR(12) DEFAULT NULL,
  is_default TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (address_id),
  KEY idx_address_customer (customer_id),
  KEY idx_address_city (city),
  CONSTRAINT fk_address_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE service_category (
  category_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  category_name VARCHAR(80) NOT NULL,
  description VARCHAR(255) NOT NULL DEFAULT '',
  category_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (category_id),
  UNIQUE KEY uq_category_name (category_name),
  KEY idx_category_status (category_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE service_offering (
  offering_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  provider_id INT UNSIGNED NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  title VARCHAR(100) NOT NULL,
  description VARCHAR(500) NOT NULL,
  pricing_type ENUM('fixed','quote') NOT NULL DEFAULT 'quote',
  base_price DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  offering_status ENUM('active','inactive') NOT NULL DEFAULT 'active',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (offering_id),
  KEY idx_offering_provider_status (provider_id, offering_status),
  KEY idx_offering_category_status (category_id, offering_status),
  CONSTRAINT fk_offering_provider FOREIGN KEY (provider_id) REFERENCES providers(provider_id) ON DELETE CASCADE,
  CONSTRAINT fk_offering_category FOREIGN KEY (category_id) REFERENCES service_category(category_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE service_request (
  request_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  customer_id INT UNSIGNED NOT NULL,
  category_id INT UNSIGNED NOT NULL,
  category_name_snapshot VARCHAR(80) NOT NULL,
  address_id INT UNSIGNED NOT NULL,
  service_address_snapshot VARCHAR(400) NOT NULL,
  service_city_snapshot VARCHAR(80) NOT NULL,
  service_province_snapshot VARCHAR(80) NOT NULL,
  description TEXT NOT NULL,
  preferred_start DATETIME NOT NULL,
  request_status ENUM('requested','matching','awaiting_quotes','booked','completed','cancelled','disputed') NOT NULL DEFAULT 'requested',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (request_id),
  KEY idx_request_customer (customer_id, created_at),
  KEY idx_request_category_status (category_id, request_status),
  KEY idx_request_address (address_id),
  KEY idx_request_start (preferred_start),
  CONSTRAINT fk_request_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT,
  CONSTRAINT fk_request_category FOREIGN KEY (category_id) REFERENCES service_category(category_id) ON DELETE RESTRICT,
  CONSTRAINT fk_request_address FOREIGN KEY (address_id) REFERENCES address(address_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE quote (
  quote_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id INT UNSIGNED NOT NULL,
  provider_id INT UNSIGNED NOT NULL,
  offering_id INT UNSIGNED NOT NULL,
  offering_title_snapshot VARCHAR(100) NOT NULL,
  provider_name_snapshot VARCHAR(100) NOT NULL,
  proposed_price DECIMAL(10,2) NOT NULL,
  scope VARCHAR(700) NOT NULL,
  proposed_start DATETIME NOT NULL,
  proposed_end DATETIME NOT NULL,
  valid_until DATETIME NOT NULL,
  quote_status ENUM('submitted','accepted','declined','withdrawn','expired') NOT NULL DEFAULT 'submitted',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (quote_id),
  UNIQUE KEY uq_quote_once_per_provider (request_id, provider_id),
  KEY idx_quote_provider_status (provider_id, quote_status),
  KEY idx_quote_request_status (request_id, quote_status),
  CONSTRAINT fk_quote_request FOREIGN KEY (request_id) REFERENCES service_request(request_id) ON DELETE CASCADE,
  CONSTRAINT fk_quote_provider FOREIGN KEY (provider_id) REFERENCES providers(provider_id) ON DELETE RESTRICT,
  CONSTRAINT fk_quote_offering FOREIGN KEY (offering_id) REFERENCES service_offering(offering_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE booking (
  booking_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  request_id INT UNSIGNED NOT NULL,
  quote_id INT UNSIGNED NOT NULL,
  service_name_snapshot VARCHAR(100) NOT NULL,
  service_category_snapshot VARCHAR(80) NOT NULL,
  provider_name_snapshot VARCHAR(100) NOT NULL,
  service_address_snapshot VARCHAR(400) NOT NULL,
  service_city_snapshot VARCHAR(80) NOT NULL,
  service_province_snapshot VARCHAR(80) NOT NULL,
  agreed_scope TEXT NOT NULL,
  agreed_price DECIMAL(10,2) NOT NULL,
  scheduled_start DATETIME NOT NULL,
  scheduled_end DATETIME NOT NULL,
  booking_status ENUM('confirmed','in_progress','service_completed','completed','cancelled','disputed') NOT NULL DEFAULT 'confirmed',
  completed_at DATETIME DEFAULT NULL,
  customer_confirmed_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (booking_id),
  UNIQUE KEY uq_booking_request (request_id),
  UNIQUE KEY uq_booking_quote (quote_id),
  KEY idx_booking_schedule (scheduled_start, scheduled_end),
  KEY idx_booking_status (booking_status),
  CONSTRAINT fk_booking_request FOREIGN KEY (request_id) REFERENCES service_request(request_id) ON DELETE RESTRICT,
  CONSTRAINT fk_booking_quote FOREIGN KEY (quote_id) REFERENCES quote(quote_id) ON DELETE RESTRICT,
  CONSTRAINT chk_booking_time CHECK (scheduled_end > scheduled_start),
  CONSTRAINT chk_booking_price CHECK (agreed_price >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE booking_change (
  change_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id INT UNSIGNED NOT NULL,
  requested_by_user_id INT UNSIGNED NOT NULL,
  proposed_start DATETIME NOT NULL,
  proposed_end DATETIME NOT NULL,
  request_message VARCHAR(300) NOT NULL DEFAULT '',
  change_status ENUM('pending','accepted','declined','cancelled') NOT NULL DEFAULT 'pending',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME DEFAULT NULL,
  PRIMARY KEY (change_id),
  KEY idx_booking_change_booking_status (booking_id, change_status),
  KEY idx_booking_change_user (requested_by_user_id),
  CONSTRAINT fk_booking_change_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE RESTRICT,
  CONSTRAINT fk_booking_change_user FOREIGN KEY (requested_by_user_id) REFERENCES users(user_id) ON DELETE RESTRICT,
  CONSTRAINT chk_booking_change_time CHECK (proposed_end > proposed_start)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payment (
  payment_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id INT UNSIGNED NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payment_type ENUM('cash_after_service','gcash_demo') NOT NULL DEFAULT 'cash_after_service',
  payment_status ENUM('pending','paid','failed','refund_pending','refunded') NOT NULL DEFAULT 'pending',
  gateway_reference VARCHAR(100) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (payment_id),
  KEY idx_payment_booking (booking_id, payment_id),
  KEY idx_payment_status (payment_status),
  CONSTRAINT fk_payment_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE RESTRICT,
  CONSTRAINT chk_payment_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE refund (
  refund_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  payment_id INT UNSIGNED NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  reason VARCHAR(700) NOT NULL,
  refund_status ENUM('pending_review','approved','refunded','rejected') NOT NULL DEFAULT 'pending_review',
  gateway_reference VARCHAR(100) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME DEFAULT NULL,
  PRIMARY KEY (refund_id),
  KEY idx_refund_payment (payment_id),
  KEY idx_refund_status (refund_status, created_at),
  CONSTRAINT fk_refund_payment FOREIGN KEY (payment_id) REFERENCES payment(payment_id) ON DELETE RESTRICT,
  CONSTRAINT chk_refund_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE payout (
  payout_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id INT UNSIGNED NOT NULL,
  provider_id INT UNSIGNED NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  payout_status ENUM('pending','processing','paid','failed') NOT NULL DEFAULT 'pending',
  gateway_reference VARCHAR(100) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (payout_id),
  UNIQUE KEY uq_payout_booking (booking_id),
  KEY idx_payout_provider (provider_id, payout_status),
  CONSTRAINT fk_payout_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE RESTRICT,
  CONSTRAINT fk_payout_provider FOREIGN KEY (provider_id) REFERENCES providers(provider_id) ON DELETE RESTRICT,
  CONSTRAINT chk_payout_amount CHECK (amount >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE review (
  review_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id INT UNSIGNED NOT NULL,
  customer_id INT UNSIGNED NOT NULL,
  rating TINYINT UNSIGNED NOT NULL,
  comment VARCHAR(700) NOT NULL DEFAULT '',
  review_status ENUM('visible','hidden') NOT NULL DEFAULT 'visible',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (review_id),
  UNIQUE KEY uq_review_booking (booking_id),
  KEY idx_review_customer (customer_id),
  CONSTRAINT fk_review_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE RESTRICT,
  CONSTRAINT fk_review_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE RESTRICT,
  CONSTRAINT chk_review_rating CHECK (rating BETWEEN 1 AND 5)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE dispute (
  dispute_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  booking_id INT UNSIGNED NOT NULL,
  user_id INT UNSIGNED NOT NULL,
  reason VARCHAR(700) NOT NULL,
  dispute_status ENUM('open','under_review','resolved','dismissed') NOT NULL DEFAULT 'open',
  booking_status_before_dispute VARCHAR(35) NOT NULL,
  resolution VARCHAR(700) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  resolved_at DATETIME DEFAULT NULL,
  PRIMARY KEY (dispute_id),
  KEY idx_dispute_booking (booking_id),
  KEY idx_dispute_status (dispute_status, created_at),
  CONSTRAINT fk_dispute_booking FOREIGN KEY (booking_id) REFERENCES booking(booking_id) ON DELETE RESTRICT,
  CONSTRAINT fk_dispute_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE notification (
  notification_id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id INT UNSIGNED NOT NULL,
  title VARCHAR(120) NOT NULL,
  message VARCHAR(500) NOT NULL,
  is_read TINYINT(1) NOT NULL DEFAULT 0,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (notification_id),
  KEY idx_notification_user_read (user_id, is_read, created_at),
  CONSTRAINT fk_notification_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Demo login passwords: admin123, demo123, provider123 (all stored as password hashes)
INSERT INTO users (user_id, first_name, last_name, email, contact, password, user_role) VALUES
(1, 'OneHome', 'Administrator', 'admin@onehome.local', '09170000001', '$2y$12$mbEk7tqoTKJONH1ZzN9aMeWFSqt14bsUZ8uvcOlTH92pXJbb0N/my', 'admin'),
(2, 'Demo', 'Customer', 'customer@onehome.local', '09170000002', '$2y$12$hAEtYQDgWoV2pOONFrfml.qKc1cQ.2D2yR8trzbhQD0hPeOdpfppa', 'customer'),
(3, 'Maria', 'Santos', 'cleaning@onehome.local', '09170000003', '$2y$12$nHr/CKJWLIhO27OK6pDjQOiyNkMNdzXBlCJlKyXNXi580YAe5/T/C', 'provider'),
(4, 'Ramon', 'Reyes', 'repairs@onehome.local', '09170000004', '$2y$12$nHr/CKJWLIhO27OK6pDjQOiyNkMNdzXBlCJlKyXNXi580YAe5/T/C', 'provider');
INSERT INTO admins (admin_id, user_id, admin_level) VALUES (1, 1, 'administrator');
INSERT INTO customers (customer_id, user_id) VALUES (1, 2);
INSERT INTO providers (provider_id, user_id, business_name, business_description, service_area_city, provider_status, verification_status) VALUES
(1, 3, 'Santos Home Cleaning', 'Home cleaning, deep cleaning, and move-in cleaning.', 'Baguio City', 'active', 'verified'),
(2, 4, 'Reyes Home Repairs', 'Plumbing and household electrical troubleshooting.', 'Baguio City', 'active', 'verified');
INSERT INTO address (address_id, customer_id, address_label, street_address, city, province, postal_code, is_default) VALUES
(1, 1, 'Home', '12 Example Street', 'Baguio City', 'Benguet', '2600', 1);
INSERT INTO service_category (category_id, category_name, description, category_status) VALUES
(1, 'House Cleaning', 'Regular, deep, and move-in/move-out cleaning.', 'active'),
(2, 'Plumbing', 'Leak repairs, faucets, drains, and basic plumbing.', 'active'),
(3, 'Electrical Repair', 'Basic household electrical inspection and repairs.', 'active'),
(4, 'Laundry', 'Washing, drying, ironing, and folding services.', 'active'),
(5, 'Appliance Repair', 'Troubleshooting and repair for common home appliances.', 'active'),
(6, 'Gardening', 'Garden cleanup, trimming, and basic plant care.', 'active'),
(7, 'Painting', 'Interior touch-ups and small household painting jobs.', 'active'),
(8, 'Carpentry', 'Minor woodwork, shelves, doors, and fixture repairs.', 'active');
INSERT INTO service_offering (offering_id, provider_id, category_id, title, description, pricing_type, base_price, offering_status) VALUES
(1, 1, 1, 'Standard Home Cleaning', 'Cleaning of bedrooms, living spaces, kitchen surfaces, and bathrooms.', 'fixed', 650.00, 'active'),
(2, 1, 1, 'Deep Home Cleaning', 'Detailed cleaning for kitchens, bathrooms, and hard-to-reach areas.', 'quote', 1000.00, 'active'),
(3, 2, 2, 'Plumbing Inspection and Repair', 'Inspection and common minor plumbing repairs.', 'quote', 800.00, 'active'),
(4, 2, 3, 'Household Electrical Repair', 'Basic inspection and repair for common household electrical issues.', 'quote', 900.00, 'active');
INSERT INTO service_request (request_id, customer_id, category_id, category_name_snapshot, address_id, service_address_snapshot, service_city_snapshot, service_province_snapshot, description, preferred_start, request_status) VALUES
(1, 1, 1, 'House Cleaning', 1, '12 Example Street, Baguio City, Benguet', 'Baguio City', 'Benguet', 'Please clean the living room, kitchen, and one bathroom.', DATE_ADD(NOW(), INTERVAL 3 DAY), 'awaiting_quotes'),
(2, 1, 2, 'Plumbing', 1, '12 Example Street, Baguio City, Benguet', 'Baguio City', 'Benguet', 'The kitchen sink is leaking and needs inspection.', DATE_ADD(NOW(), INTERVAL 5 DAY), 'booked');
INSERT INTO quote (quote_id, request_id, provider_id, offering_id, offering_title_snapshot, provider_name_snapshot, proposed_price, scope, proposed_start, proposed_end, valid_until, quote_status) VALUES
(1, 1, 1, 1, 'Standard Home Cleaning', 'Santos Home Cleaning', 650.00, 'Standard cleaning of the listed areas, including supplies and tidy-up.', DATE_ADD(NOW(), INTERVAL 3 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 3 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 2 DAY), 'submitted'),
(2, 2, 2, 3, 'Plumbing Inspection and Repair', 'Reyes Home Repairs', 1200.00, 'Inspect the kitchen sink, identify the leak, and complete minor repairs. Major parts are quoted separately.', DATE_ADD(NOW(), INTERVAL 5 DAY), DATE_ADD(DATE_ADD(NOW(), INTERVAL 5 DAY), INTERVAL 2 HOUR), DATE_ADD(NOW(), INTERVAL 4 DAY), 'accepted');
INSERT INTO booking (booking_id, request_id, quote_id, service_name_snapshot, service_category_snapshot, provider_name_snapshot, service_address_snapshot, service_city_snapshot, service_province_snapshot, agreed_scope, agreed_price, scheduled_start, scheduled_end, booking_status) VALUES
(1, 2, 2, 'Plumbing Inspection and Repair', 'Plumbing', 'Reyes Home Repairs', '12 Example Street, Baguio City, Benguet', 'Baguio City', 'Benguet', 'Inspect the kitchen sink, identify the leak, and complete minor repairs. Major parts are quoted separately.', 1200.00, (SELECT proposed_start FROM quote WHERE quote_id = 2), (SELECT proposed_end FROM quote WHERE quote_id = 2), 'confirmed');
INSERT INTO payment (payment_id, booking_id, amount, payment_type, payment_status) VALUES
(1, 1, 1200.00, 'cash_after_service', 'pending');
INSERT INTO notification (user_id, title, message) VALUES
(2, 'Welcome to OneHome', 'Browse services and submit a request to receive quotes from verified providers.'),
(3, 'New service request', 'A customer has submitted a house cleaning request in Baguio City.');
