<?php
$pageTitle = $pageTitle ?? 'OneHome';
$activeNav = $activeNav ?? '';
$role = $_SESSION['USER_ROLE'] ?? '';
$navs = [];
if ($role === 'customer') {
    $navs = [['Home','/onehome/customer/index.php','home'],['Services','/onehome/customer/services.php','services'],['My Requests','/onehome/customer/requests.php','requests'],['Bookings','/onehome/customer/bookings.php','bookings'],['Profile','/onehome/customer/profile.php','profile']];
} elseif ($role === 'provider') {
    $navs = [['Dashboard','/onehome/provider/index.php','home'],['Matched Requests','/onehome/provider/requests.php','requests'],['My Offers','/onehome/provider/offerings.php','offers'],['Bookings','/onehome/provider/bookings.php','bookings'],['Payouts','/onehome/provider/payouts.php','payouts'],['Profile','/onehome/provider/profile.php','profile']];
} elseif ($role === 'admin') {
    $navs = [['Dashboard','/onehome/admin/index.php','home'],['Providers','/onehome/admin/providers.php','providers'],['Categories','/onehome/admin/categories.php','categories'],['Requests','/onehome/admin/requests.php','requests'],['Bookings','/onehome/admin/bookings.php','bookings'],['Payments','/onehome/admin/payments.php','payments'],['Payouts','/onehome/admin/payouts.php','payouts'],['Refunds','/onehome/admin/refunds.php','refunds'],['Disputes','/onehome/admin/disputes.php','disputes'],['Reviews','/onehome/admin/reviews.php','reviews'],['Users','/onehome/admin/users.php','users']];
}
$unread = 0;
if (!empty($_SESSION['USER_ID'])) {
    try { $unread = (int)scalar($conn, 'SELECT COUNT(*) FROM notification WHERE user_id=? AND is_read=0', 'i', [(int)$_SESSION['USER_ID']]); } catch (Throwable $e) { $unread = 0; }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo h($pageTitle); ?> | OneHome</title>
<link rel="stylesheet" href="/onehome/assets/style.css">
</head>
<body>
<header class="site-header">
  <a class="brand" href="/onehome/index.php"><span class="brand-mark">O</span><span>OneHome<small>Home service marketplace</small></span></a>
  <nav class="main-nav">
    <?php foreach ($navs as $nav): ?><a class="<?php echo $activeNav === $nav[2] ? 'active' : ''; ?>" href="<?php echo h($nav[1]); ?>"><?php echo h($nav[0]); ?></a><?php endforeach; ?>
  </nav>
  <div class="header-actions">
    <?php if (!empty($_SESSION['USER_ID'])): ?>
      <a class="notification-link" href="/onehome/notifications.php" aria-label="Notifications">Notifications<?php if ($unread > 0): ?><span class="notification-count"><?php echo $unread; ?></span><?php endif; ?></a>
      <div class="user-menu"><span><?php echo h($_SESSION['USER_NAME'] ?? 'Account'); ?></span><a href="<?php echo h(home_for_role($role)); ?>">Account</a><a href="/onehome/logout.php">Log out</a></div>
    <?php else: ?><a class="nav-login" href="/onehome/login.php">Log in</a><a class="btn btn-small btn-primary" href="/onehome/register.php">Get started</a><?php endif; ?>
  </div>
</header>
<main class="page-shell">
<?php show_flash(); ?>
