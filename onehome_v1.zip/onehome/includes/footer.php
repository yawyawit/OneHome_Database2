</main>
<footer class="site-footer"><div><strong>OneHome</strong><span>Request · Match · Agree · Complete · Settle</span></div><p>Prototype marketplace. Demo payments do not transfer real money.</p></footer>
</body>
</html>
