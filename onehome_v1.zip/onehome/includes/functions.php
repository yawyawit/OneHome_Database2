<?php
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}
require_once __DIR__ . '/../dbconn.php';

function h($value): string {
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES, 'UTF-8');
}
function redirect(string $path): never {
    header('Location: ' . $path);
    exit;
}
function home_for_role(string $role): string {
    return match ($role) {
        'admin' => '/onehome/admin/index.php',
        'provider' => '/onehome/provider/index.php',
        'customer' => '/onehome/customer/index.php',
        default => '/onehome/index.php',
    };
}
function require_login(): void {
    if (empty($_SESSION['USER_ID']) || empty($_SESSION['USER_ROLE'])) {
        set_flash('error', 'Please log in to continue.');
        redirect('/onehome/login.php');
    }
    $stmt = $GLOBALS['conn']->prepare('SELECT user_role, account_status FROM users WHERE user_id = ? LIMIT 1');
    $uid = (int)$_SESSION['USER_ID'];
    $stmt->bind_param('i', $uid);
    $stmt->execute();
    $current = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if (!$current || $current['account_status'] !== 'active' || $current['user_role'] !== ($_SESSION['USER_ROLE'] ?? '')) {
        $_SESSION = [];
        session_destroy();
        header('Location: /onehome/login.php');
        exit;
    }
    // Expire quotes as part of authenticated activity so old offers cannot remain actionable.
    $GLOBALS['conn']->query("UPDATE quote SET quote_status='expired' WHERE quote_status='submitted' AND valid_until < NOW()");
}
function require_role(string ...$roles): void {
    require_login();
    if (!in_array($_SESSION['USER_ROLE'] ?? '', $roles, true)) {
        redirect(home_for_role($_SESSION['USER_ROLE'] ?? ''));
    }
}
function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}
function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . h(csrf_token()) . '">';
}
function verify_csrf(): void {
    $sent = $_POST['csrf_token'] ?? '';
    if (!is_string($sent) || !hash_equals(csrf_token(), $sent)) {
        http_response_code(403);
        exit('Invalid request token. Refresh the page and try again.');
    }
}
function set_flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}
function show_flash(): void {
    if (!empty($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        echo '<div class="alert alert-' . h($flash['type']) . '">' . h($flash['message']) . '</div>';
        unset($_SESSION['flash']);
    }
}
function scalar(mysqli $conn, string $sql, string $types = '', array $params = []): int|float|string|null {
    $stmt = $conn->prepare($sql);
    if ($types !== '') $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_row();
    $stmt->close();
    return $row[0] ?? null;
}
function row_by_id(mysqli $conn, string $sql, string $types, array $params): ?array {
    $stmt = $conn->prepare($sql);
    $stmt->bind_param($types, ...$params);
    $stmt->execute();
    $row = $stmt->get_result()->fetch_assoc() ?: null;
    $stmt->close();
    return $row;
}
function customer_id(mysqli $conn, int $userId): int {
    return (int)scalar($conn, 'SELECT customer_id FROM customers WHERE user_id = ?', 'i', [$userId]);
}
function provider_id(mysqli $conn, int $userId): int {
    return (int)scalar($conn, 'SELECT provider_id FROM providers WHERE user_id = ?', 'i', [$userId]);
}
function add_notification(mysqli $conn, int $userId, string $title, string $message): void {
    $stmt = $conn->prepare('INSERT INTO notification (user_id, title, message) VALUES (?, ?, ?)');
    $stmt->bind_param('iss', $userId, $title, $message);
    $stmt->execute();
    $stmt->close();
}
function status_class(string $status): string {
    $s = strtolower(str_replace([' ', '-'], '_', $status));
    return 'status status-' . preg_replace('/[^a-z_]/', '', $s);
}
function money($value): string {
    return '₱' . number_format((float)$value, 2);
}
function fmt_dt($value): string {
    return $value ? date('M j, Y · g:i A', strtotime($value)) : '—';
}
function input_dt_min(): string {
    return date('Y-m-d\TH:i', time() + 3600);
}
function latest_payment(mysqli $conn, int $bookingId): ?array {
    return row_by_id($conn, 'SELECT * FROM payment WHERE booking_id = ? ORDER BY payment_id DESC LIMIT 1', 'i', [$bookingId]);
}
function notify_request_parties(mysqli $conn, int $requestId, string $title, string $message): void {
    $stmt = $conn->prepare('SELECT u.user_id FROM service_request r JOIN customers c ON r.customer_id=c.customer_id JOIN users u ON c.user_id=u.user_id WHERE r.request_id=?');
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $customer = $stmt->get_result()->fetch_assoc();
    $stmt->close();
    if ($customer) add_notification($conn, (int)$customer['user_id'], $title, $message);
    $stmt = $conn->prepare('SELECT DISTINCT u.user_id FROM quote q JOIN providers p ON q.provider_id=p.provider_id JOIN users u ON p.user_id=u.user_id WHERE q.request_id=?');
    $stmt->bind_param('i', $requestId);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($provider = $result->fetch_assoc()) add_notification($conn, (int)$provider['user_id'], $title, $message);
    $stmt->close();
}
