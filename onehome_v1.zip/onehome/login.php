<?php
require_once __DIR__ . '/includes/functions.php';
if (!empty($_SESSION['USER_ROLE'])) redirect(home_for_role($_SESSION['USER_ROLE']));
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = strtolower(trim($_POST['email'] ?? ''));
    $password = $_POST['password'] ?? '';
    $stmt = $conn->prepare('SELECT user_id, first_name, last_name, email, password, user_role, account_status FROM users WHERE email=? LIMIT 1');
    $stmt->bind_param('s', $email); $stmt->execute(); $user = $stmt->get_result()->fetch_assoc(); $stmt->close();
    if (!$user || !password_verify($password, $user['password'])) $error = 'Email or password is incorrect.';
    elseif ($user['account_status'] !== 'active') $error = 'This account is currently suspended. Contact the administrator.';
    else {
        session_regenerate_id(true);
        $_SESSION['USER_ID'] = (int)$user['user_id'];
        $_SESSION['USER_ROLE'] = $user['user_role'];
        $_SESSION['USER_NAME'] = $user['first_name'];
        $_SESSION['USER_EMAIL'] = $user['email'];
        set_flash('success', 'Welcome back, ' . $user['first_name'] . '.');
        redirect(home_for_role($user['user_role']));
    }
}
$pageTitle='Log in'; include __DIR__ . '/includes/header.php';
?>
<div class="auth-layout"><div class="auth-intro"><p class="eyebrow">WELCOME BACK</p><h1>Your home services, all in one place.</h1><p>Track requests, compare quotes, manage bookings and keep payment records together.</p><div class="hero-note"><strong>Demo access</strong><br>Admin: admin@onehome.local / admin123<br>Customer: customer@onehome.local / demo123<br>Provider: cleaning@onehome.local / provider123</div></div><section class="auth-card"><h2>Log in</h2><p>Enter your account details to continue.</p><?php if($error): ?><div class="alert alert-error"><?php echo h($error); ?></div><?php endif; ?><form method="post"><input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>"><div class="field"><label for="email">Email address</label><input id="email" type="email" name="email" autocomplete="username" required value="<?php echo h($_POST['email'] ?? ''); ?>"></div><div class="field"><label for="password">Password</label><input id="password" type="password" name="password" autocomplete="current-password" required></div><button class="btn btn-primary" type="submit">Log in to OneHome</button></form><div class="auth-foot">New to OneHome? <a href="/onehome/register.php">Create an account</a></div></section></div>
<?php include __DIR__ . '/includes/footer.php'; ?>
