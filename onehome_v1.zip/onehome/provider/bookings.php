<?php
require_once __DIR__ . '/../includes/functions.php';
require_role('provider');
$pid = provider_id($conn, (int)$_SESSION['USER_ID']);
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $bid = (int)($_POST['booking_id'] ?? 0);
    $action = $_POST['action'] ?? '';
    $booking = row_by_id($conn,
        'SELECT b.*, r.request_id, r.customer_id, cu.user_id customer_user_id FROM booking b JOIN service_request r ON r.request_id=b.request_id JOIN customers cu ON cu.customer_id=r.customer_id JOIN quote q ON q.quote_id=b.quote_id WHERE b.booking_id=? AND q.provider_id=?',
        'ii', [$bid, $pid]);

    if (!$booking) {
        $error = 'Booking not found.';
    } else {
        $target = null;
        if ($action === 'start' && $booking['booking_status'] === 'confirmed') $target = 'in_progress';
        if ($action === 'report_complete' && $booking['booking_status'] === 'in_progress') $target = 'service_completed';
        if (!$target) {
            $error = 'This status transition is not allowed. Refresh the page and check the current status.';
        } else {
            try {
                $conn->begin_transaction();
                if ($target === 'in_progress') {
                    $stmt = $conn->prepare("UPDATE booking SET booking_status='in_progress' WHERE booking_id=? AND booking_status='confirmed'");
                } else {
                    $stmt = $conn->prepare("UPDATE booking SET booking_status='service_completed', completed_at=NOW() WHERE booking_id=? AND booking_status='in_progress'");
                }
                $stmt->bind_param('i', $bid);
                $stmt->execute();
                if ($stmt->affected_rows !== 1) {
                    $stmt->close();
                    throw new RuntimeException('The booking status changed. Refresh and try again.');
                }
                $stmt->close();

                if ($target === 'in_progress') {
                    $stmt = $conn->prepare("UPDATE booking_change SET change_status='cancelled', resolved_at=NOW() WHERE booking_id=? AND change_status='pending'");
                    $stmt->bind_param('i', $bid);
                    $stmt->execute();
                    $stmt->close();
                }

                if ($target === 'in_progress') {
                    $title = 'Provider started the service';
                    $message = 'Your provider marked booking #OHB-' . str_pad((string)$bid, 5, '0', STR_PAD_LEFT) . ' as In Progress.';
                } else {
                    $title = 'Provider reported service completion';
                    $message = 'Your provider reported booking #OHB-' . str_pad((string)$bid, 5, '0', STR_PAD_LEFT) . ' as complete. Please confirm the work in My Bookings.';
                }
                add_notification($conn, (int)$booking['customer_user_id'], $title, $message);
                $conn->commit();
                set_flash('success', $target === 'in_progress' ? 'Booking marked In Progress.' : 'Completion reported. The customer must confirm completion.');
                redirect('bookings.php');
            } catch (Throwable $e) {
                $conn->rollback();
                $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to update booking.';
            }
        }
    }
}

$sql = "SELECT b.*, r.description request_description, b.agreed_scope AS quote_scope, b.service_category_snapshot AS category_name, b.service_name_snapshot, b.service_address_snapshot AS street_address, b.service_city_snapshot AS city, b.service_province_snapshot AS province, cu.user_id customer_user_id, cu2.first_name customer_first, cu2.last_name customer_last, (SELECT pa.payment_status FROM payment pa WHERE pa.booking_id=b.booking_id ORDER BY pa.payment_id DESC LIMIT 1) payment_status FROM booking b JOIN quote q ON q.quote_id=b.quote_id JOIN service_request r ON r.request_id=b.request_id JOIN customers cu ON cu.customer_id=r.customer_id JOIN users cu2 ON cu2.user_id=cu.user_id WHERE q.provider_id=? ORDER BY b.scheduled_start DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param('i', $pid);
$stmt->execute();
$bookings = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
$stmt->close();
$pageTitle = 'Provider bookings';
$activeNav = 'bookings';
include __DIR__ . '/../includes/header.php';
?>
<div class="page-heading"><div><p class="eyebrow">SERVICE DELIVERY</p><h1>Your bookings</h1><p>Update job progress as it happens. The customer confirms completion, and payment remains a separate record.</p></div></div>
<?php if ($error): ?><div class="alert alert-error"><?php echo h($error); ?></div><?php endif; ?>
<section class="panel">
  <div class="panel-heading"><div><h2>Assigned work</h2><p><?php echo count($bookings); ?> booking(s)</p></div></div>
  <?php if (!$bookings): ?><div class="empty-state"><strong>No bookings assigned yet</strong><p>Send quotes to matching requests to win bookings.</p><a class="btn btn-primary" href="requests.php">Find requests</a></div>
  <?php else: ?><div class="table-wrap"><table class="data-table"><thead><tr><th>Booking</th><th>Customer / address</th><th>Schedule</th><th>Agreed price</th><th>Payment</th><th>Status / action</th></tr></thead><tbody>
  <?php foreach ($bookings as $b): ?><tr>
    <td><strong>#OHB-<?php echo str_pad((string)$b['booking_id'], 5, '0', STR_PAD_LEFT); ?></strong><br><?php echo h($b['service_name_snapshot']); ?><br><span class="muted small-text"><?php echo h($b['category_name']); ?></span><br><span class="muted small-text"><?php echo h(mb_strimwidth($b['request_description'], 0, 65, '…')); ?></span><br><span class="muted small-text">Agreed: <?php echo h(mb_strimwidth($b['quote_scope'], 0, 90, '…')); ?></span></td>
    <td><?php echo h($b['customer_first'].' '.$b['customer_last']); ?><br><span class="muted small-text"><?php echo h($b['street_address'].', '.$b['city'].', '.$b['province']); ?></span></td>
    <td><?php echo h(fmt_dt($b['scheduled_start'])); ?><br><span class="muted small-text">Until <?php echo h(date('g:i A', strtotime($b['scheduled_end']))); ?></span></td>
    <td><?php echo money($b['agreed_price']); ?></td>
    <td><span class="<?php echo h(status_class($b['payment_status'] ?? 'pending')); ?>"><?php echo h($b['payment_status'] ?? 'pending'); ?></span></td>
    <td><span class="<?php echo h(status_class($b['booking_status'])); ?>"><?php echo h(str_replace('_', ' ', $b['booking_status'])); ?></span><div class="table-actions" style="margin-top:8px">
      <?php if ($b['booking_status'] === 'confirmed'): ?><a class="btn btn-light btn-small" href="/onehome/reschedules.php?booking_id=<?php echo (int)$b['booking_id']; ?>">Reschedule</a><form method="post"><input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="booking_id" value="<?php echo (int)$b['booking_id']; ?>"><input type="hidden" name="action" value="start"><button class="btn btn-primary btn-small">Start service</button></form>
      <?php elseif ($b['booking_status'] === 'in_progress'): ?><form method="post" onsubmit="return confirm('Report that the service has been performed? The customer will be asked to confirm.');"><input type="hidden" name="csrf_token" value="<?php echo h(csrf_token()); ?>"><input type="hidden" name="booking_id" value="<?php echo (int)$b['booking_id']; ?>"><input type="hidden" name="action" value="report_complete"><button class="btn btn-secondary btn-small">Report complete</button></form>
      <?php elseif ($b['booking_status'] === 'service_completed'): ?><span class="muted small-text">Await customer confirmation</span><?php endif; ?>
    </div></td>
  </tr><?php endforeach; ?></tbody></table></div><?php endif; ?>
</section>
<?php include __DIR__ . '/../includes/footer.php'; ?>
