<?php
require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
post_only();
verify_csrf_token();

$user_id = (int) ($_POST['id'] ?? 0);
$employee = db_one(
    "SELECT id FROM users WHERE id = ? AND role = 'employee' AND status = 'pending' LIMIT 1",
    [$user_id]
);

if (!$employee) {
    flash('The pending employee account could not be found.', 'danger');
    redirect('admin/users/index.php?role=employee');
}

$statement = db_run(
    "UPDATE users SET status = 'active' WHERE id = ? AND role = 'employee' AND status = 'pending'",
    [$user_id]
);
$updated_rows = mysqli_stmt_affected_rows($statement);
mysqli_stmt_close($statement);

if ($updated_rows === 1) {
    flash('Employee approved and activated. The employee can now log in.');
} else {
    flash('The employee account was not changed. Please refresh and try again.', 'danger');
}

redirect('admin/users/index.php?role=employee');
