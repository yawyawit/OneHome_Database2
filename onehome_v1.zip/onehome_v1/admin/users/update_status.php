<?php
require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
post_only();
verify_csrf_token();

$user_id = (int) ($_POST['id'] ?? 0);
$new_status = $_POST['status'] ?? '';

// Only active and inactive are valid admin-selected account states.
if ($user_id < 1 || !in_array($new_status, ['active', 'inactive'], true)) {
    flash('Invalid account status request.', 'danger');
    redirect('admin/users/index.php?role=employee');
}

// Never allow this page to change an administrator account.
$user = db_one(
    "SELECT id, role, status FROM users WHERE id = ? AND role IN ('customer', 'employee') LIMIT 1",
    [$user_id]
);

if (!$user) {
    flash('The selected account could not be found.', 'danger');
    redirect('admin/users/index.php?role=employee');
}

$role = $user['role'];
$current_status = $user['status'];
$redirect_page = 'admin/users/index.php?role=' . $role;

if ($current_status === $new_status) {
    flash('This account already has that status.', 'info');
    redirect($redirect_page);
}

// A pending employee becomes active when the administrator approves the account.
// An active account can be deactivated, and an inactive account can be reactivated.
$statement = db_run(
    "UPDATE users SET status = ? WHERE id = ? AND role = ? AND status = ?",
    [$new_status, $user_id, $role, $current_status]
);
$updated_rows = mysqli_stmt_affected_rows($statement);
mysqli_stmt_close($statement);

if ($updated_rows !== 1) {
    flash('The account status was not changed. Please refresh the page and try again.', 'danger');
    redirect($redirect_page);
}

if ($new_status === 'active' && $current_status === 'pending' && $role === 'employee') {
    flash('Employee approved and activated. The employee can now log in.');
} elseif ($new_status === 'active') {
    flash('Account activated successfully.');
} else {
    flash('Account deactivated successfully.');
}

redirect($redirect_page);
