<?php
require_once __DIR__ . '/../../includes/auth.php';
require_role('admin');
$title = 'Users';
$requested_role = $_GET['role'] ?? 'customer';
$filter_role = in_array($requested_role, ['customer', 'employee', 'admin'], true) ? $requested_role : 'customer';
$current_admin = current_user();
$users = db_all("SELECT * FROM users WHERE role=? ORDER BY (status='pending') DESC, name", [$filter_role]);
require INC . '/header.php';
?>
<div class="page-heading">
    <div>
        <p class="eyebrow">PEOPLE</p>
        <h1>Users</h1>
        <p>Manage customer accounts, employee registrations, and administrator access.</p>
    </div>
</div>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-2 mb-3">
    <div class="d-flex flex-wrap gap-2">
    <a class="btn <?= $filter_role === 'customer' ? 'btn-primary' : 'btn-outline-secondary' ?>" href="index.php?role=customer">Customers</a>
    <a class="btn <?= $filter_role === 'employee' ? 'btn-primary' : 'btn-outline-secondary' ?>" href="index.php?role=employee">
        Employees<?php if (pending_employees_count()): ?> <span class="badge bg-light text-primary ms-1"><?= pending_employees_count() ?> pending</span><?php endif; ?>
    </a>
    <a class="btn <?= $filter_role === 'admin' ? 'btn-primary' : 'btn-outline-secondary' ?>" href="index.php?role=admin">Administrators</a>
    </div>
    <?php if ($filter_role === 'admin'): ?>
        <a class="btn btn-primary" href="create_admin.php"><i class="bi bi-person-plus me-1"></i>Add Administrator</a>
    <?php endif; ?>
</div>

<div class="card">
    <div class="card-header d-flex justify-content-between align-items-center">
        <span><?= ucfirst($filter_role) ?> accounts</span>
        <span class="text-muted small"><?= count($users) ?> account<?= count($users) === 1 ? '' : 's' ?></span>
    </div>
    <div class="table-responsive border-0">
        <?php if ($users): ?>
            <table class="table table-hover align-middle">
                <thead><tr><th>Name</th><th>Email</th><th>Phone</th><th>Joined</th><th>Status</th><th>Actions</th></tr></thead>
                <tbody>
                    <?php foreach ($users as $x): ?>
                        <tr>
                            <td class="fw-semibold"><?= e($x['name']) ?></td>
                            <td><?= e($x['email']) ?></td>
                            <td><?= e($x['phone']) ?></td>
                            <td><?= fdate($x['created_at']) ?></td>
                            <td><?= badge($x['status']) ?><?php if ($filter_role === 'admin' && (int) $x['id'] === (int) $current_admin['id']): ?> <span class="badge bg-light text-secondary">You</span><?php endif; ?></td>
                            <td class="text-nowrap">
                                <?php if ($filter_role !== 'admin'): ?>
                                    <a class="btn btn-sm btn-light" href="view.php?id=<?= $x['id'] ?>">View</a>
                                    <?php if ($x['status'] === 'pending'): ?>
                                        <form method="post" action="update_status.php" class="d-inline"
                                            data-confirm="Approve and activate this employee account?">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
                                            <input type="hidden" name="status" value="active">
                                            <button type="submit" class="btn btn-sm btn-success">Approve &amp; Activate</button>
                                        </form>
                                    <?php elseif ($x['status'] === 'active'): ?>
                                        <form method="post" action="update_status.php" class="d-inline"
                                            data-confirm="Deactivate this account? The employee will no longer be able to log in.">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
                                            <input type="hidden" name="status" value="inactive">
                                            <button type="submit" class="btn btn-sm btn-outline-danger">Deactivate</button>
                                        </form>
                                    <?php else: ?>
                                        <form method="post" action="update_status.php" class="d-inline"
                                            data-confirm="Reactivate this employee account?">
                                            <?= csrf_field() ?>
                                            <input type="hidden" name="id" value="<?= (int) $x['id'] ?>">
                                            <input type="hidden" name="status" value="active">
                                            <button type="submit" class="btn btn-sm btn-outline-success">Activate</button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted small">Managed by administrators</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php else: ?>
            <div class="empty-state"><i class="bi bi-people"></i><strong>No <?= e($filter_role) ?> accounts found</strong><span><?= $filter_role === 'admin' ? 'Use Add Administrator to create another admin account.' : 'New accounts will appear here.' ?></span></div>
        <?php endif; ?>
    </div>
</div>
<?php require INC . '/footer.php'; ?>
