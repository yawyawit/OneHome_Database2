<?php
    $host = 'localhost:3305';
    $user = 'root';
    $pass = '';
    $db = 'one_home';
    $charset = 'utf8mb4';

    $dsn = "mysql:host=$host;dbname=$db;charset=$charset";
    $attributes = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false
    ];

    try {
        $pdo = new PDO($dsn, $user, $pass, $attributes);
    } catch (Exception $e) {
        die("Database connection failed..." . $e->getMessage());
    }
?>


<?php
// Use MySQLi exceptions only when a query fails.
/*mysqli_report(MYSQLI_REPORT_OFF);

$conn = mysqli_connect('localhost:3305', 'root', '', 'one_home');
if (!$conn) {
    die('Database connection failed: ' . mysqli_connect_error() . '. Did you import database/one_home.sql in phpMyAdmin?');
}
mysqli_set_charset($conn, 'utf8mb4');
$docroot = str_replace('\\', '/', realpath($_SERVER['DOCUMENT_ROOT']));
$root = str_replace('\\', '/', realpath(__DIR__ . '/..'));
define('BASE_URL', rtrim(substr($root, strlen($docroot)), '/'));*/
?>